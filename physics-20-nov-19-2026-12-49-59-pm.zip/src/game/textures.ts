import * as THREE from 'three';

export interface ProceduralTextureSet {
  stoneMap: THREE.CanvasTexture;
  stoneBump: THREE.CanvasTexture;
  metalMap: THREE.CanvasTexture;
  metalBump: THREE.CanvasTexture;
  trimMap: THREE.CanvasTexture;
  iceMap: THREE.CanvasTexture;
  contactShadowMap: THREE.CanvasTexture;
  // World 5: Frozen Abyss textures
  frozenStoneMap: THREE.CanvasTexture;
  frozenStoneBump: THREE.CanvasTexture;
  clearIceMap: THREE.CanvasTexture;
  snowMap: THREE.CanvasTexture;
  // World 6: Inferno Core textures
  basaltMap: THREE.CanvasTexture;
  basaltBump: THREE.CanvasTexture;
  industrialMetalMap: THREE.CanvasTexture;
  lavaMap: THREE.CanvasTexture;
  dispose: () => void;
}

function makeCanvas(size: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not acquire 2D context for procedural texture generation');
  }
  return [canvas, ctx];
}

function seededRand(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function configureTexture(
  canvas: HTMLCanvasElement,
  isColor: boolean,
  anisotropy: number,
  repeat = 1,
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = anisotropy;
  if (isColor) {
    tex.colorSpace = THREE.SRGBColorSpace;
  }
  tex.needsUpdate = true;
  return tex;
}

export function createProceduralTextures(renderer: THREE.WebGLRenderer): ProceduralTextureSet {
  const maxAniso = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  const rand = seededRand(202607);

  // 1. Dark Carved Architectural Basalt Stone (Albedo + Bump)
  const [stoneColC, sCtx] = makeCanvas(512);
  const [stoneBmpC, sbCtx] = makeCanvas(512);

  sCtx.fillStyle = '#242b35';
  sCtx.fillRect(0, 0, 512, 512);
  sbCtx.fillStyle = '#8a8a8a';
  sbCtx.fillRect(0, 0, 512, 512);

  // Ashlar stone blocks with subtle tonal shifts
  const tile = 128;
  for (let row = 0; row < 4; row++) {
    const offset = (row % 2) * 64;
    for (let col = -1; col < 5; col++) {
      const x = col * tile + offset;
      const y = row * tile;
      const tone = Math.floor(34 + rand() * 14);
      sCtx.fillStyle = `rgb(${tone}, ${tone + 6}, ${tone + 14})`;
      sCtx.fillRect(x + 2, y + 2, tile - 4, tile - 4);

      const bmpTone = Math.floor(132 + rand() * 24);
      sbCtx.fillStyle = `rgb(${bmpTone}, ${bmpTone}, ${bmpTone})`;
      sbCtx.fillRect(x + 3, y + 3, tile - 6, tile - 6);

      // Subtle bevel edge highlight
      sCtx.strokeStyle = 'rgba(130, 160, 195, 0.08)';
      sCtx.lineWidth = 1.5;
      sCtx.strokeRect(x + 3, y + 3, tile - 6, tile - 6);

      // Grout seam
      sCtx.strokeStyle = '#141920';
      sCtx.lineWidth = 3;
      sCtx.strokeRect(x, y, tile, tile);

      sbCtx.strokeStyle = '#202020';
      sbCtx.lineWidth = 4;
      sbCtx.strokeRect(x, y, tile, tile);
    }
  }

  // Fine mineral grain speckles
  for (let i = 0; i < 4200; i++) {
    const gx = rand() * 512;
    const gy = rand() * 512;
    const bright = rand() > 0.5;
    sCtx.fillStyle = bright ? 'rgba(200,220,240,0.035)' : 'rgba(8,10,14,0.07)';
    sCtx.fillRect(gx, gy, 2, 2);
    sbCtx.fillStyle = bright ? 'rgba(220,220,220,0.08)' : 'rgba(30,30,30,0.08)';
    sbCtx.fillRect(gx, gy, 2, 2);
  }

  // Subtle architectural energy-channel hairline
  sCtx.strokeStyle = 'rgba(56, 189, 248, 0.14)';
  sCtx.lineWidth = 1.5;
  sCtx.beginPath();
  sCtx.moveTo(0, 256);
  sCtx.lineTo(512, 256);
  sCtx.stroke();

  // 2. Brushed Dark Titanium Metal (Albedo + Bump)
  const [metalColC, mCtx] = makeCanvas(512);
  const [metalBmpC, mbCtx] = makeCanvas(512);

  mCtx.fillStyle = '#333d4b';
  mCtx.fillRect(0, 0, 512, 512);
  mbCtx.fillStyle = '#808080';
  mbCtx.fillRect(0, 0, 512, 512);

  // Horizontal brushed grain streaks
  for (let y = 0; y < 512; y += 2) {
    const v = Math.floor(46 + rand() * 18);
    mCtx.fillStyle = `rgb(${v}, ${v + 8}, ${v + 16})`;
    mCtx.fillRect(0, y, 512, 2);
    const bv = Math.floor(110 + rand() * 36);
    mbCtx.fillStyle = `rgb(${bv}, ${bv}, ${bv})`;
    mbCtx.fillRect(0, y, 512, 2);
  }

  // Industrial machined panel seams + recessed corner rivets
  mCtx.strokeStyle = '#1b222c';
  mCtx.lineWidth = 4;
  mCtx.strokeRect(4, 4, 504, 504);
  mCtx.strokeRect(256, 0, 256, 256);
  mCtx.strokeRect(0, 256, 256, 256);

  mbCtx.strokeStyle = '#252525';
  mbCtx.lineWidth = 5;
  mbCtx.strokeRect(4, 4, 504, 504);
  mbCtx.strokeRect(256, 0, 256, 256);
  mbCtx.strokeRect(0, 256, 256, 256);

  const rivets = [
    [24, 24], [232, 24], [24, 232], [232, 232],
    [280, 24], [488, 24], [280, 232], [488, 232],
    [24, 280], [232, 280], [24, 488], [232, 488],
    [280, 280], [488, 280], [280, 488], [488, 488],
  ];
  for (const [rx, ry] of rivets) {
    mCtx.fillStyle = '#1a2028';
    mCtx.beginPath();
    mCtx.arc(rx, ry, 5, 0, Math.PI * 2);
    mCtx.fill();
    mCtx.fillStyle = '#5c6b80';
    mCtx.beginPath();
    mCtx.arc(rx - 1, ry - 1, 3, 0, Math.PI * 2);
    mCtx.fill();
  }

  // 3. Architectural Bronze-Slate Trim
  const [trimC, tCtx] = makeCanvas(256);
  tCtx.fillStyle = '#3d3935';
  tCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 256; i += 4) {
    const shade = Math.floor(56 + rand() * 14);
    tCtx.fillStyle = `rgb(${shade + 6}, ${shade + 2}, ${shade - 4})`;
    tCtx.fillRect(0, i, 256, 4);
  }
  tCtx.strokeStyle = '#23201d';
  tCtx.lineWidth = 4;
  tCtx.strokeRect(2, 2, 252, 252);

  // 4. Low-Friction Kinetic Track Surface
  const [iceC, iCtx] = makeCanvas(256);
  iCtx.fillStyle = '#233b4d';
  iCtx.fillRect(0, 0, 256, 256);
  iCtx.strokeStyle = 'rgba(125, 211, 252, 0.32)';
  iCtx.lineWidth = 3;
  for (let y = 16; y < 256; y += 64) {
    // Directional chevrons
    iCtx.beginPath();
    iCtx.moveTo(40, y + 36);
    iCtx.lineTo(128, y + 8);
    iCtx.lineTo(216, y + 36);
    iCtx.stroke();
  }
  iCtx.strokeStyle = 'rgba(186, 230, 253, 0.14)';
  iCtx.lineWidth = 1.5;
  iCtx.strokeRect(4, 4, 248, 248);

  // 5. Soft Radial Contact Shadow Disc
  const [shadowC, shCtx] = makeCanvas(128);
  const grad = shCtx.createRadialGradient(64, 64, 8, 64, 64, 60);
  grad.addColorStop(0, 'rgba(4, 8, 14, 0.72)');
  grad.addColorStop(0.55, 'rgba(4, 8, 14, 0.34)');
  grad.addColorStop(1, 'rgba(4, 8, 14, 0.0)');
  shCtx.fillStyle = grad;
  shCtx.fillRect(0, 0, 128, 128);

  // 6. World 5 — Dark Icy Carved Stone (Albedo + Bump)
  const randIce = seededRand(50521);
  const [fStoneC, fsCtx] = makeCanvas(512);
  const [fStoneBmpC, fsbCtx] = makeCanvas(512);
  fsCtx.fillStyle = '#1c2b3c';
  fsCtx.fillRect(0, 0, 512, 512);
  fsbCtx.fillStyle = '#888888';
  fsbCtx.fillRect(0, 0, 512, 512);

  for (let row = 0; row < 4; row++) {
    const off = (row % 2) * 64;
    for (let col = -1; col < 5; col++) {
      const x = col * 128 + off;
      const y = row * 128;
      const tone = Math.floor(28 + randIce() * 14);
      fsCtx.fillStyle = `rgb(${tone}, ${tone + 14}, ${tone + 28})`;
      fsCtx.fillRect(x + 2, y + 2, 124, 124);
      const bTone = Math.floor(126 + randIce() * 28);
      fsbCtx.fillStyle = `rgb(${bTone}, ${bTone}, ${bTone})`;
      fsbCtx.fillRect(x + 3, y + 3, 122, 122);

      // Frosted rime along top seam of each block
      fsCtx.fillStyle = 'rgba(186, 230, 253, 0.14)';
      fsCtx.fillRect(x + 3, y + 3, 122, 7);

      fsCtx.strokeStyle = '#0e1926';
      fsCtx.lineWidth = 3;
      fsCtx.strokeRect(x, y, 128, 128);
      fsbCtx.strokeStyle = '#222222';
      fsbCtx.lineWidth = 4;
      fsbCtx.strokeRect(x, y, 128, 128);
    }
  }
  for (let i = 0; i < 3200; i++) {
    const gx = randIce() * 512;
    const gy = randIce() * 512;
    fsCtx.fillStyle = randIce() > 0.45 ? 'rgba(206, 238, 255, 0.07)' : 'rgba(6, 14, 24, 0.08)';
    fsCtx.fillRect(gx, gy, 2, 2);
  }

  // 7. World 5 — Transparent Glacial Ice (Internal Fractures & Specular Veins)
  const [cIceC, ciCtx] = makeCanvas(512);
  const iceGrad = ciCtx.createLinearGradient(0, 0, 512, 512);
  iceGrad.addColorStop(0, '#9bd8f4');
  iceGrad.addColorStop(0.5, '#7cc6ea');
  iceGrad.addColorStop(1, '#a9e2fa');
  ciCtx.fillStyle = iceGrad;
  ciCtx.fillRect(0, 0, 512, 512);

  // Subtle crystalline frost bands and delicate internal hairline fractures
  for (let i = 0; i < 24; i++) {
    const x1 = randIce() * 512;
    const y1 = randIce() * 512;
    const len = 60 + randIce() * 140;
    const ang = randIce() * Math.PI * 2;
    ciCtx.strokeStyle = `rgba(240, 250, 255, ${0.14 + randIce() * 0.2})`;
    ciCtx.lineWidth = 1 + randIce() * 1.4;
    ciCtx.beginPath();
    ciCtx.moveTo(x1, y1);
    ciCtx.lineTo(x1 + Math.cos(ang) * len, y1 + Math.sin(ang) * len);
    ciCtx.stroke();
  }
  ciCtx.strokeStyle = 'rgba(224, 242, 254, 0.34)';
  ciCtx.lineWidth = 3;
  ciCtx.strokeRect(4, 4, 504, 504);

  // 8. World 5 — Compacted Alpine Snow Surface (cooler glacial shading so shadows & bevels read crisply)
  const [snowC, snCtx] = makeCanvas(256);
  snCtx.fillStyle = '#bfd6e8';
  snCtx.fillRect(0, 0, 256, 256);
  // Subtle wind-drift ripples (toroidally wrapped)
  for (let y = 16; y < 256; y += 32) {
    snCtx.strokeStyle = y % 64 === 16 ? 'rgba(235, 246, 255, 0.34)' : 'rgba(118, 156, 192, 0.24)';
    snCtx.lineWidth = 6;
    snCtx.beginPath();
    snCtx.moveTo(0, y);
    snCtx.bezierCurveTo(64, y - 6, 192, y + 6, 256, y);
    snCtx.stroke();
  }
  for (let i = 0; i < 3000; i++) {
    const sx = randIce() * 256;
    const sy = randIce() * 256;
    snCtx.fillStyle = randIce() > 0.5 ? 'rgba(245, 252, 255, 0.26)' : 'rgba(92, 132, 168, 0.16)';
    snCtx.fillRect(sx, sy, 2, 2);
  }

  // 9. World 6 — Dark Volcanic Basalt (Albedo + Bump)
  const randFire = seededRand(60626);
  const [basaltC, baCtx] = makeCanvas(512);
  const [basaltBmpC, babCtx] = makeCanvas(512);
  baCtx.fillStyle = '#1f1b1b';
  baCtx.fillRect(0, 0, 512, 512);
  babCtx.fillStyle = '#787878';
  babCtx.fillRect(0, 0, 512, 512);

  for (let row = 0; row < 4; row++) {
    const off = (row % 2) * 64;
    for (let col = -1; col < 5; col++) {
      const x = col * 128 + off;
      const y = row * 128;
      const v = Math.floor(24 + randFire() * 14);
      baCtx.fillStyle = `rgb(${v + 5}, ${v + 1}, ${v})`;
      baCtx.fillRect(x + 2, y + 2, 124, 124);
      const bv = Math.floor(110 + randFire() * 44);
      babCtx.fillStyle = `rgb(${bv}, ${bv}, ${bv})`;
      babCtx.fillRect(x + 3, y + 3, 122, 122);

      baCtx.strokeStyle = '#100d0d';
      baCtx.lineWidth = 3.5;
      baCtx.strokeRect(x, y, 128, 128);
      babCtx.strokeStyle = '#1a1a1a';
      babCtx.lineWidth = 4;
      babCtx.strokeRect(x, y, 128, 128);
    }
  }
  // Subtle deep ember vein glint in a few basalt cracks (restrained, not noisy)
  baCtx.strokeStyle = 'rgba(234, 88, 12, 0.22)';
  baCtx.lineWidth = 1.5;
  baCtx.beginPath();
  baCtx.moveTo(0, 128);
  baCtx.lineTo(512, 128);
  baCtx.moveTo(256, 0);
  baCtx.lineTo(256, 512);
  baCtx.stroke();
  for (let i = 0; i < 3600; i++) {
    const gx = randFire() * 512;
    const gy = randFire() * 512;
    baCtx.fillStyle = randFire() > 0.5 ? 'rgba(95, 76, 68, 0.06)' : 'rgba(6, 4, 4, 0.1)';
    baCtx.fillRect(gx, gy, 2, 2);
  }

  // 10. World 6 — Forged Industrial Furnace Metal Grating
  const [indMetC, imCtx] = makeCanvas(512);
  imCtx.fillStyle = '#2d2928';
  imCtx.fillRect(0, 0, 512, 512);
  for (let y = 0; y < 512; y += 32) {
    for (let x = 0; x < 512; x += 32) {
      imCtx.fillStyle = ((x + y) / 32) % 2 === 0 ? '#36312f' : '#262221';
      imCtx.fillRect(x + 2, y + 2, 28, 28);
      imCtx.strokeStyle = '#181515';
      imCtx.lineWidth = 2;
      imCtx.strokeRect(x + 1, y + 1, 30, 30);
    }
  }
  // Subtle industrial amber border seam
  imCtx.strokeStyle = 'rgba(217, 119, 6, 0.35)';
  imCtx.lineWidth = 4;
  imCtx.strokeRect(6, 6, 500, 500);

  // 11. World 6 — Seamless Toroidal Cellular Magma Crust & Glowing Lava Fissures
  const lavaSize = 256;
  const [lavaC, lCtx] = makeCanvas(lavaSize);
  const lavaImg = lCtx.createImageData(lavaSize, lavaSize);
  const cells = 7;
  const ptsX: number[] = [];
  const ptsY: number[] = [];
  for (let cy = 0; cy < cells; cy++) {
    for (let cx = 0; cx < cells; cx++) {
      ptsX.push(cx + 0.15 + randFire() * 0.7);
      ptsY.push(cy + 0.15 + randFire() * 0.7);
    }
  }
  const d = lavaImg.data;
  for (let py = 0; py < lavaSize; py++) {
    const gy = (py / lavaSize) * cells;
    const iy = Math.floor(gy);
    for (let px = 0; px < lavaSize; px++) {
      const gx = (px / lavaSize) * cells;
      const ix = Math.floor(gx);
      let d1 = 99;
      let d2 = 99;
      for (let oy = -1; oy <= 1; oy++) {
        const ny = (iy + oy + cells) % cells;
        const wrapY = iy + oy < 0 ? -cells : iy + oy >= cells ? cells : 0;
        for (let ox = -1; ox <= 1; ox++) {
          const nx = (ix + ox + cells) % cells;
          const wrapX = ix + ox < 0 ? -cells : ix + ox >= cells ? cells : 0;
          const idx = ny * cells + nx;
          const dx = gx - (ptsX[idx] + wrapX);
          const dy = gy - (ptsY[idx] + wrapY);
          const dist = Math.hypot(dx, dy);
          if (dist < d1) {
            d2 = d1;
            d1 = dist;
          } else if (dist < d2) {
            d2 = dist;
          }
        }
      }
      // Edge distance between Voronoi plates forms natural volcanic fissures
      const edge = d2 - d1;
      const wave =
        0.5 +
        0.25 * Math.sin((px / lavaSize) * Math.PI * 4 + (py / lavaSize) * Math.PI * 2) +
        0.25 * Math.cos((py / lavaSize) * Math.PI * 6 - (px / lavaSize) * Math.PI * 2);
      const heat = Math.max(0, Math.min(1, 1 - edge * 3.15 + (wave - 0.5) * 0.16));

      let r: number;
      let g: number;
      let b: number;
      if (heat < 0.38) {
        // Dark cooled basalt magma crust plates
        const t = heat / 0.38;
        r = 24 + t * 38;
        g = 12 + t * 10;
        b = 11 + t * 6;
      } else if (heat < 0.72) {
        // Deep crimson-to-ember transition along fissure walls
        const t = (heat - 0.38) / 0.34;
        r = 62 + t * 168;
        g = 22 + t * 64;
        b = 17 - t * 9;
      } else {
        // Bright molten core veins (controlled amber-orange, never blown-out white)
        const t = (heat - 0.72) / 0.28;
        r = 230 + t * 24;
        g = 86 + t * 104;
        b = 8 + t * 32;
      }
      const pIdx = (py * lavaSize + px) * 4;
      d[pIdx] = Math.round(r);
      d[pIdx + 1] = Math.round(g);
      d[pIdx + 2] = Math.round(b);
      d[pIdx + 3] = 255;
    }
  }
  lCtx.putImageData(lavaImg, 0, 0);

  const stoneMap = configureTexture(stoneColC, true, maxAniso, 1);
  const stoneBump = configureTexture(stoneBmpC, false, maxAniso, 1);
  const metalMap = configureTexture(metalColC, true, maxAniso, 1);
  const metalBump = configureTexture(metalBmpC, false, maxAniso, 1);
  const trimMap = configureTexture(trimC, true, maxAniso, 1);
  const iceMap = configureTexture(iceC, true, maxAniso, 1);
  const contactShadowMap = configureTexture(shadowC, true, 1, 1);
  contactShadowMap.wrapS = THREE.ClampToEdgeWrapping;
  contactShadowMap.wrapT = THREE.ClampToEdgeWrapping;

  const frozenStoneMap = configureTexture(fStoneC, true, maxAniso, 1);
  const frozenStoneBump = configureTexture(fStoneBmpC, false, maxAniso, 1);
  const clearIceMap = configureTexture(cIceC, true, maxAniso, 1);
  const snowMap = configureTexture(snowC, true, maxAniso, 1);

  const basaltMap = configureTexture(basaltC, true, maxAniso, 1);
  const basaltBump = configureTexture(basaltBmpC, false, maxAniso, 1);
  const industrialMetalMap = configureTexture(indMetC, true, maxAniso, 1);
  const lavaMap = configureTexture(lavaC, true, maxAniso, 1);

  return {
    stoneMap,
    stoneBump,
    metalMap,
    metalBump,
    trimMap,
    iceMap,
    contactShadowMap,
    frozenStoneMap,
    frozenStoneBump,
    clearIceMap,
    snowMap,
    basaltMap,
    basaltBump,
    industrialMetalMap,
    lavaMap,
    dispose: () => {
      stoneMap.dispose();
      stoneBump.dispose();
      metalMap.dispose();
      metalBump.dispose();
      trimMap.dispose();
      iceMap.dispose();
      contactShadowMap.dispose();
      frozenStoneMap.dispose();
      frozenStoneBump.dispose();
      clearIceMap.dispose();
      snowMap.dispose();
      basaltMap.dispose();
      basaltBump.dispose();
      industrialMetalMap.dispose();
      lavaMap.dispose();
    },
  };
}
