import type {
  EnvironmentTheme,
  GravityZoneDef,
  LaserHazardDef,
  LavaHazardDef,
  LevelBlueprint,
  TierId,
  Vec3,
  WorldId,
} from './types';

export interface WorldMeta {
  id: WorldId;
  number: number;
  name: string;
  subtitle: string;
  range: [number, number];
  theme: EnvironmentTheme;
  difficultyLabel: string;
}

export const WORLD_ORDER: WorldId[] = [
  'world1',
  'world2',
  'world3',
  'world4',
  'world5',
  'world6',
];

export const WORLD_META: Record<WorldId, WorldMeta> = {
  world1: {
    id: 'world1',
    number: 1,
    name: 'Citadel Gate',
    subtitle: 'Gravity, kinetic blocks, momentum, switches, and twin counterweights.',
    range: [1, 5],
    theme: 'citadel',
    difficultyLabel: 'Foundation',
  },
  world2: {
    id: 'world2',
    number: 2,
    name: 'Kinetic Foundry',
    subtitle: 'Moving shuttles, rotating spans, multi-block chambers, and low-G spires.',
    range: [6, 10],
    theme: 'citadel',
    difficultyLabel: 'Intermediate',
  },
  world3: {
    id: 'world3',
    number: 3,
    name: 'Vector Spire',
    subtitle: 'Timed gauntlets, gravity shifts, laser occlusion, and tri-stage circuits.',
    range: [11, 15],
    theme: 'citadel',
    difficultyLabel: 'Advanced',
  },
  world4: {
    id: 'world4',
    number: 4,
    name: 'Axiom Vault',
    subtitle: 'High-speed momentum courses, limited-pulse trials, and the twentieth axiom.',
    range: [16, 20],
    theme: 'citadel',
    difficultyLabel: 'Master',
  },
  world5: {
    id: 'world5',
    number: 5,
    name: 'Frozen Abyss',
    subtitle: 'Low-friction transparent ice, sliding weights, frozen switches, and collapsing bridges.',
    range: [21, 25],
    theme: 'frozen',
    difficultyLabel: 'Very Hard',
  },
  world6: {
    id: 'world6',
    number: 6,
    name: 'Inferno Core',
    subtitle: 'Molten lava crossings, heat-sensitive receptors, rotating furnaces, and timed meltdowns.',
    range: [26, 30],
    theme: 'inferno',
    difficultyLabel: 'Extreme Hard',
  },
};

export function getWorldForLevel(levelId: number): WorldMeta {
  for (const wid of WORLD_ORDER) {
    const meta = WORLD_META[wid];
    if (levelId >= meta.range[0] && levelId <= meta.range[1]) {
      return meta;
    }
  }
  return WORLD_META.world1;
}

export const TIER_META: Record<TierId, { label: string; range: string; description: string }> = {
  foundation: {
    label: 'Foundation',
    range: 'Levels 01–04',
    description: 'Core gravity, pushing, momentum, and mechanical switches.',
  },
  intermediate: {
    label: 'Intermediate',
    range: 'Levels 05–08',
    description: 'Pressure plates, moving shuttles, rotating spans, and multi-block puzzles.',
  },
  advanced: {
    label: 'Advanced',
    range: 'Levels 09–12',
    description: 'Interlocked circuits, low-gravity spires, timed runs, and precision placement.',
  },
  expert: {
    label: 'Expert',
    range: 'Levels 13–16',
    description: 'Gravity shifts, laser occlusion, multi-stage mechanisms, and momentum gauntlets.',
  },
  nightmare: {
    label: 'Nightmare',
    range: 'Levels 17–19',
    description: 'Limited-pulse challenges and tightly coupled multi-system chambers.',
  },
  final: {
    label: 'Final Challenge',
    range: 'Level 20',
    description: 'The complete citadel combining every physics principle into one finale.',
  },
  frozen: {
    label: 'World 5 · Frozen Abyss',
    range: 'Levels 21–25',
    description: 'Glacial low-friction ice, sliding monoliths, frozen switches, and breaking passages.',
  },
  inferno: {
    label: 'World 6 · Inferno Core',
    range: 'Levels 26–30',
    description: 'Volcanic molten crossings, thermal conduits, rotating furnaces, and meltdown trials.',
  },
};

export function evaluateSignalCondition(
  requiredSignals: string[] | undefined,
  signalMap: Readonly<Record<string, boolean>>,
  logic: 'AND' | 'OR' = 'AND',
): boolean {
  if (!requiredSignals || requiredSignals.length === 0) {
    return true;
  }
  if (logic === 'OR') {
    return requiredSignals.some((id) => Boolean(signalMap[id]));
  }
  return requiredSignals.every((id) => Boolean(signalMap[id]));
}

export function evaluateLaserCycle(laser: LaserHazardDef, elapsedTime: number): boolean {
  if (!laser.cyclePeriod || laser.cyclePeriod <= 0) {
    return true;
  }
  const duty = laser.activeDuty ?? 0.55;
  const phase = ((elapsedTime + (laser.phaseOffset ?? 0)) % laser.cyclePeriod + laser.cyclePeriod) % laser.cyclePeriod;
  return phase < laser.cyclePeriod * duty;
}

export function pointInBox(point: Vec3, center: Vec3, size: Vec3): boolean {
  const hx = size[0] * 0.5;
  const hy = size[1] * 0.5;
  const hz = size[2] * 0.5;
  return (
    Math.abs(point[0] - center[0]) <= hx &&
    Math.abs(point[1] - center[1]) <= hy &&
    Math.abs(point[2] - center[2]) <= hz
  );
}

export function resolveGravityAtPoint(
  point: Vec3,
  baseGravity: Vec3,
  activeGravitySwitchVector: Vec3 | null,
  zones: GravityZoneDef[],
  signalMap: Readonly<Record<string, boolean>>,
): Vec3 {
  let gx = activeGravitySwitchVector ? activeGravitySwitchVector[0] : baseGravity[0];
  let gy = activeGravitySwitchVector ? activeGravitySwitchVector[1] : baseGravity[1];
  let gz = activeGravitySwitchVector ? activeGravitySwitchVector[2] : baseGravity[2];

  for (const zone of zones) {
    if (!evaluateSignalCondition(zone.requiredSignals, signalMap, zone.logic)) {
      continue;
    }
    if (pointInBox(point, zone.position, zone.size)) {
      gx = zone.gravity[0];
      gy = zone.gravity[1];
      gz = zone.gravity[2];
    }
  }
  return [gx, gy, gz];
}

export function describeGravityLabel(gravity: Vec3): string | null {
  const [gx, gy, gz] = gravity;
  if (gy > 0.5) return 'Updraft Lift';
  if (gy > -12 && gy <= 0.5 && Math.abs(gx) < 2 && Math.abs(gz) < 2) return 'Low Gravity';
  if (Math.abs(gx) >= 4 || Math.abs(gz) >= 4) return 'Vector Shift';
  return null;
}

/**
 * Ray vs Axis-Aligned Bounding Box intersection distance fraction t in [0, 1] along segment [start, end].
 * Returns null if no hit.
 */
export function segmentAabbHitFraction(
  start: Vec3,
  end: Vec3,
  boxCenter: Vec3,
  boxHalfExtents: Vec3,
): number | null {
  const dx = end[0] - start[0];
  const dy = end[1] - start[1];
  const dz = end[2] - start[2];

  let tMin = 0;
  let tMax = 1;

  const axes: Array<[number, number, number, number]> = [
    [start[0], dx, boxCenter[0] - boxHalfExtents[0], boxCenter[0] + boxHalfExtents[0]],
    [start[1], dy, boxCenter[1] - boxHalfExtents[1], boxCenter[1] + boxHalfExtents[1]],
    [start[2], dz, boxCenter[2] - boxHalfExtents[2], boxCenter[2] + boxHalfExtents[2]],
  ];

  for (const [origin, dir, minB, maxB] of axes) {
    if (Math.abs(dir) < 1e-8) {
      if (origin < minB || origin > maxB) return null;
    } else {
      let t1 = (minB - origin) / dir;
      let t2 = (maxB - origin) / dir;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
      }
      tMin = Math.max(tMin, t1);
      tMax = Math.min(tMax, t2);
      if (tMin > tMax) return null;
    }
  }

  return tMin >= 0 && tMin <= 1 ? tMin : null;
}

/**
 * Distance from point to line segment [start, end] clipped to maxFraction in [0, 1].
 */
export function distancePointToSegment(
  point: Vec3,
  start: Vec3,
  end: Vec3,
  maxFraction = 1,
): number {
  const clampedFrac = Math.max(0, Math.min(1, maxFraction));
  const ex = start[0] + (end[0] - start[0]) * clampedFrac;
  const ey = start[1] + (end[1] - start[1]) * clampedFrac;
  const ez = start[2] + (end[2] - start[2]) * clampedFrac;

  const vx = ex - start[0];
  const vy = ey - start[1];
  const vz = ez - start[2];

  const wx = point[0] - start[0];
  const wy = point[1] - start[1];
  const wz = point[2] - start[2];

  const lenSq = vx * vx + vy * vy + vz * vz;
  if (lenSq < 1e-8) {
    return Math.hypot(wx, wy, wz);
  }
  const t = Math.max(0, Math.min(1, (wx * vx + wy * vy + wz * vz) / lenSq));
  const px = start[0] + vx * t;
  const py = start[1] + vy * t;
  const pz = start[2] + vz * t;
  return Math.hypot(point[0] - px, point[1] - py, point[2] - pz);
}

export interface LaserBlockerBox {
  center: Vec3;
  halfExtents: Vec3;
}

export interface LaserEvaluationResult {
  active: boolean;
  hitFraction: number;
  hitsPlayer: boolean;
}

export function evaluateLaserBeam(
  laser: LaserHazardDef,
  signalMap: Readonly<Record<string, boolean>>,
  elapsedTime: number,
  blockers: LaserBlockerBox[],
  playerPos: Vec3,
  playerRadius: number,
): LaserEvaluationResult {
  const disabled = laser.disableSignals && laser.disableSignals.length > 0
    ? evaluateSignalCondition(laser.disableSignals, signalMap, laser.logic)
    : false;

  if (disabled || !evaluateLaserCycle(laser, elapsedTime)) {
    return { active: false, hitFraction: 0, hitsPlayer: false };
  }

  let minFraction = 1;
  for (const box of blockers) {
    const frac = segmentAabbHitFraction(laser.start, laser.end, box.center, box.halfExtents);
    if (frac !== null && frac < minFraction) {
      minFraction = frac;
    }
  }

  const distToPlayer = distancePointToSegment(playerPos, laser.start, laser.end, minFraction);
  return {
    active: true,
    hitFraction: minFraction,
    hitsPlayer: distToPlayer <= playerRadius * 0.88,
  };
}

export function formatDuration(seconds: number): string {
  const safe = Math.max(0, Number.isFinite(seconds) ? seconds : 0);
  const mins = Math.floor(safe / 60);
  const secs = Math.floor(safe % 60);
  const tenths = Math.floor((safe - Math.floor(safe)) * 10);
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  return `${mm}:${ss}.${tenths}`;
}

export function validateLevelBlueprints(levels: LevelBlueprint[], expectedCount = 30): string[] {
  const errors: string[] = [];
  if (levels.length !== expectedCount) {
    errors.push(`Expected exactly ${expectedCount} levels, found ${levels.length}`);
  }

  const seenIds = new Set<number>();
  const seenSignatures = new Set<string>();

  for (const level of levels) {
    if (seenIds.has(level.id)) {
      errors.push(`Duplicate level ID: ${level.id}`);
    }
    seenIds.add(level.id);

    if (!level.title.trim()) errors.push(`Level ${level.id} missing title`);
    if (!level.objective.trim()) errors.push(`Level ${level.id} missing objective`);
    if (level.platforms.length === 0) errors.push(`Level ${level.id} has no platforms`);

    // Check spawn is not on top of portal
    const distSpawnPortal = Math.hypot(
      level.spawn[0] - level.portal.position[0],
      level.spawn[1] - level.portal.position[1],
      level.spawn[2] - level.portal.position[2],
    );
    if (distSpawnPortal < 4) {
      errors.push(`Level ${level.id} spawn is too close to exit portal (${distSpawnPortal.toFixed(2)}m)`);
    }

    // Collect valid signal IDs
    const validSignals = new Set<string>([
      ...level.switches.map((s) => s.id),
      ...level.pressurePlates.map((p) => p.id),
    ]);

    const checkSignalRefs = (owner: string, refs?: string[]) => {
      if (!refs) return;
      for (const ref of refs) {
        if (!validSignals.has(ref)) {
          errors.push(`Level ${level.id} ${owner} references unknown signal "${ref}"`);
        }
      }
    };

    checkSignalRefs('portal', level.portal.requiredSignals);
    for (const d of level.doors) checkSignalRefs(`door:${d.id}`, d.requiredSignals);
    for (const m of level.movingPlatforms) checkSignalRefs(`moving:${m.id}`, m.requiredSignals);
    for (const r of level.rotatingBridges) checkSignalRefs(`bridge:${r.id}`, r.requiredSignals);
    for (const g of level.gravityZones) checkSignalRefs(`gravity:${g.id}`, g.requiredSignals);
    for (const l of level.lasers) checkSignalRefs(`laser:${l.id}`, l.disableSignals);
    for (const obs of level.movingObstacles ?? []) {
      checkSignalRefs(`obstacle:${obs.id}`, obs.disableSignals);
    }

    // Validate breakable ice timing parameters
    for (const pl of level.platforms) {
      if (pl.breakable) {
        if (pl.breakable.collapseDelay <= 0 || pl.breakable.respawnDelay <= 0) {
          errors.push(`Level ${level.id} breakable platform "${pl.id}" has invalid timing`);
        }
      }
    }

    // Check geometry uniqueness so no duplicate layouts exist
    const sig = JSON.stringify({
      s: level.spawn,
      p: level.portal.position,
      pl: level.platforms.map((pl) => [pl.position, pl.size]),
      db: level.dynamicBodies.map((d) => [d.shape, d.position]),
    });
    if (seenSignatures.has(sig)) {
      errors.push(`Level ${level.id} duplicates layout signature of another level`);
    }
    seenSignatures.add(sig);
  }

  for (let i = 1; i <= expectedCount; i++) {
    if (!seenIds.has(i)) {
      errors.push(`Missing level ID ${i}`);
    }
  }

  return errors;
}

export type BreakableIcePhase = 'intact' | 'cracking' | 'collapsed';

export interface BreakableIceState {
  phase: BreakableIcePhase;
  timer: number;
}

/**
 * Pure state machine for World 5 breakable/collapsing ice platforms.
 */
export function stepBreakableIceState(
  current: BreakableIceState,
  triggered: boolean,
  dt: number,
  collapseDelay: number,
  respawnDelay: number,
): { next: BreakableIceState; startedCracking: boolean; justCollapsed: boolean; justReformed: boolean } {
  if (current.phase === 'intact') {
    if (triggered) {
      return {
        next: { phase: 'cracking', timer: collapseDelay },
        startedCracking: true,
        justCollapsed: false,
        justReformed: false,
      };
    }
    return { next: current, startedCracking: false, justCollapsed: false, justReformed: false };
  }

  if (current.phase === 'cracking') {
    const remaining = current.timer - dt;
    if (remaining <= 0) {
      return {
        next: { phase: 'collapsed', timer: respawnDelay },
        startedCracking: false,
        justCollapsed: true,
        justReformed: false,
      };
    }
    return {
      next: { phase: 'cracking', timer: remaining },
      startedCracking: false,
      justCollapsed: false,
      justReformed: false,
    };
  }

  // Collapsed -> reform after respawnDelay so puzzles never soft-lock
  const remaining = current.timer - dt;
  if (remaining <= 0) {
    return {
      next: { phase: 'intact', timer: 0 },
      startedCracking: false,
      justCollapsed: false,
      justReformed: true,
    };
  }
  return {
    next: { phase: 'collapsed', timer: remaining },
    startedCracking: false,
    justCollapsed: false,
    justReformed: false,
  };
}

/**
 * Sphere vs AABB hazard overlap check for molten lava pools & lethal moving furnace obstacles.
 */
export function evaluateLavaHazardOverlap(
  point: Vec3,
  radius: number,
  hazard: Pick<LavaHazardDef, 'position' | 'size'>,
): boolean {
  const hx = hazard.size[0] * 0.5;
  const hy = hazard.size[1] * 0.5;
  const hz = hazard.size[2] * 0.5;

  const clampedX = Math.max(hazard.position[0] - hx, Math.min(hazard.position[0] + hx, point[0]));
  const clampedY = Math.max(hazard.position[1] - hy, Math.min(hazard.position[1] + hy, point[1]));
  const clampedZ = Math.max(hazard.position[2] - hz, Math.min(hazard.position[2] + hz, point[2]));

  const dx = point[0] - clampedX;
  const dy = point[1] - clampedY;
  const dz = point[2] - clampedZ;
  const r = Math.max(0.05, radius * 0.84);
  return dx * dx + dy * dy + dz * dz <= r * r;
}

export interface JoystickVector {
  offsetX: number;
  offsetY: number;
  normX: number;
  normY: number;
}

export interface JoystickPointerState {
  pointerId: number | null;
  active: boolean;
  centerX: number;
  centerY: number;
  offsetX: number;
  offsetY: number;
  normX: number;
  normY: number;
}

export function createNeutralJoystickState(): JoystickPointerState {
  return {
    pointerId: null,
    active: false,
    centerX: 0,
    centerY: 0,
    offsetX: 0,
    offsetY: 0,
    normX: 0,
    normY: 0,
  };
}

/**
 * Computes clamped pixel offset and normalized [-1, 1] movement axes for the virtual joystick.
 * Uses direct vector scaling (no atan2/cos/sin drift) so orthogonal drags stay exact.
 */
export function computeJoystickOutput(
  clientX: number,
  clientY: number,
  centerX: number,
  centerY: number,
  maxRadius: number,
): JoystickVector {
  if (
    !Number.isFinite(clientX) ||
    !Number.isFinite(clientY) ||
    !Number.isFinite(centerX) ||
    !Number.isFinite(centerY) ||
    !Number.isFinite(maxRadius) ||
    maxRadius <= 0
  ) {
    return { offsetX: 0, offsetY: 0, normX: 0, normY: 0 };
  }

  const dx = clientX - centerX;
  const dy = clientY - centerY;
  const dist = Math.hypot(dx, dy);

  if (dist < 1e-6) {
    return { offsetX: 0, offsetY: 0, normX: 0, normY: 0 };
  }

  const scale = dist > maxRadius ? maxRadius / dist : 1;
  const offsetX = dx * scale;
  const offsetY = dy * scale;
  return {
    offsetX,
    offsetY,
    normX: Math.max(-1, Math.min(1, offsetX / maxRadius)),
    normY: Math.max(-1, Math.min(1, offsetY / maxRadius)),
  };
}

export function joystickPointerDown(
  state: JoystickPointerState,
  pointerId: number,
  clientX: number,
  clientY: number,
  centerX: number,
  centerY: number,
  maxRadius: number,
): JoystickPointerState {
  if (state.pointerId !== null) {
    return state;
  }
  const vec = computeJoystickOutput(clientX, clientY, centerX, centerY, maxRadius);
  return {
    pointerId,
    active: true,
    centerX,
    centerY,
    ...vec,
  };
}

export function joystickPointerMove(
  state: JoystickPointerState,
  pointerId: number,
  clientX: number,
  clientY: number,
  maxRadius: number,
): JoystickPointerState {
  if (state.pointerId !== pointerId) {
    return state;
  }
  const vec = computeJoystickOutput(clientX, clientY, state.centerX, state.centerY, maxRadius);
  return {
    ...state,
    ...vec,
  };
}

export function joystickPointerEnd(
  state: JoystickPointerState,
  pointerId: number,
): JoystickPointerState {
  if (state.pointerId !== pointerId) {
    return state;
  }
  return createNeutralJoystickState();
}

export function joystickForceReset(): JoystickPointerState {
  return createNeutralJoystickState();
}

