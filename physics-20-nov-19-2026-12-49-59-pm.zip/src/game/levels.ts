import { EXPANSION_LEVELS } from './expansionLevels';
import type {
  DoorDef,
  LevelBlueprint,
  PlatformDef,
  SurfaceStyle,
  Vec3,
} from './types';

function floor(
  id: string,
  x: number,
  topY: number,
  z: number,
  w: number,
  d: number,
  h = 1.2,
  style: SurfaceStyle = 'stone',
  extra: Partial<PlatformDef> = {},
): PlatformDef {
  return {
    id,
    position: [x, topY - h * 0.5, z],
    size: [w, h, d],
    style,
    ...extra,
  };
}

function wall(
  id: string,
  x: number,
  baseY: number,
  z: number,
  w: number,
  height: number,
  d: number,
  style: SurfaceStyle = 'stone',
): PlatformDef {
  return {
    id,
    position: [x, baseY + height * 0.5, z],
    size: [w, height, d],
    style,
  };
}

function framedGateZ(
  id: string,
  x: number,
  baseY: number,
  z: number,
  totalWidth: number,
  openingWidth: number,
  height: number,
  depth: number,
  requiredSignals: string[],
  logic: 'AND' | 'OR' = 'AND',
): { walls: PlatformDef[]; door: DoorDef } {
  const sideWidth = Math.max(0.8, (totalWidth - openingWidth) * 0.5);
  const sideOffset = openingWidth * 0.5 + sideWidth * 0.5;
  const walls: PlatformDef[] = [
    wall(`${id}_jambL`, x - sideOffset, baseY, z, sideWidth, height + 0.6, depth, 'stone'),
    wall(`${id}_jambR`, x + sideOffset, baseY, z, sideWidth, height + 0.6, depth, 'stone'),
    wall(`${id}_lintel`, x, baseY + height, z, totalWidth, 0.7, depth + 0.2, 'trim'),
  ];
  const door: DoorDef = {
    id,
    position: [x, baseY + height * 0.5, z],
    size: [openingWidth, height, depth * 0.55],
    openOffset: [0, height + 0.2, 0],
    requiredSignals,
    logic,
  };
  return { walls, door };
}

function framedGateX(
  id: string,
  x: number,
  baseY: number,
  z: number,
  totalDepth: number,
  openingDepth: number,
  height: number,
  thickness: number,
  requiredSignals: string[],
  logic: 'AND' | 'OR' = 'AND',
): { walls: PlatformDef[]; door: DoorDef } {
  const sideDepth = Math.max(0.8, (totalDepth - openingDepth) * 0.5);
  const sideOffset = openingDepth * 0.5 + sideDepth * 0.5;
  const walls: PlatformDef[] = [
    wall(`${id}_jambN`, x, baseY, z - sideOffset, thickness, height + 0.6, sideDepth, 'stone'),
    wall(`${id}_jambS`, x, baseY, z + sideOffset, thickness, height + 0.6, sideDepth, 'stone'),
    wall(`${id}_lintel`, x, baseY + height, z, thickness + 0.2, 0.7, totalDepth, 'trim'),
  ];
  const door: DoorDef = {
    id,
    position: [x, baseY + height * 0.5, z],
    size: [openingDepth, height, thickness * 0.55],
    openOffset: [0, height + 0.2, 0],
    requiredSignals,
    logic,
    rotationY: Math.PI * 0.5,
  };
  return { walls, door };
}

function buildLevels(): LevelBlueprint[] {
  // =========================================================================
  // TIER 1: FOUNDATION (Levels 1 - 4)
  // =========================================================================

  // LEVEL 1: First Impulse — Push/grab cube as step to upper terrace & toggle switch to open exit gate
  const l1Gate = framedGateZ('l1_door', 0, 2.4, -14.5, 11, 3.6, 3.4, 1.0, ['l1_sw1']);
  const level1: LevelBlueprint = {
    id: 1,
    title: 'First Impulse',
    tier: 'foundation',
    objective: 'Move the kinetic cube to reach the upper terrace, activate the switch, and enter the portal.',
    spawn: [0, 0.9, 8],
    spawnYaw: 0,
    portal: { position: [0, 2.4, -20.5] },
    fallY: -10,
    parTime: 30,
    platforms: [
      floor('l1_main', 0, 0, 2, 12, 16, 1.6, 'stone'),
      floor('l1_upper', 0, 2.4, -14, 11, 16, 4.0, 'stone'),
      // Low curb trim guiding the cube toward the step
      floor('l1_guide', 0, 0.04, -3.5, 3.2, 6.0, 0.08, 'trim'),
      // Flanking architectural parapet walls
      wall('l1_parL', -5.7, 0, 2, 0.6, 1.1, 16, 'trim'),
      wall('l1_parR', 5.7, 0, 2, 0.6, 1.1, 16, 'trim'),
      ...l1Gate.walls,
    ],
    dynamicBodies: [
      {
        id: 'l1_cube1',
        shape: 'cube',
        position: [-2.4, 0.7, 2.5],
        size: [1.35, 1.35, 1.35],
        mass: 3.2,
        friction: 0.65,
        grabbable: true,
      },
    ],
    switches: [
      {
        id: 'l1_sw1',
        position: [3.2, 2.4, -11.2],
        kind: 'toggle',
        label: 'Gate Conduit',
      },
    ],
    pressurePlates: [],
    doors: [l1Gate.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [],
  };

  // LEVEL 2: Counterweight — Push heavy cube down ramp onto recessed pressure plate to open blast door
  const l2Gate = framedGateZ('l2_door', 0, 0, -11, 12, 3.8, 3.6, 1.1, ['l2_plate1']);
  const level2: LevelBlueprint = {
    id: 2,
    title: 'Counterweight',
    tier: 'foundation',
    objective: 'Guide the heavy monolith cube onto the pressure plate to unlock the exit vault.',
    spawn: [0, 0.9, 10],
    spawnYaw: 0,
    portal: { position: [0, 1.6, -21] },
    fallY: -10,
    parTime: 35,
    platforms: [
      floor('l2_court', 0, 0, 1, 12, 24, 1.6, 'stone'),
      // Elevated side shelf holding the counterweight block
      floor('l2_shelf', -7.2, 1.8, 2, 4.4, 7.0, 3.4, 'stone'),
      // Smooth ramp connecting shelf down to main court
      {
        id: 'l2_ramp',
        position: [-3.9, 0.82, 2],
        size: [3.6, 0.5, 4.2],
        rotation: [0, 0, -0.44],
        style: 'metal',
        friction: 0.35,
      },
      // Exit sanctuary terrace beyond door
      floor('l2_sanctuary', 0, 0, -14.5, 10, 6, 1.6, 'stone'),
      floor('l2_step1', 0, 0.8, -17.5, 8, 2.4, 1.6, 'trim'),
      floor('l2_portalDeck', 0, 1.6, -21, 9, 6, 3.2, 'stone'),
      ...l2Gate.walls,
    ],
    dynamicBodies: [
      {
        id: 'l2_heavy',
        shape: 'heavyCube',
        position: [-7.2, 2.6, 2.0],
        size: [1.45, 1.45, 1.45],
        mass: 5.5,
        friction: 0.55,
        grabbable: true,
      },
    ],
    switches: [],
    pressurePlates: [
      {
        id: 'l2_plate1',
        position: [3.4, 0, -6.5],
        size: [2.3, 2.3],
        minWeight: 2.5,
        requiresBlock: true,
      },
    ],
    doors: [l2Gate.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [],
  };

  // LEVEL 3: Kinetic Momentum — Build speed down an inclined runway, leap chasm, roll sphere into cradle
  const l3Gate = framedGateZ('l3_door', 0, 0, -24, 10, 3.6, 3.4, 1.0, ['l3_plate1']);
  const level3: LevelBlueprint = {
    id: 3,
    title: 'Kinetic Momentum',
    tier: 'foundation',
    objective: 'Build speed across the momentum track, cross the chasm, and roll the sphere onto the lock plate.',
    spawn: [0, 3.9, 14],
    spawnYaw: 0,
    portal: { position: [0, 0, -31] },
    fallY: -12,
    parTime: 40,
    platforms: [
      floor('l3_start', 0, 3.0, 13, 8, 6, 2.0, 'stone'),
      // Steep downhill metallic momentum ramp
      {
        id: 'l3_downRamp',
        position: [0, 1.4, 4.5],
        size: [5.2, 0.6, 12.2],
        rotation: [0.25, 0, 0],
        style: 'ice',
        friction: 0.12,
      },
      // Launch lip
      {
        id: 'l3_launch',
        position: [0, 0.2, -3.0],
        size: [5.2, 0.6, 4.0],
        rotation: [-0.14, 0, 0],
        style: 'metal',
        friction: 0.15,
      },
      // Landing deck across a 4.4m gap
      floor('l3_mid', 0, 0, -16, 11, 16, 1.8, 'stone'),
      // Side walls on mid deck so rolling sphere doesn't fall off easily
      wall('l3_railL', -5.2, 0, -16, 0.6, 1.2, 16, 'trim'),
      wall('l3_railR', 5.2, 0, -16, 0.6, 1.2, 16, 'trim'),
      // Exit deck
      floor('l3_exit', 0, 0, -29.5, 10, 10, 1.8, 'stone'),
      ...l3Gate.walls,
    ],
    dynamicBodies: [
      {
        id: 'l3_sphere',
        shape: 'sphere',
        position: [-2.6, 1.0, -12.5],
        size: [1.4, 1.4, 1.4],
        mass: 3.5,
        friction: 0.35,
        restitution: 0.4,
        grabbable: true,
      },
    ],
    switches: [],
    pressurePlates: [
      {
        id: 'l3_plate1',
        position: [2.8, 0, -20.0],
        size: [2.3, 2.3],
        minWeight: 2.0,
        requiresBlock: true,
      },
    ],
    doors: [l3Gate.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l3_cp', position: [0, 0, -9.8] }],
  };

  // LEVEL 4: Twin Conduits — Dual mechanical switches deploy a bridge and open the vault door
  const l4Gate = framedGateZ('l4_door', 0, 1.2, -17, 10, 3.6, 3.4, 1.0, ['l4_sw1', 'l4_sw2']);
  const level4: LevelBlueprint = {
    id: 4,
    title: 'Twin Conduits',
    tier: 'foundation',
    objective: 'Activate both flanking conduit switches to deploy the bridge and unseal the chamber gate.',
    spawn: [0, 0.9, 10],
    spawnYaw: 0,
    portal: { position: [0, 1.2, -23.5] },
    fallY: -10,
    parTime: 40,
    platforms: [
      floor('l4_hub', 0, 0, 6, 10, 12, 1.6, 'stone'),
      // West wing
      floor('l4_westBridge', -7.5, 0, 4, 6, 3.2, 1.0, 'metal'),
      floor('l4_westPad', -12.5, 0.9, 4, 5.5, 6.0, 2.4, 'stone'),
      // East wing
      floor('l4_eastBridge', 7.5, 0, 4, 6, 3.2, 1.0, 'metal'),
      floor('l4_eastPad', 12.5, 0.9, 4, 5.5, 6.0, 2.4, 'stone'),
      // Northern exit sanctuary (reachable via extending moving bridge triggered by sw1)
      floor('l4_north', 0, 1.2, -16, 10, 18, 2.8, 'stone'),
      ...l4Gate.walls,
    ],
    dynamicBodies: [],
    switches: [
      { id: 'l4_sw1', position: [-12.5, 0.9, 4], kind: 'toggle', label: 'West Conduit' },
      { id: 'l4_sw2', position: [12.5, 0.9, 4], kind: 'toggle', label: 'East Conduit' },
    ],
    pressurePlates: [],
    doors: [l4Gate.door],
    movingPlatforms: [
      {
        id: 'l4_bridge',
        startPos: [0, -3.0, -3.5],
        endPos: [0, 0.4, -3.5],
        size: [4.2, 0.8, 7.6],
        speed: 3.2,
        requiredSignals: ['l4_sw1', 'l4_sw2'],
        logic: 'OR',
        style: 'metal',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [],
  };

  // =========================================================================
  // TIER 2: INTERMEDIATE (Levels 5 - 8)
  // =========================================================================

  // LEVEL 5: Twin Plates — Two distinct weight sockets (cube + sphere) unlocking a dual-lock door
  const l5Gate = framedGateZ('l5_door', 0, 0, -15, 14, 4.0, 3.6, 1.1, ['l5_p1', 'l5_p2']);
  const level5: LevelBlueprint = {
    id: 5,
    title: 'Twin Plates',
    tier: 'intermediate',
    objective: 'Place both kinetic weights on the recessed pressure plates to unlock the twin-seal gate.',
    spawn: [0, 0.9, 11],
    spawnYaw: 0,
    portal: { position: [0, 0.8, -23] },
    fallY: -10,
    parTime: 50,
    platforms: [
      floor('l5_hall', 0, 0, -1, 14, 28, 1.6, 'stone'),
      // Central low divider wall with gap so player navigates both sides
      wall('l5_div', 0, 0, 0, 0.8, 1.8, 9.0, 'trim'),
      // Raised pedestal on west for cube
      floor('l5_westPed', -4.8, 1.1, 4.5, 3.6, 3.6, 2.2, 'stone'),
      // Exit sanctuary
      floor('l5_exit', 0, 0.8, -21, 10, 11, 2.4, 'stone'),
      ...l5Gate.walls,
    ],
    dynamicBodies: [
      {
        id: 'l5_cube',
        shape: 'cube',
        position: [-4.8, 2.0, 4.5],
        size: [1.35, 1.35, 1.35],
        mass: 3.4,
        grabbable: true,
      },
      {
        id: 'l5_sphere',
        shape: 'sphere',
        position: [4.6, 0.9, 5.5],
        size: [1.4, 1.4, 1.4],
        mass: 3.2,
        friction: 0.4,
        restitution: 0.35,
        grabbable: true,
      },
    ],
    switches: [],
    pressurePlates: [
      { id: 'l5_p1', position: [-4.2, 0, -10.5], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
      { id: 'l5_p2', position: [4.2, 0, -10.5], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l5Gate.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [],
  };

  // LEVEL 6: Skyward Shuttle — Ride horizontal shuttle across void, activate vertical elevator to upper portal
  const level6: LevelBlueprint = {
    id: 6,
    title: 'Skyward Shuttle',
    tier: 'intermediate',
    objective: 'Ride the horizontal shuttle across the abyss and power the vertical elevator to the upper sanctuary.',
    spawn: [0, 0.9, 13],
    spawnYaw: 0,
    portal: { position: [0, 7.2, -23] },
    fallY: -12,
    parTime: 48,
    platforms: [
      floor('l6_start', 0, 0, 12, 9, 8, 1.8, 'stone'),
      floor('l6_mid', 0, 0, -8, 10, 9, 1.8, 'stone'),
      // Upper portal deck reachable from elevator
      floor('l6_upper', 0, 7.2, -21, 10, 10, 2.0, 'stone'),
      wall('l6_guardL', -4.7, 7.2, -21, 0.6, 1.2, 10, 'trim'),
      wall('l6_guardR', 4.7, 7.2, -21, 0.6, 1.2, 10, 'trim'),
    ],
    dynamicBodies: [],
    switches: [
      { id: 'l6_elevSw', position: [3.2, 0, -8], kind: 'toggle', label: 'Elevator Drive' },
    ],
    pressurePlates: [],
    doors: [],
    movingPlatforms: [
      {
        id: 'l6_shuttle',
        startPos: [0, -0.45, 5.5],
        endPos: [0, -0.45, -1.5],
        size: [4.2, 0.9, 4.2],
        speed: 2.6,
        pauseAtEnds: 1.0,
        style: 'metal',
      },
      {
        id: 'l6_elevator',
        startPos: [0, -0.45, -14.2],
        endPos: [0, 6.75, -14.2],
        size: [4.4, 0.9, 4.4],
        speed: 3.0,
        requiredSignals: ['l6_elevSw'],
        pauseAtEnds: 1.4,
        style: 'accent',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l6_cp', position: [-2.8, 0, -8] }],
  };

  // LEVEL 7: Pivot Span — Control a rotating bridge to fetch a cube from the east island and unlock north portal
  const l7Gate = framedGateZ('l7_door', 0, 0, -13.5, 9, 3.6, 3.4, 1.0, ['l7_plate']);
  const level7: LevelBlueprint = {
    id: 7,
    title: 'Pivot Span',
    tier: 'intermediate',
    objective: 'Rotate the central bridge to retrieve the cube from the east island, place it on the north plate, and cross.',
    spawn: [0, 0.9, 13],
    spawnYaw: 0,
    portal: { position: [0, 0, -19.5] },
    fallY: -12,
    parTime: 60,
    platforms: [
      floor('l7_south', 0, 0, 12.5, 9, 7, 1.8, 'stone'),
      floor('l7_center', 0, 0, 0, 5.2, 5.2, 2.2, 'trim'),
      floor('l7_east', 13, 0, 0, 7.5, 7.5, 1.8, 'stone'),
      floor('l7_west', -13, 0, 0, 7.5, 7.5, 1.8, 'stone'),
      floor('l7_north', 0, 0, -15.5, 9, 13, 1.8, 'stone'),
      ...l7Gate.walls,
    ],
    dynamicBodies: [
      {
        id: 'l7_cube',
        shape: 'cube',
        position: [13.5, 0.85, 0],
        size: [1.35, 1.35, 1.35],
        mass: 3.0,
        grabbable: true,
      },
    ],
    switches: [
      { id: 'l7_rotSw', position: [-3.0, 0, 10.6], kind: 'toggle', label: 'Rotate Bridge' },
      { id: 'l7_rotSw2', position: [10.4, 0, 2.4], kind: 'toggle', label: 'Rotate Bridge' },
    ],
    pressurePlates: [
      { id: 'l7_plate', position: [-13, 0, 0], size: [2.4, 2.4], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l7Gate.door],
    movingPlatforms: [],
    rotatingBridges: [
      {
        id: 'l7_bridge',
        pivot: [0, -0.35, 0],
        size: [3.6, 0.7, 19.2],
        restAngleY: 0, // Connects South <-> North
        activeAngleY: Math.PI * 0.5, // Connects West <-> East
        speed: 1.4,
        requiredSignals: ['l7_rotSw', 'l7_rotSw2'],
        logic: 'OR',
      },
    ],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l7_cp', position: [0, 0, 0] }],
  };

  // LEVEL 8: Cascade Vault — Carry a kinetic block onto an elevator to unlock the elevated vault door
  const l8Gate = framedGateZ('l8_door', 0, 5.2, -16, 11, 3.8, 3.5, 1.1, ['l8_plateUp']);
  const level8: LevelBlueprint = {
    id: 8,
    title: 'Cascade Vault',
    tier: 'intermediate',
    objective: 'Load a kinetic cube onto the elevator, ascend to the upper vault, and weight the upper lock plate.',
    spawn: [0, 0.9, 12],
    spawnYaw: 0,
    portal: { position: [0, 5.2, -22.5] },
    fallY: -12,
    parTime: 65,
    platforms: [
      floor('l8_lower', 0, 0, 7, 13, 14, 1.8, 'stone'),
      // Recessed side alcove holding a secondary cube
      floor('l8_upper', 0, 5.2, -14.5, 11, 20, 2.2, 'stone'),
      wall('l8_uWallL', -5.2, 5.2, -14.5, 0.6, 1.2, 20, 'trim'),
      wall('l8_uWallR', 5.2, 5.2, -14.5, 0.6, 1.2, 20, 'trim'),
      ...l8Gate.walls,
    ],
    dynamicBodies: [
      {
        id: 'l8_cube1',
        shape: 'cube',
        position: [-3.8, 0.85, 6.5],
        size: [1.35, 1.35, 1.35],
        mass: 3.0,
        grabbable: true,
      },
      {
        id: 'l8_cube2',
        shape: 'heavyCube',
        position: [3.8, 0.85, 6.5],
        size: [1.4, 1.4, 1.4],
        mass: 4.5,
        grabbable: true,
      },
    ],
    switches: [],
    pressurePlates: [
      { id: 'l8_plateLow', position: [-4.2, 0, 2.2], size: [2.2, 2.2], minWeight: 2.0, requiresBlock: true },
      { id: 'l8_plateUp', position: [3.4, 5.2, -11.5], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l8Gate.door],
    movingPlatforms: [
      {
        id: 'l8_lift',
        startPos: [0, -0.45, -2.2],
        endPos: [0, 4.75, -2.2],
        size: [4.8, 0.9, 4.8],
        speed: 2.6,
        requiredSignals: ['l8_plateLow'],
        pauseAtEnds: 1.8,
        style: 'accent',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l8_cp', position: [-3.2, 5.2, -6.5] }],
  };

  // =========================================================================
  // TIER 3: ADVANCED (Levels 9 - 12)
  // =========================================================================

  // LEVEL 9: Interlocked Circuit — Chain door 1 -> retrieve cube -> hold plate -> bridge to exit door 2
  const l9Door1 = framedGateX('l9_d1', -6.2, 0, 2, 10, 3.6, 3.4, 1.0, ['l9_sw1']);
  const l9Door2 = framedGateZ('l9_d2', 0, 0, -18, 10, 3.6, 3.4, 1.0, ['l9_plate1', 'l9_sw2']);
  const level9: LevelBlueprint = {
    id: 9,
    title: 'Interlocked Circuit',
    tier: 'advanced',
    objective: 'Unlock the west vault for the cube, anchor the central plate, and engage the exit circuit.',
    spawn: [0, 0.9, 11],
    spawnYaw: 0,
    portal: { position: [0, 0, -24.5] },
    fallY: -12,
    parTime: 70,
    platforms: [
      floor('l9_hub', 0, 0, 4, 12.4, 18, 1.8, 'stone'),
      floor('l9_westVault', -10.5, 0, 2, 8.6, 10, 1.8, 'stone'),
      floor('l9_eastAlcove', 10.5, 0, 2, 8.6, 10, 1.8, 'stone'),
      floor('l9_north', 0, 0, -20.5, 10, 13, 1.8, 'stone'),
      ...l9Door1.walls,
      ...l9Door2.walls,
    ],
    dynamicBodies: [
      {
        id: 'l9_cube',
        shape: 'cube',
        position: [-11.5, 0.85, 2],
        size: [1.35, 1.35, 1.35],
        mass: 3.2,
        grabbable: true,
      },
    ],
    switches: [
      { id: 'l9_sw1', position: [10.5, 0, 2], kind: 'toggle', label: 'West Vault' },
      { id: 'l9_sw2', position: [-3.2, 0, -15.2], kind: 'toggle', label: 'Inner Lock' },
    ],
    pressurePlates: [
      { id: 'l9_plate1', position: [0, 0, -3.0], size: [2.4, 2.4], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l9Door1.door, l9Door2.door],
    movingPlatforms: [
      {
        id: 'l9_shuttle',
        startPos: [0, -0.45, -7.2],
        endPos: [0, -0.45, -11.8],
        size: [4.2, 0.9, 4.4],
        speed: 3.0,
        requiredSignals: ['l9_plate1'],
        pauseAtEnds: 1.0,
        style: 'metal',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l9_cp', position: [3.0, 0, -15.2] }],
  };

  // LEVEL 10: Low-G Spire — Vertical ascent using localized low-gravity uplift shafts & elevated plate
  const l10Gate = framedGateZ('l10_door', 0, 10.5, -19, 10, 3.6, 3.4, 1.0, ['l10_plateTop']);
  const level10: LevelBlueprint = {
    id: 10,
    title: 'Low-G Spire',
    tier: 'advanced',
    objective: 'Ride the cyan low-gravity columns to ascend the spire and weight the summit plate.',
    spawn: [0, 0.9, 10],
    spawnYaw: 0,
    portal: { position: [0, 10.5, -25] },
    fallY: -12,
    parTime: 65,
    platforms: [
      floor('l10_base', 0, 0, 6, 11, 12, 1.8, 'stone'),
      // Mid balcony at y = 5.2
      floor('l10_mid', 0, 5.2, -3.5, 11, 8, 1.6, 'stone'),
      // Summit deck at y = 10.5
      floor('l10_top', 0, 10.5, -18, 10, 18, 2.0, 'stone'),
      wall('l10_wL', -4.8, 10.5, -18, 0.5, 1.1, 18, 'trim'),
      wall('l10_wR', 4.8, 10.5, -18, 0.5, 1.1, 18, 'trim'),
      ...l10Gate.walls,
    ],
    dynamicBodies: [
      {
        id: 'l10_lightCube',
        shape: 'cube',
        position: [-3.2, 6.0, -3.5],
        size: [1.3, 1.3, 1.3],
        mass: 2.2,
        grabbable: true,
      },
    ],
    switches: [
      { id: 'l10_upSw', position: [3.5, 5.2, -3.5], kind: 'toggle', label: 'Summit Updraft' },
    ],
    pressurePlates: [
      { id: 'l10_plateTop', position: [-3.0, 10.5, -15.5], size: [2.3, 2.3], minWeight: 1.5, requiresBlock: true },
    ],
    doors: [l10Gate.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [
      {
        id: 'l10_gz1',
        position: [0, 3.6, 1.6],
        size: [4.2, 7.2, 4.2],
        gravity: [0, 7.5, 0], // Updraft column to y=5.2
      },
      {
        id: 'l10_gz2',
        position: [0, 8.6, -8.5],
        size: [4.4, 7.4, 4.4],
        gravity: [0, 8.0, 0], // Activated updraft to y=10.5
        requiredSignals: ['l10_upSw'],
      },
    ],
    lasers: [],
    checkpoints: [{ id: 'l10_cp', position: [0, 5.2, -5.5] }],
  };

  // LEVEL 11: Chronos Run — Timed switches drive retractable bridges and timed exit blast door
  const l11Door = framedGateZ('l11_door', 0, 0, -29, 10, 3.8, 3.5, 1.0, ['l11_timer2']);
  const level11: LevelBlueprint = {
    id: 11,
    title: 'Chronos Run',
    tier: 'advanced',
    objective: 'Trigger the timed chrono-switches and cross each mechanism before the countdown expires.',
    spawn: [0, 0.9, 10],
    spawnYaw: 0,
    portal: { position: [0, 0, -35.5] },
    fallY: -12,
    parTime: 55,
    platforms: [
      floor('l11_start', 0, 0, 7, 10, 10, 1.8, 'stone'),
      floor('l11_mid', 0, 0, -11, 10, 12, 1.8, 'stone'),
      floor('l11_end', 0, 0, -30, 10, 16, 1.8, 'stone'),
      ...l11Door.walls,
    ],
    dynamicBodies: [],
    switches: [
      { id: 'l11_timer1', position: [2.8, 0, 4.2], kind: 'timed', duration: 9.0, label: 'Chrono Bridge' },
      { id: 'l11_timer2', position: [-2.8, 0, -14.0], kind: 'timed', duration: 8.5, label: 'Chrono Gate' },
    ],
    pressurePlates: [],
    doors: [l11Door.door],
    movingPlatforms: [
      {
        id: 'l11_bridge1',
        startPos: [0, -3.5, -1.5],
        endPos: [0, -0.4, -1.5],
        size: [4.0, 0.8, 7.6],
        speed: 6.5,
        requiredSignals: ['l11_timer1'],
        style: 'accent',
      },
      {
        id: 'l11_bridge2',
        startPos: [0, -3.5, -19.5],
        endPos: [0, -0.4, -19.5],
        size: [4.0, 0.8, 5.8],
        speed: 6.5,
        requiredSignals: ['l11_timer2'],
        style: 'accent',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l11_cp', position: [0, 0, -8.5] }],
  };

  // LEVEL 12: Precision Fulcrum — Position elongated stone slab across chasm, roll sphere onto lock plate
  const l12Door = framedGateZ('l12_door', 0, 0, -19, 10, 3.6, 3.4, 1.0, ['l12_plate']);
  const level12: LevelBlueprint = {
    id: 12,
    title: 'Precision Fulcrum',
    tier: 'advanced',
    objective: 'Bridge the central trench with the metallic slab and guide the sphere to the far lock plate.',
    spawn: [0, 0.9, 12],
    spawnYaw: 0,
    portal: { position: [0, 0, -25.5] },
    fallY: -12,
    parTime: 65,
    platforms: [
      floor('l12_south', 0, 0, 6.5, 12, 13, 1.8, 'stone'),
      // Narrow stepped center pier
      floor('l12_pier', 0, 0, -2.5, 2.4, 2.2, 1.8, 'trim'),
      // North hall across a 5.5m trench
      floor('l12_north', 0, 0, -15.5, 11, 20, 1.8, 'stone'),
      wall('l12_nL', -5.2, 0, -15.5, 0.6, 1.2, 20, 'trim'),
      wall('l12_nR', 5.2, 0, -15.5, 0.6, 1.2, 20, 'trim'),
      ...l12Door.walls,
    ],
    dynamicBodies: [
      {
        id: 'l12_slab',
        shape: 'slab',
        position: [-3.4, 0.6, 4.5],
        size: [2.2, 0.45, 5.2],
        mass: 3.8,
        friction: 0.75,
        grabbable: true,
      },
      {
        id: 'l12_sphere',
        shape: 'sphere',
        position: [3.6, 0.9, 5.0],
        size: [1.35, 1.35, 1.35],
        mass: 2.8,
        friction: 0.4,
        grabbable: true,
      },
    ],
    switches: [],
    pressurePlates: [
      { id: 'l12_plate', position: [3.2, 0, -14.5], size: [2.4, 2.4], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l12Door.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l12_cp', position: [-3.0, 0, -8.5] }],
  };

  // =========================================================================
  // TIER 4: EXPERT (Levels 13 - 16)
  // =========================================================================

  // LEVEL 13: Vector Shift — Global gravity switch shifts chamber into low-G moon physics to scale canyon tiers
  const l13Door = framedGateZ('l13_door', 0, 7.8, -24, 10, 3.8, 3.4, 1.0, ['l13_plate']);
  const level13: LevelBlueprint = {
    id: 13,
    title: 'Vector Shift',
    tier: 'expert',
    objective: 'Engage the Gravity Vector Console to lower gravity, leap the monolith tiers, and unlock the high gate.',
    spawn: [0, 0.9, 11],
    spawnYaw: 0,
    portal: { position: [0, 7.8, -30] },
    fallY: -12,
    parTime: 65,
    platforms: [
      floor('l13_tier0', 0, 0, 7, 10, 12, 1.8, 'stone'),
      floor('l13_tier1', -4.0, 3.8, -3, 7, 7, 1.8, 'stone'),
      floor('l13_tier2', 4.0, 7.6, -12, 7, 7, 1.8, 'stone'),
      floor('l13_top', 0, 7.8, -23.5, 10, 17, 2.0, 'stone'),
      ...l13Door.walls,
    ],
    dynamicBodies: [
      {
        id: 'l13_cube',
        shape: 'cube',
        position: [4.0, 8.6, -12],
        size: [1.3, 1.3, 1.3],
        mass: 2.4,
        grabbable: true,
      },
    ],
    switches: [
      {
        id: 'l13_gravSw',
        position: [3.2, 0, 4.5],
        kind: 'gravity',
        gravityVector: [0, -7.2, 0], // Low-G leap height ~6.4m!
        label: 'Low-G Vector',
      },
    ],
    pressurePlates: [
      { id: 'l13_plate', position: [-3.0, 7.8, -20.5], size: [2.3, 2.3], minWeight: 1.8, requiresBlock: true },
    ],
    doors: [l13Door.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [{ id: 'l13_cp', position: [-4.0, 3.8, -3] }],
  };

  // LEVEL 14: Crimson Interception — Physically block lethal laser beams using opaque shield cubes
  const level14: LevelBlueprint = {
    id: 14,
    title: 'Crimson Interception',
    tier: 'expert',
    objective: 'Position the metallic shield cubes to intercept the crimson laser beams and reach the portal.',
    spawn: [0, 0.9, 13],
    spawnYaw: 0,
    portal: { position: [0, 0, -22], requiredSignals: ['l14_sw'] },
    fallY: -10,
    parTime: 65,
    platforms: [
      floor('l14_hall', 0, 0, -4, 12, 39, 1.8, 'stone'),
      wall('l14_wL', -5.7, 0, -4, 0.6, 2.8, 39, 'stone'),
      wall('l14_wR', 5.7, 0, -4, 0.6, 2.8, 39, 'stone'),
    ],
    dynamicBodies: [
      {
        id: 'l14_shield1',
        shape: 'heavyCube',
        position: [-3.2, 0.9, 7.0],
        size: [1.55, 1.65, 1.55],
        mass: 4.0,
        grabbable: true,
        blocksLaser: true,
      },
      {
        id: 'l14_shield2',
        shape: 'heavyCube',
        position: [3.2, 0.9, -4.5],
        size: [1.55, 1.65, 1.55],
        mass: 4.0,
        grabbable: true,
        blocksLaser: true,
      },
    ],
    switches: [
      { id: 'l14_sw', position: [0, 0, -16.5], kind: 'toggle', label: 'Portal Conduit' },
    ],
    pressurePlates: [],
    doors: [],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [
      {
        id: 'l14_las1',
        start: [-5.3, 0.85, 2.5],
        end: [5.3, 0.85, 2.5],
      },
      {
        id: 'l14_las2',
        start: [5.3, 0.85, -10.5],
        end: [-5.3, 0.85, -10.5],
      },
      {
        id: 'l14_las3',
        start: [-5.3, 0.85, -19.2],
        end: [5.3, 0.85, -19.2],
        disableSignals: ['l14_sw'],
      },
    ],
    checkpoints: [{ id: 'l14_cp', position: [0, 0, -1.5] }],
  };

  // LEVEL 15: Tri-Stage Foundry — Rotating span + pulsing laser barrier + elevator carrying block to final door
  const l15Door = framedGateZ('l15_door', 0, 5.0, -25, 10, 3.6, 3.4, 1.0, ['l15_plateTop']);
  const level15: LevelBlueprint = {
    id: 15,
    title: 'Tri-Stage Foundry',
    tier: 'expert',
    objective: 'Align the foundry turntable, pass the pulsing laser corridor, and carry the cube up the lift.',
    spawn: [0, 0.9, 15],
    spawnYaw: 0,
    portal: { position: [0, 5.0, -31] },
    fallY: -12,
    parTime: 80,
    platforms: [
      floor('l15_south', 0, 0, 14, 9, 8, 1.8, 'stone'),
      floor('l15_pivot', 0, 0, 3, 4.5, 4.5, 2.0, 'trim'),
      floor('l15_mid', 0, 0, -11, 10, 12, 1.8, 'stone'),
      wall('l15_mL', -4.7, 0, -11, 0.6, 2.4, 12, 'stone'),
      wall('l15_mR', 4.7, 0, -11, 0.6, 2.4, 12, 'stone'),
      floor('l15_top', 0, 5.0, -26, 10, 16, 2.0, 'stone'),
      ...l15Door.walls,
    ],
    dynamicBodies: [
      {
        id: 'l15_cube',
        shape: 'cube',
        position: [-2.6, 0.85, -12.5],
        size: [1.4, 1.4, 1.4],
        mass: 3.0,
        grabbable: true,
        blocksLaser: true,
      },
    ],
    switches: [
      { id: 'l15_rotSw', position: [-3.0, 0, 12.0], kind: 'toggle', label: 'Turntable Align' },
      { id: 'l15_liftSw', position: [3.2, 0, -14.5], kind: 'toggle', label: 'Foundry Lift' },
    ],
    pressurePlates: [
      { id: 'l15_plateTop', position: [3.0, 5.0, -21.8], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l15Door.door],
    movingPlatforms: [
      {
        id: 'l15_lift',
        startPos: [0, -0.45, -19.2],
        endPos: [0, 4.55, -19.2],
        size: [4.6, 0.9, 4.6],
        speed: 2.8,
        requiredSignals: ['l15_liftSw'],
        pauseAtEnds: 1.6,
        style: 'accent',
      },
    ],
    rotatingBridges: [
      {
        id: 'l15_span',
        pivot: [0, -0.35, 3],
        size: [3.6, 0.7, 15.6],
        restAngleY: Math.PI * 0.5,
        activeAngleY: 0,
        speed: 1.4,
        requiredSignals: ['l15_rotSw'],
      },
    ],
    gravityZones: [],
    lasers: [
      {
        id: 'l15_pulse1',
        start: [-4.4, 0.85, -8.5],
        end: [4.4, 0.85, -8.5],
        cyclePeriod: 4.4,
        activeDuty: 0.45,
      },
      {
        id: 'l15_pulse2',
        start: [4.4, 0.85, -13.5],
        end: [-4.4, 0.85, -13.5],
        cyclePeriod: 4.4,
        activeDuty: 0.45,
        phaseOffset: 2.2,
      },
    ],
    checkpoints: [{ id: 'l15_cp', position: [0, 0, -6.2] }],
  };

  // LEVEL 16: Velocity Crucible — Momentum ramps, kinetic bounce pads, and pulsing lasers
  const level16: LevelBlueprint = {
    id: 16,
    title: 'Velocity Crucible',
    tier: 'expert',
    objective: 'Chain the kinetic bounce pads and momentum ramps across the islands while timing the laser gates.',
    spawn: [0, 0.9, 16],
    spawnYaw: 0,
    portal: { position: [0, 8.0, -30] },
    fallY: -12,
    parTime: 60,
    platforms: [
      floor('l16_s', 0, 0, 14, 9, 9, 1.8, 'stone'),
      // Bounce pad 1 -> boosts to Island 2 (y=3.6)
      floor('l16_b1', 0, 0.12, 10.6, 3.2, 3.2, 0.24, 'bounce', { bounceVelocity: 15.2 }),
      floor('l16_i2', 0, 3.6, 1, 9, 11, 1.8, 'stone'),
      // Low-friction sprint bridge to Island 3
      floor('l16_run', 0, 3.6, -8.5, 4.4, 8.5, 0.9, 'ice', { friction: 0.14 }),
      floor('l16_i3', 0, 3.6, -16, 10, 8, 1.8, 'stone'),
      // Bounce pad 2 -> boosts to Summit (y=8.0)
      floor('l16_b2', 0, 3.72, -18.5, 3.4, 3.4, 0.24, 'bounce', { bounceVelocity: 16.0 }),
      floor('l16_top', 0, 8.0, -28, 10, 11, 2.0, 'stone'),
    ],
    dynamicBodies: [],
    switches: [],
    pressurePlates: [],
    doors: [],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [
      {
        id: 'l16_las1',
        start: [-4.2, 4.45, 1.0],
        end: [4.2, 4.45, 1.0],
        cyclePeriod: 3.8,
        activeDuty: 0.45,
      },
      {
        id: 'l16_las2',
        start: [-4.2, 4.45, -14.5],
        end: [4.2, 4.45, -14.5],
        cyclePeriod: 3.6,
        activeDuty: 0.45,
        phaseOffset: 1.5,
      },
      {
        id: 'l16_las3',
        start: [-4.5, 8.85, -25.8],
        end: [4.5, 8.85, -25.8],
        cyclePeriod: 3.4,
        activeDuty: 0.42,
      },
    ],
    checkpoints: [
      { id: 'l16_cp1', position: [0, 3.6, 4.5] },
      { id: 'l16_cp2', position: [0, 3.6, -13.0] },
    ],
  };

  // =========================================================================
  // TIER 5: NIGHTMARE (Levels 17 - 19)
  // =========================================================================

  // LEVEL 17: Measured Force — Limited-pulse challenge (8 interactions max): laser block + gravity lift + twin lock
  const l17Door = framedGateZ('l17_door', 0, 4.8, -20, 11, 3.8, 3.5, 1.1, ['l17_p1', 'l17_p2']);
  const level17: LevelBlueprint = {
    id: 17,
    title: 'Measured Force',
    tier: 'nightmare',
    objective: 'Solve the chamber within 8 kinetic interactions: block the laser, rise through the updraft, and lock both plates.',
    spawn: [0, 0.9, 13],
    spawnYaw: 0,
    portal: { position: [0, 4.8, -26.5] },
    fallY: -12,
    parTime: 75,
    moveLimit: 8,
    platforms: [
      floor('l17_lower', 0, 0, 4, 12, 22, 1.8, 'stone'),
      wall('l17_wL', -5.7, 0, 4, 0.6, 2.4, 22, 'stone'),
      wall('l17_wR', 5.7, 0, 4, 0.6, 2.4, 22, 'stone'),
      floor('l17_upper', 0, 4.8, -19, 11, 19, 2.0, 'stone'),
      ...l17Door.walls,
    ],
    dynamicBodies: [
      {
        id: 'l17_shield',
        shape: 'heavyCube',
        position: [-3.4, 0.9, 8.0],
        size: [1.5, 1.6, 1.5],
        mass: 3.8,
        grabbable: true,
        blocksLaser: true,
      },
      {
        id: 'l17_topCube',
        shape: 'cube',
        position: [3.2, 5.6, -12.5],
        size: [1.35, 1.35, 1.35],
        mass: 3.0,
        grabbable: true,
      },
    ],
    switches: [
      { id: 'l17_upSw', position: [3.4, 0, -4.5], kind: 'toggle', label: 'Updraft Column' },
    ],
    pressurePlates: [
      { id: 'l17_p1', position: [-3.2, 0, -4.5], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
      { id: 'l17_p2', position: [-3.0, 4.8, -16.8], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l17Door.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [
      {
        id: 'l17_gz',
        position: [0, 3.2, -8.2],
        size: [4.4, 6.8, 4.4],
        gravity: [0, 8.2, 0],
        requiredSignals: ['l17_upSw'],
      },
    ],
    lasers: [
      {
        id: 'l17_las',
        start: [-5.3, 0.85, 2.2],
        end: [5.3, 0.85, 2.2],
      },
    ],
    checkpoints: [{ id: 'l17_cp', position: [0, 4.8, -11.5] }],
  };

  // LEVEL 18: Obsidian Labyrinth — Interlocked rotating span, laser occlusion, timed vault, and vertical shaft
  const l18Door = framedGateZ('l18_door', 0, 5.4, -26, 10, 3.6, 3.4, 1.0, ['l18_timer', 'l18_plate']);
  const level18: LevelBlueprint = {
    id: 18,
    title: 'Obsidian Labyrinth',
    tier: 'nightmare',
    objective: 'Coordinate the rotating span, shield cube, updraft shaft, and timed gate to escape the labyrinth.',
    spawn: [0, 0.9, 15],
    spawnYaw: 0,
    portal: { position: [0, 5.4, -32.5] },
    fallY: -12,
    parTime: 90,
    platforms: [
      floor('l18_start', 0, 0, 14, 9, 8, 1.8, 'stone'),
      floor('l18_hub', 0, 0, 2, 5.0, 5.0, 2.0, 'trim'),
      floor('l18_east', 12.5, 0, 2, 7.5, 8.0, 1.8, 'stone'),
      floor('l18_mid', 0, 0, -11, 10, 11, 1.8, 'stone'),
      wall('l18_mL', -4.7, 0, -11, 0.6, 2.4, 11, 'stone'),
      wall('l18_mR', 4.7, 0, -11, 0.6, 2.4, 11, 'stone'),
      floor('l18_upper', 0, 5.4, -26.5, 10, 18, 2.0, 'stone'),
      ...l18Door.walls,
    ],
    dynamicBodies: [
      {
        id: 'l18_shield',
        shape: 'heavyCube',
        position: [12.5, 0.9, 2.0],
        size: [1.5, 1.6, 1.5],
        mass: 3.6,
        grabbable: true,
        blocksLaser: true,
      },
      {
        id: 'l18_topCube',
        shape: 'cube',
        position: [-3.2, 6.2, -20.5],
        size: [1.35, 1.35, 1.35],
        mass: 3.0,
        grabbable: true,
      },
    ],
    switches: [
      { id: 'l18_rotSw', position: [-3.0, 0, 12.2], kind: 'toggle', label: 'Span Pivot' },
      { id: 'l18_rotSwE', position: [10.0, 0, 4.5], kind: 'toggle', label: 'Span Pivot' },
      { id: 'l18_timer', position: [3.2, 5.4, -20.5], kind: 'timed', duration: 9.5, label: 'Vault Chrono' },
    ],
    pressurePlates: [
      { id: 'l18_plate', position: [-3.0, 5.4, -23.0], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l18Door.door],
    movingPlatforms: [],
    rotatingBridges: [
      {
        id: 'l18_bridge',
        pivot: [0, -0.35, 2],
        size: [3.6, 0.7, 17.5],
        restAngleY: 0,
        activeAngleY: Math.PI * 0.5,
        speed: 1.45,
        requiredSignals: ['l18_rotSw', 'l18_rotSwE'],
        logic: 'OR',
      },
    ],
    gravityZones: [
      {
        id: 'l18_updraft',
        position: [0, 3.6, -15.6],
        size: [4.2, 7.6, 4.2],
        gravity: [0, 8.6, 0],
      },
    ],
    lasers: [
      {
        id: 'l18_las1',
        start: [-4.4, 0.85, -10.5],
        end: [4.4, 0.85, -10.5],
      },
    ],
    checkpoints: [
      { id: 'l18_cp1', position: [0, 0, -7.2] },
      { id: 'l18_cp2', position: [0, 5.4, -19.0] },
    ],
  };

  // LEVEL 19: Harmonic Singularity — Limited pulses (10), shuttle + laser shield + low-G leap
  const l19Door = framedGateZ('l19_door', 0, 5.6, -27, 10, 3.8, 3.5, 1.1, ['l19_p1', 'l19_swFinal']);
  const level19: LevelBlueprint = {
    id: 19,
    title: 'Harmonic Singularity',
    tier: 'nightmare',
    objective: 'Complete the harmonic sequence within 10 kinetic pulses: ride the shuttle, shield the laser, and leap in low gravity.',
    spawn: [0, 0.9, 15],
    spawnYaw: 0,
    portal: { position: [0, 5.6, -33.5] },
    fallY: -12,
    parTime: 90,
    moveLimit: 10,
    platforms: [
      floor('l19_start', 0, 0, 13, 10, 9, 1.8, 'stone'),
      floor('l19_mid', 0, 0, -6, 11, 13, 1.8, 'stone'),
      wall('l19_mL', -5.2, 0, -6, 0.6, 2.4, 13, 'stone'),
      wall('l19_mR', 5.2, 0, -6, 0.6, 2.4, 13, 'stone'),
      floor('l19_high', 0, 5.6, -26, 10, 20, 2.0, 'stone'),
      ...l19Door.walls,
    ],
    dynamicBodies: [
      {
        id: 'l19_shield',
        shape: 'heavyCube',
        position: [-3.2, 0.9, -2.5],
        size: [1.55, 1.65, 1.55],
        mass: 3.8,
        grabbable: true,
        blocksLaser: true,
      },
      {
        id: 'l19_weight',
        shape: 'cube',
        position: [3.0, 6.4, -19.5],
        size: [1.35, 1.35, 1.35],
        mass: 3.0,
        grabbable: true,
      },
    ],
    switches: [
      {
        id: 'l19_gravSw',
        position: [3.4, 0, -9.8],
        kind: 'gravity',
        gravityVector: [0, -7.0, 0],
        label: 'Low-G Field',
      },
      { id: 'l19_swFinal', position: [3.2, 5.6, -23.5], kind: 'toggle', label: 'Harmonic Seal' },
    ],
    pressurePlates: [
      { id: 'l19_p1', position: [-3.0, 5.6, -23.5], size: [2.3, 2.3], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l19Door.door],
    movingPlatforms: [
      {
        id: 'l19_shuttle',
        startPos: [0, -0.45, 6.2],
        endPos: [0, -0.45, 1.8],
        size: [4.4, 0.9, 4.4],
        speed: 3.0,
        pauseAtEnds: 0.9,
        style: 'metal',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [
      {
        id: 'l19_las1',
        start: [-4.8, 0.85, -6.2],
        end: [4.8, 0.85, -6.2],
      },
      {
        id: 'l19_las2',
        start: [4.6, 6.45, -21.0],
        end: [-4.6, 6.45, -21.0],
        cyclePeriod: 4.2,
        activeDuty: 0.45,
      },
    ],
    checkpoints: [
      { id: 'l19_cp1', position: [0, 0, -1.2] },
      { id: 'l19_cp2', position: [0, 5.6, -17.8] },
    ],
  };

  // =========================================================================
  // TIER 6: FINAL CHALLENGE (Level 20)
  // =========================================================================

  // LEVEL 20: The Twentieth Axiom — Grand citadel combining momentum, pressure plates, lasers,
  // rotating span, moving elevator, updraft gravity, and timed finale door!
  const l20Gate1 = framedGateZ('l20_g1', 0, 0, -9, 12, 3.8, 3.5, 1.0, ['l20_p1']);
  const l20GateFinal = framedGateZ('l20_gFinal', 0, 7.2, -46, 12, 4.2, 3.8, 1.2, ['l20_pFinal', 'l20_timer']);
  const level20: LevelBlueprint = {
    id: 20,
    title: 'The Twentieth Axiom',
    tier: 'final',
    objective: 'Master every discipline across the three citadel wings to unseal the Final Portal.',
    spawn: [0, 0.9, 16],
    spawnYaw: 0,
    portal: { position: [0, 7.2, -53.5] },
    fallY: -14,
    parTime: 130,
    platforms: [
      // Wing 1: Momentum & Counterweight Courtyard
      floor('l20_w1', 0, 0, 5, 12, 26, 1.8, 'stone'),
      wall('l20_w1L', -5.7, 0, 5, 0.6, 1.8, 26, 'trim'),
      wall('l20_w1R', 5.7, 0, 5, 0.6, 1.8, 26, 'trim'),
      // Wing 2: Laser Hall & Rotating Span Abyss
      floor('l20_w2', 0, 0, -15.5, 12, 13, 1.8, 'stone'),
      wall('l20_w2L', -5.7, 0, -15.5, 0.6, 2.4, 13, 'stone'),
      wall('l20_w2R', 5.7, 0, -15.5, 0.6, 2.4, 13, 'stone'),
      floor('l20_pivot', 0, 0, -29.5, 5.0, 5.0, 2.0, 'trim'),
      // Wing 3: Gravity Spire & Final Sanctuary
      floor('l20_w3Base', 0, 0, -39, 11, 7, 1.8, 'stone'),
      floor('l20_w3Top', 0, 7.2, -47, 12, 20, 2.2, 'stone'),
      wall('l20_topL', -5.7, 7.2, -47, 0.6, 1.4, 20, 'trim'),
      wall('l20_topR', 5.7, 7.2, -47, 0.6, 1.4, 20, 'trim'),
      ...l20Gate1.walls,
      ...l20GateFinal.walls,
    ],
    dynamicBodies: [
      {
        id: 'l20_sphere1',
        shape: 'sphere',
        position: [-3.4, 0.9, 9.0],
        size: [1.4, 1.4, 1.4],
        mass: 3.2,
        friction: 0.35,
        restitution: 0.35,
        grabbable: true,
      },
      {
        id: 'l20_shield',
        shape: 'heavyCube',
        position: [3.2, 0.9, -12.2],
        size: [1.55, 1.65, 1.55],
        mass: 4.0,
        grabbable: true,
        blocksLaser: true,
      },
      {
        id: 'l20_finalCube',
        shape: 'cube',
        position: [-3.5, 8.0, -40.5],
        size: [1.4, 1.4, 1.4],
        mass: 3.2,
        grabbable: true,
      },
    ],
    switches: [
      { id: 'l20_rotSw', position: [-3.4, 0, -20.2], kind: 'toggle', label: 'Citadel Span' },
      { id: 'l20_upSw', position: [3.4, 0, -38.8], kind: 'toggle', label: 'Ascension Conduit' },
      { id: 'l20_timer', position: [3.6, 7.2, -41.5], kind: 'timed', duration: 10.0, label: 'Axiom Chrono' },
    ],
    pressurePlates: [
      { id: 'l20_p1', position: [3.4, 0, -4.5], size: [2.4, 2.4], minWeight: 2.0, requiresBlock: true },
      { id: 'l20_pFinal', position: [-3.6, 7.2, -43.2], size: [2.4, 2.4], minWeight: 2.0, requiresBlock: true },
    ],
    doors: [l20Gate1.door, l20GateFinal.door],
    movingPlatforms: [],
    rotatingBridges: [
      {
        id: 'l20_span',
        pivot: [0, -0.35, -29.5],
        size: [3.8, 0.7, 15.2],
        restAngleY: Math.PI * 0.5,
        activeAngleY: 0,
        speed: 1.4,
        requiredSignals: ['l20_rotSw'],
      },
    ],
    gravityZones: [
      {
        id: 'l20_updraft',
        position: [0, 4.6, -39.0],
        size: [4.6, 9.6, 4.6],
        gravity: [0, 9.0, 0],
        requiredSignals: ['l20_upSw'],
      },
    ],
    lasers: [
      {
        id: 'l20_las1',
        start: [-5.3, 0.85, -16.0],
        end: [5.3, 0.85, -16.0],
      },
      {
        id: 'l20_las2',
        start: [-5.3, 8.05, -49.5],
        end: [5.3, 8.05, -49.5],
        cyclePeriod: 4.0,
        activeDuty: 0.42,
      },
    ],
    checkpoints: [
      { id: 'l20_cp1', position: [0, 0, -11.5] },
      { id: 'l20_cp2', position: [0, 7.2, -39.0] },
    ],
  };

  return [
    level1,
    level2,
    level3,
    level4,
    level5,
    level6,
    level7,
    level8,
    level9,
    level10,
    level11,
    level12,
    level13,
    level14,
    level15,
    level16,
    level17,
    level18,
    level19,
    level20,
  ];
}

export const LEVELS: LevelBlueprint[] = [...buildLevels(), ...EXPANSION_LEVELS];

export function getLevelById(id: number): LevelBlueprint {
  const found = LEVELS.find((lvl) => lvl.id === id);
  return found ?? LEVELS[0];
}
