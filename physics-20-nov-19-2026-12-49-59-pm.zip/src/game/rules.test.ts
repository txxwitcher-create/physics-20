import assert from 'node:assert/strict';
import test from 'node:test';
import { LEVELS, getLevelById } from './levels';
import {
  computeJoystickOutput,
  createNeutralJoystickState,
  describeGravityLabel,
  evaluateLaserBeam,
  evaluateLavaHazardOverlap,
  evaluateSignalCondition,
  formatDuration,
  getWorldForLevel,
  joystickForceReset,
  joystickPointerDown,
  joystickPointerEnd,
  joystickPointerMove,
  resolveGravityAtPoint,
  stepBreakableIceState,
  validateLevelBlueprints,
  WORLD_META,
  WORLD_ORDER,
} from './rules';
import {
  createDefaultProgress,
  recordLevelCompletion,
  sanitizeProgress,
  sanitizeSettings,
  TOTAL_LEVELS,
} from './storage';

test('all 30 handcrafted levels pass structural, signal, and uniqueness validation while preserving Levels 1–20', () => {
  const errors = validateLevelBlueprints(LEVELS, 30);
  assert.deepEqual(errors, []);
  assert.equal(LEVELS.length, 30);
  assert.equal(TOTAL_LEVELS, 30);

  // Verify locked Levels 1–20 remain intact with default citadel environment
  assert.equal(getLevelById(1).title, 'First Impulse');
  assert.equal(getLevelById(2).title, 'Counterweight');
  assert.equal(getLevelById(20).title, 'The Twentieth Axiom');
  for (let id = 1; id <= 20; id++) {
    const lvl = getLevelById(id);
    assert.equal(lvl.environment, undefined, `Level ${id} must remain unmodified default citadel`);
  }

  // Verify World 5 (Frozen Abyss, Levels 21–25)
  const expectedFrozenTitles = [
    'Frozen Entry',
    'Sliding Weight',
    'Frozen Switches',
    'Breaking Passage',
    'Icebound Trial',
  ];
  for (let i = 0; i < 5; i++) {
    const lvl = getLevelById(21 + i);
    assert.equal(lvl.title, expectedFrozenTitles[i]);
    assert.equal(lvl.tier, 'frozen');
    assert.equal(lvl.environment, 'frozen');
  }

  // Verify World 6 (Inferno Core, Levels 26–30)
  const expectedInfernoTitles = [
    'Molten Crossing',
    'Thermal Mechanism',
    'Rotating Furnace',
    'Meltdown Sequence',
    'Inferno Trial',
  ];
  for (let i = 0; i < 5; i++) {
    const lvl = getLevelById(26 + i);
    assert.equal(lvl.title, expectedInfernoTitles[i]);
    assert.equal(lvl.tier, 'inferno');
    assert.equal(lvl.environment, 'inferno');
    assert.ok((lvl.lavaHazards?.length ?? 0) >= 1, `Level ${26 + i} must include lava hazards`);
  }

  // Verify exact progression tier distribution (4+4+4+4+3+1 + 5 + 5 = 30)
  const counts = LEVELS.reduce<Record<string, number>>((acc, lvl) => {
    acc[lvl.tier] = (acc[lvl.tier] ?? 0) + 1;
    return acc;
  }, {});
  assert.deepEqual(counts, {
    foundation: 4,
    intermediate: 4,
    advanced: 4,
    expert: 4,
    nightmare: 3,
    final: 1,
    frozen: 5,
    inferno: 5,
  });

  // Verify 6-world mapping covers 1..30 seamlessly
  assert.equal(WORLD_ORDER.length, 6);
  assert.equal(getWorldForLevel(1).id, 'world1');
  assert.equal(getWorldForLevel(20).id, 'world4');
  assert.equal(getWorldForLevel(21).id, 'world5');
  assert.equal(getWorldForLevel(25).id, 'world5');
  assert.equal(getWorldForLevel(26).id, 'world6');
  assert.equal(getWorldForLevel(30).id, 'world6');
  assert.equal(WORLD_META.world5.name, 'Frozen Abyss');
  assert.equal(WORLD_META.world6.name, 'Inferno Core');
});

test('signal condition evaluation supports AND, OR, and empty requirements', () => {
  const signals = { s1: true, s2: false };
  assert.equal(evaluateSignalCondition(undefined, signals), true);
  assert.equal(evaluateSignalCondition([], signals), true);
  assert.equal(evaluateSignalCondition(['s1'], signals, 'AND'), true);
  assert.equal(evaluateSignalCondition(['s1', 's2'], signals, 'AND'), false);
  assert.equal(evaluateSignalCondition(['s1', 's2'], signals, 'OR'), true);
  assert.equal(evaluateSignalCondition(['s2'], signals, 'OR'), false);
});

test('laser beam occlusion physically blocks beams with shield cubes and disables via switches', () => {
  const laser = {
    id: 'las1',
    start: [-5, 1, 0] as [number, number, number],
    end: [5, 1, 0] as [number, number, number],
    disableSignals: ['sw_off'],
  };

  const hitUnblocked = evaluateLaserBeam(laser, {}, 0, [], [2, 1, 0], 0.52);
  assert.equal(hitUnblocked.active, true);
  assert.equal(hitUnblocked.hitFraction, 1);
  assert.equal(hitUnblocked.hitsPlayer, true);

  const shieldBlock = [{ center: [0, 1, 0] as [number, number, number], halfExtents: [0.75, 0.8, 0.75] as [number, number, number] }];
  const blocked = evaluateLaserBeam(laser, {}, 0, shieldBlock, [2, 1, 0], 0.52);
  assert.equal(blocked.active, true);
  assert.ok(blocked.hitFraction < 0.5, `Expected laser clipped before midpoint, got ${blocked.hitFraction}`);
  assert.equal(blocked.hitsPlayer, false);

  const disabled = evaluateLaserBeam(laser, { sw_off: true }, 0, [], [2, 1, 0], 0.52);
  assert.equal(disabled.active, false);
  assert.equal(disabled.hitsPlayer, false);
});

test('gravity zones and global gravity switches resolve accurately', () => {
  const base: [number, number, number] = [0, -22, 0];
  const zones = [
    {
      id: 'gz1',
      position: [0, 4, 0] as [number, number, number],
      size: [4, 8, 4] as [number, number, number],
      gravity: [0, 8, 0] as [number, number, number],
      requiredSignals: ['up_sw'],
    },
  ];

  assert.deepEqual(resolveGravityAtPoint([0, 3, 0], base, null, zones, {}), [0, -22, 0]);
  assert.deepEqual(resolveGravityAtPoint([0, 3, 0], base, null, zones, { up_sw: true }), [0, 8, 0]);
  assert.equal(describeGravityLabel([0, 8, 0]), 'Updraft Lift');
  assert.equal(describeGravityLabel([0, -7, 0]), 'Low Gravity');
  assert.equal(describeGravityLabel([0, -22, 0]), null);
});

test('progression saving preserves existing 1–20 saves, promotes Level 20 clear to 21, and unlocks through Level 30', () => {
  const start = createDefaultProgress();
  assert.equal(start.unlockedLevel, 1);

  const r1 = recordLevelCompletion(start, 1, 28.45, 1000);
  assert.equal(r1.next.unlockedLevel, 2);
  assert.equal(r1.isNewBest, true);
  assert.equal(r1.bestTime, 28.45);

  // Slower replay keeps previous best time
  const r2 = recordLevelCompletion(r1.next, 1, 35.1, 2000);
  assert.equal(r2.isNewBest, false);
  assert.equal(r2.bestTime, 28.45);

  // Faster replay updates best time
  const r3 = recordLevelCompletion(r2.next, 1, 21.3, 3000);
  assert.equal(r3.isNewBest, true);
  assert.equal(r3.bestTime, 21.3);

  // Legacy player who completed Level 20 gets automatically promoted to unlock World 5 (Level 21)
  const legacyCompleted20 = sanitizeProgress({
    unlockedLevel: 20,
    completedLevels: {
      1: { bestTime: 14.2, completedAt: 100 },
      20: { bestTime: 82.4, completedAt: 500 },
    },
  });
  assert.equal(legacyCompleted20.unlockedLevel, 21);
  assert.equal(legacyCompleted20.completedLevels[1]?.bestTime, 14.2);
  assert.equal(legacyCompleted20.completedLevels[20]?.bestTime, 82.4);

  // Completing Level 21 unlocks 22; completing Level 30 clamps cleanly at 30
  const r21 = recordLevelCompletion(legacyCompleted20, 21, 31.0, 900);
  assert.equal(r21.next.unlockedLevel, 22);
  const r30 = recordLevelCompletion({ unlockedLevel: 30, completedLevels: {} }, 30, 94.5, 1000);
  assert.equal(r30.next.unlockedLevel, 30);

  // Sanitization clamps invalid stored values safely to TOTAL_LEVELS (30)
  const sanitized = sanitizeProgress({ unlockedLevel: 99, completedLevels: { 999: { bestTime: 10 }, 2: { bestTime: 18.5 }, 26: { bestTime: 44.1 } } });
  assert.equal(sanitized.unlockedLevel, 30);
  assert.equal(sanitized.completedLevels[999], undefined);
  assert.equal(sanitized.completedLevels[2]?.bestTime, 18.5);
  assert.equal(sanitized.completedLevels[26]?.bestTime, 44.1);

  const settings = sanitizeSettings({ volume: 5, cameraSensitivity: 0.1, graphicsQuality: 'invalid' });
  assert.equal(settings.volume, 1);
  assert.equal(settings.cameraSensitivity, 0.4);
  assert.equal(settings.graphicsQuality, 'auto');
});

test('World 5 breakable ice state machine cracks, collapses, and reforms cleanly', () => {
  let state = { phase: 'intact' as const, timer: 0 };

  // Untouched stays intact
  const s0 = stepBreakableIceState(state, false, 0.5, 1.0, 3.5);
  assert.equal(s0.next.phase, 'intact');
  assert.equal(s0.startedCracking, false);

  // Stepping onto ice starts cracking countdown
  const s1 = stepBreakableIceState(s0.next, true, 0.016, 1.0, 3.5);
  assert.equal(s1.next.phase, 'cracking');
  assert.equal(s1.startedCracking, true);
  assert.equal(s1.next.timer, 1.0);

  // Partial countdown stays cracking
  const s2 = stepBreakableIceState(s1.next, false, 0.6, 1.0, 3.5);
  assert.equal(s2.next.phase, 'cracking');
  assert.equal(s2.justCollapsed, false);

  // Remaining time expires -> collapses
  const s3 = stepBreakableIceState(s2.next, false, 0.5, 1.0, 3.5);
  assert.equal(s3.next.phase, 'collapsed');
  assert.equal(s3.justCollapsed, true);
  assert.equal(s3.next.timer, 3.5);

  // Respawn timer expires -> reforms cleanly to intact
  const s4 = stepBreakableIceState(s3.next, false, 3.6, 1.0, 3.5);
  assert.equal(s4.next.phase, 'intact');
  assert.equal(s4.justReformed, true);
});

test('World 6 lava hazard overlap accurately detects safe clearance vs molten contact', () => {
  const pool = {
    position: [0, -2.5, 0] as [number, number, number],
    size: [20, 1.8, 20] as [number, number, number], // top surface at y = -1.6
  };

  // Standing on walkway at y = 0.52 is safely above lava
  assert.equal(evaluateLavaHazardOverlap([0, 0.52, 0], 0.52, pool), false);
  // Falling near lava surface (-1.3 -> distance 0.3 <= 0.52*0.84=0.4368) triggers hazard
  assert.equal(evaluateLavaHazardOverlap([0, -1.3, 0], 0.52, pool), true);
  // Deep inside magma triggers hazard
  assert.equal(evaluateLavaHazardOverlap([4, -2.2, -5], 0.52, pool), true);
  // Outside horizontal bounds at lava elevation does not trigger
  assert.equal(evaluateLavaHazardOverlap([15, -2.0, 0], 0.52, pool), false);
});

test('duration formatter outputs clean tabular mm:ss.t strings', () => {
  assert.equal(formatDuration(0), '00:00.0');
  assert.equal(formatDuration(65.48), '01:05.4');
});

test('virtual joystick clamps all directions accurately without floating-point drift on orthogonal axes', () => {
  const maxR = 42;
  const cx = 100;
  const cy = 700;

  const up = computeJoystickOutput(cx, cy - 90, cx, cy, maxR);
  assert.equal(up.offsetX, 0);
  assert.equal(up.offsetY, -42);
  assert.equal(up.normX, 0);
  assert.equal(up.normY, -1);

  const down = computeJoystickOutput(cx, cy + 80, cx, cy, maxR);
  assert.equal(down.offsetX, 0);
  assert.equal(down.offsetY, 42);
  assert.equal(down.normX, 0);
  assert.equal(down.normY, 1);

  const left = computeJoystickOutput(cx - 21, cy, cx, cy, maxR);
  assert.equal(left.offsetX, -21);
  assert.equal(left.offsetY, 0);
  assert.equal(left.normX, -0.5);
  assert.equal(left.normY, 0);

  const right = computeJoystickOutput(cx + 120, cy, cx, cy, maxR);
  assert.equal(right.offsetX, 42);
  assert.equal(right.offsetY, 0);
  assert.equal(right.normX, 1);
  assert.equal(right.normY, 0);

  const diag = computeJoystickOutput(cx + 100, cy - 100, cx, cy, maxR);
  assert.ok(Math.abs(Math.hypot(diag.normX, diag.normY) - 1) < 1e-9);
  assert.ok(Math.abs(Math.hypot(diag.offsetX, diag.offsetY) - maxR) < 1e-9);

  assert.deepEqual(computeJoystickOutput(cx, cy, cx, cy, maxR), {
    offsetX: 0,
    offsetY: 0,
    normX: 0,
    normY: 0,
  });
  assert.deepEqual(computeJoystickOutput(Number.NaN, cy, cx, cy, maxR), {
    offsetX: 0,
    offsetY: 0,
    normX: 0,
    normY: 0,
  });
});

test('virtual joystick pointer lifecycle returns to neutral on release and recovers after forced reset (pause/level change)', () => {
  const maxR = 42;
  let state = createNeutralJoystickState();

  state = joystickPointerDown(state, 10, 100, 700, 100, 700, maxR);
  state = joystickPointerMove(state, 10, 100, 620, maxR);
  assert.equal(state.active, true);
  assert.equal(state.pointerId, 10);
  assert.equal(state.offsetY, -42);
  assert.equal(state.normY, -1);

  const ignoredDown = joystickPointerDown(state, 11, 140, 700, 100, 700, maxR);
  assert.equal(ignoredDown.pointerId, 10);
  const ignoredEnd = joystickPointerEnd(state, 11);
  assert.equal(ignoredEnd.pointerId, 10);

  state = joystickForceReset();
  assert.equal(state.active, false);
  assert.equal(state.pointerId, null);
  assert.equal(state.offsetX, 0);
  assert.equal(state.offsetY, 0);
  assert.equal(state.normX, 0);
  assert.equal(state.normY, 0);

  state = joystickPointerDown(state, 12, 100, 700, 100, 700, maxR);
  state = joystickPointerMove(state, 12, 142, 700, maxR);
  assert.equal(state.active, true);
  assert.equal(state.pointerId, 12);
  assert.equal(state.normX, 1);

  state = joystickPointerEnd(state, 12);
  assert.equal(state.active, false);
  assert.equal(state.pointerId, null);
  assert.equal(state.offsetX, 0);
  assert.equal(state.offsetY, 0);
  assert.equal(state.normX, 0);
  assert.equal(state.normY, 0);
});
