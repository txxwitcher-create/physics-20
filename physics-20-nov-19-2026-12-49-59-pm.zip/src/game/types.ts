export type Vec3 = [number, number, number];

export type EnvironmentTheme = 'citadel' | 'frozen' | 'inferno';

export type WorldId =
  | 'world1'
  | 'world2'
  | 'world3'
  | 'world4'
  | 'world5'
  | 'world6';

export type TierId =
  | 'foundation'
  | 'intermediate'
  | 'advanced'
  | 'expert'
  | 'nightmare'
  | 'final'
  | 'frozen'
  | 'inferno';

export type GameScreenState =
  | 'loading'
  | 'title'
  | 'playing'
  | 'paused'
  | 'complete'
  | 'error';

export type SurfaceStyle =
  | 'stone'
  | 'metal'
  | 'trim'
  | 'ice'
  | 'bounce'
  | 'accent'
  | 'frozenStone'
  | 'clearIce'
  | 'snow'
  | 'basalt'
  | 'industrialMetal'
  | 'lava';

export interface BreakableConfig {
  collapseDelay: number; // Seconds after contact before collider disables & ice drops
  respawnDelay: number; // Seconds before fractured ice reforms cleanly
}

export interface PlatformDef {
  id: string;
  position: Vec3;
  size: Vec3;
  rotation?: Vec3; // Euler radians [rx, ry, rz]
  style?: SurfaceStyle;
  friction?: number;
  restitution?: number;
  bounceVelocity?: number; // If set, propels player upward
  slippery?: boolean; // World 5 low-friction ice surface momentum physics
  breakable?: BreakableConfig; // World 5 collapsing/breakable ice platform
}

export type DynamicShape = 'cube' | 'heavyCube' | 'sphere' | 'slab';

export interface DynamicBodyDef {
  id: string;
  shape: DynamicShape;
  position: Vec3;
  size: Vec3; // Full dimensions for box/slab, [diameter, diameter, diameter] for sphere
  mass: number;
  friction?: number;
  restitution?: number;
  grabbable?: boolean;
  blocksLaser?: boolean;
  lowFriction?: boolean; // World 5 sliding ice monolith / frost cube
  heatConductive?: boolean; // World 6 tungsten-copper thermal core cube
}

export type SwitchKind = 'toggle' | 'timed' | 'gravity' | 'thermal';

export interface SwitchDef {
  id: string;
  position: Vec3;
  kind: SwitchKind;
  duration?: number; // Seconds for 'timed' or 'thermal'
  initialActive?: boolean;
  gravityVector?: Vec3; // Active gravity vector when kind === 'gravity'
  label?: string;
  frozen?: boolean; // Visual frozen crystal housing for World 5
}

export interface PressurePlateDef {
  id: string;
  position: Vec3;
  size?: [number, number]; // width, depth (default [2.1, 2.1])
  minWeight?: number; // Minimum mass or player count needed (default 1.0)
  requiresBlock?: boolean; // If true, only dynamic blocks can hold it down
  thermalOnly?: boolean; // World 6 heat-sensitive receptor pad (requires heatConductive block)
}

export interface DoorDef {
  id: string;
  position: Vec3; // Closed center position
  size: Vec3; // [width, height, depth]
  openOffset: Vec3; // Offset added when open
  requiredSignals: string[]; // All listed switch/plate IDs must be active
  logic?: 'AND' | 'OR';
  rotationY?: number;
}

export interface MovingPlatformDef {
  id: string;
  startPos: Vec3;
  endPos: Vec3;
  size: Vec3;
  speed: number; // Units per second
  requiredSignals?: string[]; // If omitted or empty, moves continuously
  logic?: 'AND' | 'OR';
  pauseAtEnds?: number; // Seconds to dwell at endpoints
  style?: SurfaceStyle;
  slippery?: boolean;
}

export interface RotatingBridgeDef {
  id: string;
  pivot: Vec3;
  size: Vec3; // Length along X or Z
  restAngleY: number;
  activeAngleY: number;
  speed: number; // Radians per second
  requiredSignals?: string[]; // If empty, rotates continuously
  continuousSpeed?: number; // Rad/s if continuous
  logic?: 'AND' | 'OR';
  style?: SurfaceStyle;
  slippery?: boolean;
}

export interface GravityZoneDef {
  id: string;
  position: Vec3;
  size: Vec3;
  gravity: Vec3; // Overrides gravity inside zone
  requiredSignals?: string[]; // Optional activation signal
  logic?: 'AND' | 'OR';
}

export interface LaserHazardDef {
  id: string;
  start: Vec3;
  end: Vec3;
  disableSignals?: string[]; // If active, laser shuts off
  logic?: 'AND' | 'OR';
  cyclePeriod?: number; // Optional pulsing laser (total seconds)
  activeDuty?: number; // Fraction of period active (0..1)
  phaseOffset?: number;
}

export interface LavaHazardDef {
  id: string;
  position: Vec3; // Center of lava pool
  size: Vec3; // [width, height, depth]
  shimmer?: boolean; // Subtle sparing heat distortion ribbon above pool
}

export interface MovingObstacleDef {
  id: string;
  startPos: Vec3;
  endPos: Vec3;
  size: Vec3;
  speed: number;
  pauseAtEnds?: number;
  lethal?: boolean; // If true, molten furnace ram triggers hazard respawn on contact
  disableSignals?: string[]; // Optional signals to retract/halt obstacle
  logic?: 'AND' | 'OR';
  style?: SurfaceStyle;
}

export interface CheckpointDef {
  id: string;
  position: Vec3;
}

export interface PortalDef {
  position: Vec3;
  requiredSignals?: string[];
  logic?: 'AND' | 'OR';
  rotationY?: number;
}

export interface LevelBlueprint {
  id: number;
  title: string;
  tier: TierId;
  environment?: EnvironmentTheme; // Defaults to 'citadel' for Levels 1–20
  objective: string;
  spawn: Vec3;
  spawnYaw?: number; // Initial camera yaw in radians
  portal: PortalDef;
  fallY: number;
  parTime: number;
  baseGravity?: Vec3;
  moveLimit?: number; // Max interactions (grab / switch) for limited-move Nightmare levels
  platforms: PlatformDef[];
  dynamicBodies: DynamicBodyDef[];
  switches: SwitchDef[];
  pressurePlates: PressurePlateDef[];
  doors: DoorDef[];
  movingPlatforms: MovingPlatformDef[];
  rotatingBridges: RotatingBridgeDef[];
  gravityZones: GravityZoneDef[];
  lasers: LaserHazardDef[];
  lavaHazards?: LavaHazardDef[];
  movingObstacles?: MovingObstacleDef[];
  checkpoints: CheckpointDef[];
}

export interface LevelCompletionRecord {
  bestTime: number;
  completedAt: number;
}

export interface ProgressState {
  unlockedLevel: number; // 1..30
  completedLevels: Record<number, LevelCompletionRecord>;
}

export type GraphicsQuality = 'auto' | 'high' | 'balanced';
export type TouchControlsMode = 'auto' | 'always' | 'off';

export interface SettingsState {
  sfxEnabled: boolean;
  musicEnabled: boolean;
  volume: number; // 0..1
  cameraSensitivity: number; // 0.4..2.0
  graphicsQuality: GraphicsQuality;
  showFps: boolean;
  touchControlsMode: TouchControlsMode;
}

export interface HudSnapshot {
  levelId: number;
  levelTitle: string;
  tierLabel: string;
  objective: string;
  elapsedTime: number;
  interactPrompt: string | null;
  interactType: 'switch' | 'grab' | 'release' | null;
  isGrabbing: boolean;
  gravityLabel: string | null;
  movesRemaining: number | null;
  moveLimit: number | null;
  portalUnlocked: boolean;
  checkpointBanner: string | null;
  timedRemaining: number | null;
  timedLabel: string | null;
  fps: number;
}

export interface CompletionSummary {
  levelId: number;
  levelTitle: string;
  elapsedTime: number;
  bestTime: number;
  isNewBest: boolean;
  hasNextLevel: boolean;
}

