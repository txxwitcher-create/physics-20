import type { ProgressState, SettingsState } from './types';

export const PROGRESS_STORAGE_KEY = 'physics20_progress_v1';
export const SETTINGS_STORAGE_KEY = 'physics20_settings_v1';
export const TOTAL_LEVELS = 30;

export function createDefaultProgress(): ProgressState {
  return {
    unlockedLevel: 1,
    completedLevels: {},
  };
}

export function createDefaultSettings(): SettingsState {
  return {
    sfxEnabled: true,
    musicEnabled: true,
    volume: 0.7,
    cameraSensitivity: 1.0,
    graphicsQuality: 'auto',
    showFps: false,
    touchControlsMode: 'auto',
  };
}

export function sanitizeProgress(raw: unknown): ProgressState {
  if (!raw || typeof raw !== 'object') {
    return createDefaultProgress();
  }
  const obj = raw as Record<string, unknown>;
  const unlockedRaw = typeof obj.unlockedLevel === 'number' && Number.isFinite(obj.unlockedLevel)
    ? Math.floor(obj.unlockedLevel)
    : 1;
  const unlockedLevel = Math.max(1, Math.min(TOTAL_LEVELS, unlockedRaw));

  const completedLevels: ProgressState['completedLevels'] = {};
  if (obj.completedLevels && typeof obj.completedLevels === 'object') {
    for (const [key, val] of Object.entries(obj.completedLevels as Record<string, unknown>)) {
      const levelId = Number(key);
      if (!Number.isInteger(levelId) || levelId < 1 || levelId > TOTAL_LEVELS) continue;
      if (!val || typeof val !== 'object') continue;
      const rec = val as Record<string, unknown>;
      const bestTime = typeof rec.bestTime === 'number' && Number.isFinite(rec.bestTime) && rec.bestTime > 0
        ? rec.bestTime
        : 0;
      const completedAt = typeof rec.completedAt === 'number' && Number.isFinite(rec.completedAt)
        ? rec.completedAt
        : Date.now();
      if (bestTime > 0) {
        completedLevels[levelId] = { bestTime, completedAt };
      }
    }
  }

  // Preserve all existing save records and seamlessly unlock World 5 (Level 21) if Level 20 was already completed
  const effectiveUnlocked = completedLevels[20] && unlockedLevel === 20
    ? 21
    : unlockedLevel;

  return { unlockedLevel: effectiveUnlocked, completedLevels };
}

export function sanitizeSettings(raw: unknown): SettingsState {
  const defaults = createDefaultSettings();
  if (!raw || typeof raw !== 'object') {
    return defaults;
  }
  const obj = raw as Record<string, unknown>;
  const quality = obj.graphicsQuality === 'high' || obj.graphicsQuality === 'balanced' || obj.graphicsQuality === 'auto'
    ? obj.graphicsQuality
    : defaults.graphicsQuality;
  const touchMode = obj.touchControlsMode === 'auto' || obj.touchControlsMode === 'always' || obj.touchControlsMode === 'off'
    ? obj.touchControlsMode
    : defaults.touchControlsMode;

  return {
    sfxEnabled: typeof obj.sfxEnabled === 'boolean' ? obj.sfxEnabled : defaults.sfxEnabled,
    musicEnabled: typeof obj.musicEnabled === 'boolean' ? obj.musicEnabled : defaults.musicEnabled,
    volume: typeof obj.volume === 'number' && Number.isFinite(obj.volume)
      ? Math.max(0, Math.min(1, obj.volume))
      : defaults.volume,
    cameraSensitivity: typeof obj.cameraSensitivity === 'number' && Number.isFinite(obj.cameraSensitivity)
      ? Math.max(0.4, Math.min(2.0, obj.cameraSensitivity))
      : defaults.cameraSensitivity,
    graphicsQuality: quality,
    showFps: typeof obj.showFps === 'boolean' ? obj.showFps : defaults.showFps,
    touchControlsMode: touchMode,
  };
}

export function recordLevelCompletion(
  current: ProgressState,
  levelId: number,
  elapsedTime: number,
  now = Date.now(),
): { next: ProgressState; isNewBest: boolean; bestTime: number } {
  const clampedId = Math.max(1, Math.min(TOTAL_LEVELS, Math.floor(levelId)));
  const safeTime = Math.max(0.1, Number(elapsedTime.toFixed(2)));
  const prevRecord = current.completedLevels[clampedId];
  const isNewBest = !prevRecord || safeTime < prevRecord.bestTime;
  const bestTime = isNewBest ? safeTime : prevRecord.bestTime;
  const unlockedLevel = Math.min(TOTAL_LEVELS, Math.max(current.unlockedLevel, clampedId + 1));

  const next: ProgressState = {
    unlockedLevel,
    completedLevels: {
      ...current.completedLevels,
      [clampedId]: {
        bestTime,
        completedAt: now,
      },
    },
  };

  return { next, isNewBest, bestTime };
}

export function loadProgress(): ProgressState {
  try {
    const raw = window.localStorage.getItem(PROGRESS_STORAGE_KEY);
    if (!raw) return createDefaultProgress();
    return sanitizeProgress(JSON.parse(raw));
  } catch {
    return createDefaultProgress();
  }
}

export function saveProgress(progress: ProgressState): void {
  try {
    window.localStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // Ignore storage quota or private mode restrictions gracefully
  }
}

export function resetProgressStorage(): ProgressState {
  const fresh = createDefaultProgress();
  saveProgress(fresh);
  return fresh;
}

export function loadSettings(): SettingsState {
  try {
    const raw = window.localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return createDefaultSettings();
    return sanitizeSettings(JSON.parse(raw));
  } catch {
    return createDefaultSettings();
  }
}

export function saveSettings(settings: SettingsState): void {
  try {
    window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage errors gracefully
  }
}
