import type {
  DoorDef,
  LevelBlueprint,
  PlatformDef,
  SurfaceStyle,
} from './types';

function floor(
  id: string,
  x: number,
  topY: number,
  z: number,
  w: number,
  d: number,
  h = 1.2,
  style: SurfaceStyle = 'frozenStone',
  extra: Partial<PlatformDef> = {},
): PlatformDef {
  return {
    id,
    position: [x, topY - h * 0.5, z],
    size: [w, h, d],
    style,
    ...extra,
  };
}

function wall(
  id: string,
  x: number,
  baseY: number,
  z: number,
  w: number,
  height: number,
  d: number,
  style: SurfaceStyle = 'frozenStone',
): PlatformDef {
  return {
    id,
    position: [x, baseY + height * 0.5, z],
    size: [w, height, d],
    style,
  };
}

function framedGateZ(
  id: string,
  x: number,
  baseY: number,
  z: number,
  totalWidth: number,
  openingWidth: number,
  height: number,
  depth: number,
  requiredSignals: string[],
  wallStyle: SurfaceStyle,
  lintelStyle: SurfaceStyle,
  logic: 'AND' | 'OR' = 'AND',
): { walls: PlatformDef[]; door: DoorDef } {
  const sideWidth = Math.max(0.8, (totalWidth - openingWidth) * 0.5);
  const sideOffset = openingWidth * 0.5 + sideWidth * 0.5;
  const walls: PlatformDef[] = [
    wall(`${id}_wl`, x - sideOffset, baseY, z, sideWidth, height, depth, wallStyle),
    wall(`${id}_wr`, x + sideOffset, baseY, z, sideWidth, height, depth, wallStyle),
    wall(`${id}_top`, x, baseY + height, z, totalWidth, 1.0, depth, lintelStyle),
  ];
  const door: DoorDef = {
    id: `${id}_door`,
    position: [x, baseY + height * 0.5, z],
    size: [openingWidth - 0.08, height - 0.06, depth * 0.65],
    openOffset: [0, height + 0.55, 0],
    requiredSignals,
    logic,
  };
  return { walls, door };
}

function buildFrozenLevels(): LevelBlueprint[] {
  // =========================================================================
  // WORLD 5: FROZEN ABYSS (LEVELS 21–25)
  // =========================================================================

  // LEVEL 21: Frozen Entry — Slippery transparent ice & controlled momentum
  const g21 = framedGateZ(
    'l21_gate',
    0,
    0,
    -22.2,
    10.0,
    3.6,
    3.8,
    0.9,
    ['l21_sw1'],
    'frozenStone',
    'clearIce',
  );
  const level21: LevelBlueprint = {
    id: 21,
    title: 'Frozen Entry',
    tier: 'frozen',
    environment: 'frozen',
    objective: 'Master low-friction ice momentum, activate the frozen switch, and cross the glacial gap.',
    spawn: [0, 1.0, 6.2],
    portal: { position: [0, 0, -45.4] },
    fallY: -12,
    parTime: 36,
    platforms: [
      floor('l21_start', 0, 0, 4.0, 9.0, 8.0, 1.4, 'snow'),
      floor('l21_ice_main', 0, 0, -7.0, 8.2, 14.0, 1.1, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      // Ice gallery frozen stone curbs & baffles to teach controlled drift steering
      wall('l21_curb_l', -4.35, 0, -7.0, 0.55, 0.9, 14.0, 'frozenStone'),
      wall('l21_curb_r', 4.35, 0, -7.0, 0.55, 0.9, 14.0, 'frozenStone'),
      wall('l21_baf1', -1.8, 0, -4.5, 3.6, 1.5, 1.0, 'frozenStone'),
      wall('l21_baf2', 1.8, 0, -9.8, 3.6, 1.5, 1.0, 'frozenStone'),
      // Mid snow basin + side ice spur holding frozen crystal switch
      floor('l21_mid', 0, 0, -18.0, 10.0, 8.0, 1.4, 'snow'),
      floor('l21_spur_bridge', 6.5, 0, -18.0, 3.4, 3.8, 0.9, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      floor('l21_spur', 10.5, 0, -18.0, 5.2, 6.2, 1.3, 'frozenStone'),
      wall('l21_spur_back', 12.85, 0, -18.0, 0.5, 1.2, 6.2, 'frozenStone'),
      ...g21.walls,
      // Long transparent momentum glide runway + clean 2.8m jump gap to exit
      floor('l21_runway', 0, 0, -29.0, 5.8, 14.0, 1.1, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      wall('l21_pylon_l', -3.3, 0, -34.5, 0.8, 2.8, 0.8, 'frozenStone'),
      wall('l21_pylon_r', 3.3, 0, -34.5, 0.8, 2.8, 0.8, 'frozenStone'),
      floor('l21_exit', 0, 0, -43.5, 9.6, 9.4, 1.5, 'snow'),
      wall('l21_exit_back', 0, 0, -48.0, 9.6, 2.2, 0.6, 'frozenStone'),
    ],
    dynamicBodies: [],
    switches: [
      {
        id: 'l21_sw1',
        position: [10.6, 0, -18.0],
        kind: 'toggle',
        frozen: true,
      },
    ],
    pressurePlates: [],
    doors: [g21.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [
      { id: 'l21_cp1', position: [0, 0, -18.0] },
    ],
  };

  // LEVEL 22: Sliding Weight — Push & slide heavy low-friction blocks onto twin plates
  const g22 = framedGateZ(
    'l22_gate',
    0,
    0,
    -15.8,
    18.0,
    3.8,
    3.9,
    0.9,
    ['l22_p1', 'l22_p2'],
    'frozenStone',
    'clearIce',
  );
  const level22: LevelBlueprint = {
    id: 22,
    title: 'Sliding Weight',
    tier: 'frozen',
    environment: 'frozen',
    objective: 'Slide both heavy frost monoliths across the ice basin onto the twin pressure plates.',
    spawn: [0, 1.0, 10.6],
    portal: { position: [0, 0, -24.5] },
    fallY: -12,
    parTime: 55,
    platforms: [
      floor('l22_start', 0, 0, 9.0, 10.0, 7.0, 1.4, 'snow'),
      // Large transparent slippery ice rink with raised frozenStone perimeter curbs
      floor('l22_rink', 0, 0, -5.0, 18.0, 21.0, 1.2, 'clearIce', {
        slippery: true,
        friction: 0.035,
      }),
      wall('l22_w_l', -9.2, 0, -5.0, 0.7, 1.5, 21.4, 'frozenStone'),
      wall('l22_w_r', 9.2, 0, -5.0, 0.7, 1.5, 21.4, 'frozenStone'),
      wall('l22_w_sl', -7.2, 0, 5.4, 4.4, 1.5, 0.7, 'frozenStone'),
      wall('l22_w_sr', 7.2, 0, 5.4, 4.4, 1.5, 0.7, 'frozenStone'),
      // Central ice-arena baffles and backstop catch walls behind plates
      wall('l22_pil1', -1.8, 0, -4.5, 2.2, 2.2, 2.2, 'frozenStone'),
      wall('l22_pil2', 2.4, 0, -8.5, 2.2, 2.2, 2.2, 'frozenStone'),
      wall('l22_stop1', -5.8, 0, -13.6, 3.0, 1.4, 0.7, 'frozenStone'),
      wall('l22_stop2', 5.8, 0, -13.6, 3.0, 1.4, 0.7, 'frozenStone'),
      ...g22.walls,
      floor('l22_exit', 0, 0, -21.5, 10.5, 12.0, 1.5, 'snow'),
      wall('l22_exit_back', 0, 0, -27.2, 10.5, 2.4, 0.7, 'frozenStone'),
    ],
    dynamicBodies: [
      {
        id: 'l22_b1',
        shape: 'heavyCube',
        position: [-4.6, 0.88, 1.0],
        size: [1.55, 1.55, 1.55],
        mass: 2.1,
        grabbable: true,
        lowFriction: true,
      },
      {
        id: 'l22_b2',
        shape: 'heavyCube',
        position: [4.6, 0.88, -1.2],
        size: [1.55, 1.55, 1.55],
        mass: 2.1,
        grabbable: true,
        lowFriction: true,
      },
    ],
    switches: [],
    pressurePlates: [
      {
        id: 'l22_p1',
        position: [-5.8, 0, -11.4],
        size: [2.4, 2.4],
        requiresBlock: true,
      },
      {
        id: 'l22_p2',
        position: [5.8, 0, -11.4],
        size: [2.4, 2.4],
        requiresBlock: true,
      },
    ],
    doors: [g22.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [],
  };

  // LEVEL 23: Frozen Switches — Multiple pressure plates, movable cubes & timed frozen ice bridge
  const g23a = framedGateZ(
    'l23_gate1',
    0,
    0,
    -10.2,
    14.0,
    3.6,
    3.8,
    0.9,
    ['l23_p1', 'l23_p2'],
    'frozenStone',
    'clearIce',
  );
  const g23b = framedGateZ(
    'l23_gate2',
    0,
    0,
    -31.5,
    10.0,
    3.6,
    3.8,
    0.9,
    ['l23_sw1'],
    'frozenStone',
    'clearIce',
  );
  const level23: LevelBlueprint = {
    id: 23,
    title: 'Frozen Switches',
    tier: 'frozen',
    environment: 'frozen',
    objective: 'Weight both frost plates to enter the crystal alcove, then trigger the timed switch to ride the ice bridge.',
    spawn: [0, 1.0, 11.8],
    portal: { position: [0, 0, -37.5] },
    fallY: -12,
    parTime: 65,
    platforms: [
      floor('l23_start', 0, 0, 10.0, 10.0, 8.0, 1.4, 'snow'),
      // Courtyard with stone center and slippery ice wings
      floor('l23_court_c', 0, 0, -2.0, 5.2, 16.0, 1.3, 'frozenStone'),
      floor('l23_court_l', -4.8, 0, -2.0, 4.4, 16.0, 1.2, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      floor('l23_court_r', 4.8, 0, -2.0, 4.4, 16.0, 1.2, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      wall('l23_cl', -7.25, 0, -2.0, 0.55, 1.4, 16.0, 'frozenStone'),
      wall('l23_cr', 7.25, 0, -2.0, 0.55, 1.4, 16.0, 'frozenStone'),
      ...g23a.walls,
      // Crystal alcove with timed frozen switch
      floor('l23_alcove', 0, 0, -13.5, 10.0, 7.0, 1.4, 'snow'),
      wall('l23_al_l', -5.2, 0, -13.5, 0.55, 1.5, 7.0, 'frozenStone'),
      wall('l23_al_r', 5.2, 0, -13.5, 0.55, 1.5, 7.0, 'frozenStone'),
      // Exit island across chasm
      floor('l23_exit', 0, 0, -35.5, 10.0, 9.0, 1.5, 'snow'),
      ...g23b.walls,
      wall('l23_exit_back', 0, 0, -39.8, 10.0, 2.2, 0.6, 'frozenStone'),
    ],
    dynamicBodies: [
      {
        id: 'l23_b1',
        shape: 'cube',
        position: [-4.4, 0.8, 2.6],
        size: [1.4, 1.4, 1.4],
        mass: 1.5,
        grabbable: true,
        lowFriction: true,
      },
      {
        id: 'l23_b2',
        shape: 'cube',
        position: [4.4, 0.8, 2.6],
        size: [1.4, 1.4, 1.4],
        mass: 1.5,
        grabbable: true,
        lowFriction: true,
      },
    ],
    switches: [
      {
        id: 'l23_sw1',
        position: [3.2, 0, -14.2],
        kind: 'timed',
        duration: 13.5,
        frozen: true,
      },
    ],
    pressurePlates: [
      {
        id: 'l23_p1',
        position: [-4.8, 0, -6.8],
        size: [2.3, 2.3],
        requiresBlock: true,
      },
      {
        id: 'l23_p2',
        position: [4.8, 0, -6.8],
        size: [2.3, 2.3],
        requiresBlock: true,
      },
    ],
    doors: [g23a.door, g23b.door],
    movingPlatforms: [
      {
        id: 'l23_mp1',
        startPos: [0, -0.35, -19.8],
        endPos: [0, -0.35, -28.4],
        size: [4.2, 0.7, 5.2],
        speed: 5.4,
        requiredSignals: ['l23_sw1'],
        pauseAtEnds: 0.6,
        style: 'clearIce',
        slippery: true,
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [
      { id: 'l23_cp1', position: [0, 0, -13.0] },
    ],
  };

  // LEVEL 24: Breaking Passage — Collapsing ice platforms, timing & precise movement
  const g24a = framedGateZ(
    'l24_gate1',
    0,
    0,
    -23.8,
    11.0,
    3.6,
    3.8,
    0.9,
    ['l24_p1'],
    'frozenStone',
    'clearIce',
  );
  const g24b = framedGateZ(
    'l24_gate2',
    0,
    0,
    -44.2,
    10.0,
    3.6,
    3.8,
    0.9,
    ['l24_sw1'],
    'frozenStone',
    'clearIce',
  );
  const level24: LevelBlueprint = {
    id: 24,
    title: 'Breaking Passage',
    tier: 'frozen',
    environment: 'frozen',
    objective: 'Cross fracturing ice bridges before they collapse, unlock the gate, and race the timed span.',
    spawn: [0, 1.0, 11.4],
    portal: { position: [0, 0, -50.8] },
    fallY: -12,
    parTime: 65,
    platforms: [
      floor('l24_start', 0, 0, 10.0, 8.4, 7.0, 1.4, 'snow'),
      // Span 1: 4 sequential collapsing ice platforms
      floor('l24_ice1', 0, 0, 3.2, 4.5, 4.2, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.15, respawnDelay: 3.6 },
      }),
      floor('l24_ice2', -1.5, 0, -2.0, 4.4, 4.0, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.1, respawnDelay: 3.6 },
      }),
      floor('l24_ice3', 1.5, 0, -7.2, 4.4, 4.0, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.1, respawnDelay: 3.6 },
      }),
      floor('l24_ice4', 0, 0, -12.4, 4.5, 4.0, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.15, respawnDelay: 3.6 },
      }),
      // Mid checkpoint island
      floor('l24_mid', 0, 0, -19.5, 11.0, 9.0, 1.4, 'frozenStone'),
      ...g24a.walls,
      // Span 2: Timed alternating breakable + slippery anchor runway
      floor('l24_ice5', 0, 0, -27.2, 4.5, 4.4, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.0, respawnDelay: 3.4 },
      }),
      floor('l24_ice6', 0, 0, -32.6, 5.0, 4.4, 0.9, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      floor('l24_ice7', 0, 0, -38.0, 4.5, 4.4, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.0, respawnDelay: 3.4 },
      }),
      floor('l24_ice8', 0, 0, -42.2, 4.8, 3.2, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.05, respawnDelay: 3.4 },
      }),
      // Far Glacier Exit Vault
      floor('l24_exit', 0, 0, -48.5, 10.0, 9.0, 1.5, 'snow'),
      ...g24b.walls,
      wall('l24_exit_back', 0, 0, -52.8, 10.0, 2.4, 0.6, 'frozenStone'),
    ],
    dynamicBodies: [
      {
        id: 'l24_b1',
        shape: 'cube',
        position: [-3.6, 0.8, -19.5],
        size: [1.4, 1.4, 1.4],
        mass: 1.4,
        grabbable: true,
        lowFriction: true,
      },
    ],
    switches: [
      {
        id: 'l24_sw1',
        position: [-2.8, 0, -22.2],
        kind: 'timed',
        duration: 12.5,
        frozen: true,
      },
    ],
    pressurePlates: [
      {
        id: 'l24_p1',
        position: [3.6, 0, -19.5],
        size: [2.3, 2.3],
        requiresBlock: true,
      },
    ],
    doors: [g24a.door, g24b.door],
    movingPlatforms: [],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    checkpoints: [
      { id: 'l24_cp1', position: [0, 0, -17.0] },
    ],
  };

  // LEVEL 25: Icebound Trial — World 5 multi-stage finale
  const g25 = framedGateZ(
    'l25_gate',
    0,
    0,
    -61.7,
    10.0,
    3.8,
    4.0,
    0.9,
    ['l25_p2', 'l25_sw1'],
    'frozenStone',
    'clearIce',
  );
  const level25: LevelBlueprint = {
    id: 25,
    title: 'Icebound Trial',
    tier: 'frozen',
    environment: 'frozen',
    objective: 'Slide the monolith to align the ice span, cross fracturing slabs, and seal both frost locks.',
    spawn: [0, 1.0, 13.0],
    portal: { position: [0, 0, -69.0] },
    fallY: -12,
    parTime: 95,
    platforms: [
      // Stage 1: Sliding monolith arena
      floor('l25_start', 0, 0, 12.0, 9.0, 6.0, 1.4, 'snow'),
      floor('l25_court1', 0, 0, 2.0, 14.0, 14.0, 1.2, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      wall('l25_c1_l', -7.2, 0, 2.0, 0.6, 1.4, 14.4, 'frozenStone'),
      wall('l25_c1_r', 7.2, 0, 2.0, 0.6, 1.4, 14.4, 'frozenStone'),
      wall('l25_stop1', 4.5, 0, -3.7, 3.0, 1.4, 0.7, 'frozenStone'),
      wall('l25_baf1', -0.4, 0, 1.2, 2.2, 2.0, 2.2, 'frozenStone'),
      // Stage 2: Mid-Glacier checkpoint + staggered breaking stones
      floor('l25_mid', 0, 0, -22.0, 10.0, 8.0, 1.4, 'frozenStone'),
      floor('l25_brk1', -2.0, 0, -28.8, 4.5, 3.8, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.0, respawnDelay: 3.5 },
      }),
      floor('l25_brk2', 2.0, 0, -33.6, 4.5, 3.8, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.0, respawnDelay: 3.5 },
      }),
      floor('l25_brk3', 0, 0, -38.4, 4.6, 3.8, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.0, respawnDelay: 3.5 },
      }),
      // Stage 3: Upper Frost Bastion (Checkpoint 2 + Cube 2 + Timed Switch)
      floor('l25_bastion_c', 0, 0, -46.5, 14.0, 11.0, 1.3, 'clearIce', {
        slippery: true,
        friction: 0.04,
      }),
      floor('l25_bastion_entry', 0, 0, -41.8, 8.0, 2.4, 1.35, 'snow'),
      wall('l25_b_l', -7.2, 0, -46.5, 0.6, 1.4, 11.4, 'frozenStone'),
      wall('l25_b_r', 7.2, 0, -46.5, 0.6, 1.4, 11.4, 'frozenStone'),
      wall('l25_stop2', 4.8, 0, -50.6, 3.0, 1.4, 0.7, 'frozenStone'),
      // Final Breakable Bridge Sprint
      floor('l25_brk4', 0, 0, -54.6, 4.6, 3.8, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.05, respawnDelay: 3.5 },
      }),
      floor('l25_brk5', 0, 0, -59.2, 4.6, 3.8, 0.75, 'clearIce', {
        slippery: true,
        friction: 0.05,
        breakable: { collapseDelay: 1.05, respawnDelay: 3.5 },
      }),
      ...g25.walls,
      floor('l25_exit', 0, 0, -66.5, 10.4, 10.0, 1.6, 'snow'),
      wall('l25_exit_back', 0, 0, -71.3, 10.4, 2.8, 0.7, 'frozenStone'),
    ],
    dynamicBodies: [
      {
        id: 'l25_b1',
        shape: 'heavyCube',
        position: [-4.2, 0.88, 5.2],
        size: [1.55, 1.55, 1.55],
        mass: 2.0,
        grabbable: true,
        lowFriction: true,
      },
      {
        id: 'l25_b2',
        shape: 'cube',
        position: [-4.5, 0.8, -45.5],
        size: [1.45, 1.45, 1.45],
        mass: 1.6,
        grabbable: true,
        lowFriction: true,
      },
    ],
    switches: [
      {
        id: 'l25_sw1',
        position: [-4.8, 0, -49.5],
        kind: 'timed',
        duration: 14.0,
        frozen: true,
      },
    ],
    pressurePlates: [
      {
        id: 'l25_p1',
        position: [4.5, 0, -1.8],
        size: [2.4, 2.4],
        requiresBlock: true,
      },
      {
        id: 'l25_p2',
        position: [4.8, 0, -48.5],
        size: [2.4, 2.4],
        requiresBlock: true,
      },
    ],
    doors: [g25.door],
    movingPlatforms: [],
    rotatingBridges: [
      {
        id: 'l25_rb1',
        pivot: [0, -0.325, -11.5],
        size: [3.8, 0.65, 12.2],
        restAngleY: Math.PI / 2,
        activeAngleY: 0,
        speed: 1.4,
        requiredSignals: ['l25_p1'],
        style: 'clearIce',
        slippery: true,
      },
    ],
    gravityZones: [],
    lasers: [],
    checkpoints: [
      { id: 'l25_cp1', position: [0, 0, -21.0] },
      { id: 'l25_cp2', position: [0, 0, -41.8] },
    ],
  };

  return [level21, level22, level23, level24, level25];
}

function buildInfernoLevels(): LevelBlueprint[] {
  // =========================================================================
  // WORLD 6: INFERNO CORE (LEVELS 26–30)
  // =========================================================================

  // LEVEL 26: Molten Crossing — Moving industrial platforms above dangerous lava
  const level26: LevelBlueprint = {
    id: 26,
    title: 'Molten Crossing',
    tier: 'inferno',
    environment: 'inferno',
    objective: 'Ride the industrial shuttles over molten lava, power the foundry lift, and evade the furnace ram.',
    spawn: [0, 1.0, 11.8],
    portal: { position: [0, 4.0, -53.6] },
    fallY: -10,
    parTime: 55,
    platforms: [
      floor('l26_start', 0, 0, 10.0, 10.0, 8.0, 1.8, 'basalt'),
      wall('l26_p1', -4.6, 0, 6.4, 0.9, 3.0, 0.9, 'industrialMetal'),
      wall('l26_p2', 4.6, 0, 6.4, 0.9, 3.0, 0.9, 'industrialMetal'),
      // Mid basalt pier between shuttles
      floor('l26_pier', 0, 0, -9.8, 6.8, 5.2, 2.0, 'basalt'),
      // Mid foundry deck with checkpoint + lift switch
      floor('l26_mid', 0, 0, -22.5, 11.0, 9.0, 2.0, 'basalt'),
      wall('l26_mid_l', -5.2, 0, -22.5, 0.6, 1.4, 9.0, 'industrialMetal'),
      wall('l26_mid_r', 5.2, 0, -22.5, 0.6, 1.4, 9.0, 'industrialMetal'),
      // Elevated basalt bridge patrolled by lethal furnace ram
      floor('l26_upper', 0, 4.0, -39.5, 7.4, 15.6, 1.6, 'basalt'),
      wall('l26_up_rail_l', -3.8, 4.0, -39.5, 0.45, 0.7, 15.6, 'industrialMetal'),
      wall('l26_up_rail_r', 3.8, 4.0, -39.5, 0.45, 0.7, 15.6, 'industrialMetal'),
      // Elevated exit sanctuary
      floor('l26_exit', 0, 4.0, -51.5, 10.0, 9.0, 2.2, 'basalt'),
      wall('l26_exit_back', 0, 4.0, -55.8, 10.0, 2.6, 0.7, 'industrialMetal'),
    ],
    dynamicBodies: [],
    switches: [
      {
        id: 'l26_sw1',
        position: [3.6, 0, -23.5],
        kind: 'toggle',
      },
    ],
    pressurePlates: [],
    doors: [],
    movingPlatforms: [
      {
        id: 'l26_mp1',
        startPos: [0, -0.35, 3.4],
        endPos: [0, -0.35, -4.8],
        size: [4.2, 0.7, 4.2],
        speed: 3.6,
        pauseAtEnds: 0.7,
        style: 'industrialMetal',
      },
      {
        id: 'l26_mp2',
        startPos: [-3.0, -0.35, -15.2],
        endPos: [3.0, -0.35, -15.2],
        size: [4.4, 0.7, 4.2],
        speed: 3.3,
        pauseAtEnds: 0.55,
        style: 'industrialMetal',
      },
      {
        id: 'l26_elev',
        startPos: [0, -0.35, -29.5],
        endPos: [0, 3.65, -29.5],
        size: [4.6, 0.7, 4.4],
        speed: 3.2,
        requiredSignals: ['l26_sw1'],
        pauseAtEnds: 1.0,
        style: 'industrialMetal',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [],
    lavaHazards: [
      {
        id: 'l26_lava1',
        position: [0, -2.5, -18.0],
        size: [40, 1.8, 66],
        shimmer: true,
      },
    ],
    movingObstacles: [
      {
        id: 'l26_obs1',
        startPos: [-2.4, 4.85, -39.5],
        endPos: [2.4, 4.85, -39.5],
        size: [2.0, 1.45, 1.35],
        speed: 3.5,
        pauseAtEnds: 0.35,
        lethal: true,
        style: 'industrialMetal',
      },
    ],
    checkpoints: [
      { id: 'l26_cp1', position: [0, 0, -20.5] },
    ],
  };

  // LEVEL 27: Thermal Mechanism — Activate heat-sensitive receptors using thermal cores
  const g27 = framedGateZ(
    'l27_gate',
    0,
    0,
    -34.2,
    15.0,
    3.8,
    4.0,
    0.9,
    ['l27_tp2', 'l27_sw1'],
    'basalt',
    'industrialMetal',
  );
  const level27: LevelBlueprint = {
    id: 27,
    title: 'Thermal Mechanism',
    tier: 'inferno',
    environment: 'inferno',
    objective: 'Place glowing thermal cores onto heat-sensitive receptors to bridge the magma and open the blast door.',
    spawn: [0, 1.0, 12.0],
    portal: { position: [0, 0, -42.4] },
    fallY: -10,
    parTime: 65,
    platforms: [
      floor('l27_start', 0, 0, 10.0, 12.0, 9.0, 1.8, 'basalt'),
      // Room 1: Foundry Courtyard
      floor('l27_room1', 0, 0, -1.0, 15.0, 13.0, 1.8, 'basalt'),
      wall('l27_r1_l', -7.25, 0, -1.0, 0.55, 1.4, 13.0, 'industrialMetal'),
      wall('l27_r1_r', 7.25, 0, -1.0, 0.55, 1.4, 13.0, 'industrialMetal'),
      // Room 2: Far Volcanic Platform
      floor('l27_room2', 0, 0, -27.5, 15.0, 13.0, 1.8, 'basalt'),
      wall('l27_r2_l', -7.25, 0, -27.5, 0.55, 1.4, 13.0, 'industrialMetal'),
      wall('l27_r2_r', 7.25, 0, -27.5, 0.55, 1.4, 13.0, 'industrialMetal'),
      ...g27.walls,
      floor('l27_exit', 0, 0, -39.5, 10.5, 11.0, 2.0, 'basalt'),
      wall('l27_exit_back', 0, 0, -44.8, 10.5, 2.6, 0.7, 'industrialMetal'),
    ],
    dynamicBodies: [
      {
        id: 'l27_decoy',
        shape: 'heavyCube',
        position: [-4.4, 0.85, 2.2],
        size: [1.45, 1.45, 1.45],
        mass: 1.8,
        grabbable: true,
        heatConductive: false,
      },
      {
        id: 'l27_core1',
        shape: 'cube',
        position: [4.4, 0.85, 2.2],
        size: [1.45, 1.45, 1.45],
        mass: 1.5,
        grabbable: true,
        heatConductive: true,
      },
      {
        id: 'l27_core2',
        shape: 'cube',
        position: [-5.6, 0.85, -27.8],
        size: [1.45, 1.45, 1.45],
        mass: 1.5,
        grabbable: true,
        heatConductive: true,
      },
    ],
    switches: [
      {
        id: 'l27_sw1',
        position: [-4.6, 0, -31.8],
        kind: 'toggle',
      },
    ],
    pressurePlates: [
      {
        id: 'l27_tp1',
        position: [0, 0, -5.0],
        size: [2.3, 2.3],
        thermalOnly: true,
      },
      {
        id: 'l27_tp2',
        position: [4.6, 0, -30.5],
        size: [2.3, 2.3],
        thermalOnly: true,
      },
    ],
    doors: [g27.door],
    movingPlatforms: [
      {
        id: 'l27_mp1',
        startPos: [0, -0.35, -10.0],
        endPos: [0, -0.35, -18.5],
        size: [4.4, 0.7, 4.6],
        speed: 4.0,
        requiredSignals: ['l27_tp1'],
        pauseAtEnds: 0.8,
        style: 'industrialMetal',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [
      {
        id: 'l27_las1',
        start: [-3.4, 0.9, -24.0],
        end: [-3.4, 0.9, -31.5],
        cyclePeriod: 3.6,
        activeDuty: 0.44,
      },
    ],
    lavaHazards: [
      {
        id: 'l27_lava1',
        position: [0, -2.5, -14.0],
        size: [44, 1.8, 60],
        shimmer: true,
      },
    ],
    movingObstacles: [],
    checkpoints: [
      { id: 'l27_cp1', position: [0, 0, -22.8] },
    ],
  };

  // LEVEL 28: Rotating Furnace — Counter-rotating platforms & momentum-based movement
  const level28: LevelBlueprint = {
    id: 28,
    title: 'Rotating Furnace',
    tier: 'inferno',
    environment: 'inferno',
    objective: 'Cross counter-rotating furnace spans above the caldera and align the final turntable with the thermal core.',
    spawn: [0, 1.0, 13.8],
    portal: { position: [0, 0, -58.0] },
    fallY: -10,
    parTime: 70,
    platforms: [
      floor('l28_start', 0, 0, 12.0, 9.2, 8.0, 2.0, 'basalt'),
      floor('l28_pier', 0, 0, -10.0, 7.6, 6.0, 2.0, 'basalt'),
      // Central Reactor Hub
      floor('l28_hub', 0, 0, -32.5, 12.4, 10.0, 2.0, 'basalt'),
      wall('l28_hub_l', -6.0, 0, -32.5, 0.55, 1.4, 10.0, 'industrialMetal'),
      wall('l28_hub_r', 6.0, 0, -32.5, 0.55, 1.4, 10.0, 'industrialMetal'),
      // Exit Caldera Sanctuary
      floor('l28_exit', 0, 0, -55.5, 10.4, 10.0, 2.2, 'basalt'),
      wall('l28_exit_back', 0, 0, -60.3, 10.4, 2.8, 0.7, 'industrialMetal'),
    ],
    dynamicBodies: [
      {
        id: 'l28_core1',
        shape: 'cube',
        position: [-4.4, 0.85, -35.6],
        size: [1.45, 1.45, 1.45],
        mass: 1.5,
        grabbable: true,
        heatConductive: true,
      },
    ],
    switches: [],
    pressurePlates: [
      {
        id: 'l28_tp1',
        position: [4.4, 0, -35.6],
        size: [2.3, 2.3],
        thermalOnly: true,
      },
    ],
    doors: [],
    movingPlatforms: [],
    rotatingBridges: [
      {
        id: 'l28_rb1',
        pivot: [0, -0.35, 0.5],
        size: [3.8, 0.7, 13.5],
        restAngleY: 0,
        activeAngleY: 0,
        speed: 0,
        continuousSpeed: 0.45,
        style: 'industrialMetal',
      },
      {
        id: 'l28_rb2',
        pivot: [0, -0.35, -20.5],
        size: [3.8, 0.7, 13.5],
        restAngleY: Math.PI / 2,
        activeAngleY: 0,
        speed: 0,
        continuousSpeed: -0.5,
        style: 'industrialMetal',
      },
      {
        id: 'l28_rb3',
        pivot: [0, -0.35, -44.2],
        size: [4.0, 0.7, 12.4],
        restAngleY: Math.PI / 2,
        activeAngleY: 0,
        speed: 1.25,
        requiredSignals: ['l28_tp1'],
        style: 'industrialMetal',
      },
    ],
    gravityZones: [],
    lasers: [],
    lavaHazards: [
      {
        id: 'l28_lava1',
        position: [0, -2.6, -22.0],
        size: [48, 1.8, 80],
        shimmer: true,
      },
    ],
    movingObstacles: [
      {
        id: 'l28_obs1',
        startPos: [-4.0, 0.85, -32.8],
        endPos: [4.0, 0.85, -32.8],
        size: [2.0, 1.4, 1.3],
        speed: 3.4,
        pauseAtEnds: 0.35,
        lethal: true,
        style: 'industrialMetal',
      },
    ],
    checkpoints: [
      { id: 'l28_cp1', position: [0, 0, -10.0] },
      { id: 'l28_cp2', position: [0, 0, -29.0] },
    ],
  };

  // LEVEL 29: Meltdown Sequence — Connected thermal & timed mechanisms under time pressure
  const g29a = framedGateZ(
    'l29_gate1',
    0,
    0,
    -29.8,
    11.0,
    3.6,
    3.9,
    0.9,
    ['l29_tsw1'],
    'basalt',
    'industrialMetal',
  );
  const g29b = framedGateZ(
    'l29_gate2',
    0,
    0,
    -52.6,
    10.0,
    3.6,
    3.9,
    0.9,
    ['l29_tsw2'],
    'basalt',
    'industrialMetal',
  );
  const level29: LevelBlueprint = {
    id: 29,
    title: 'Meltdown Sequence',
    tier: 'inferno',
    environment: 'inferno',
    objective: 'Shut down the laser grid with the thermal core, then chain both temperature-controlled switches before lockdown.',
    spawn: [0, 1.0, 13.0],
    portal: { position: [0, 0, -60.0] },
    fallY: -10,
    parTime: 80,
    platforms: [
      floor('l29_start', 0, 0, 11.0, 11.0, 9.0, 1.8, 'basalt'),
      // Section 1: Thermal Receptor Plaza
      floor('l29_plaza', 0, 0, 0.5, 13.0, 12.0, 1.8, 'basalt'),
      wall('l29_pl_l', -6.25, 0, 0.5, 0.55, 1.4, 12.0, 'industrialMetal'),
      wall('l29_pl_r', 6.25, 0, 0.5, 0.55, 1.4, 12.0, 'industrialMetal'),
      // Section 2: Thermal Switch 1 Control Platform
      floor('l29_ctrl', 0, 0, -10.0, 11.0, 9.0, 1.8, 'basalt'),
      // Section 3: Inner Meltdown Deck + Industrial Catwalk
      floor('l29_inner', 0, 0, -34.5, 11.0, 10.0, 1.8, 'basalt'),
      ...g29a.walls,
      floor('l29_catwalk', 0, 0, -46.0, 5.8, 13.0, 1.2, 'industrialMetal'),
      ...g29b.walls,
      floor('l29_exit', 0, 0, -57.5, 10.4, 10.0, 2.0, 'basalt'),
      wall('l29_exit_back', 0, 0, -62.3, 10.4, 2.8, 0.7, 'industrialMetal'),
    ],
    dynamicBodies: [
      {
        id: 'l29_core1',
        shape: 'cube',
        position: [-4.6, 0.85, 3.0],
        size: [1.45, 1.45, 1.45],
        mass: 1.5,
        grabbable: true,
        heatConductive: true,
      },
    ],
    switches: [
      {
        id: 'l29_tsw1',
        position: [-3.5, 0, -12.5],
        kind: 'thermal',
        duration: 15.0,
      },
      {
        id: 'l29_tsw2',
        position: [3.6, 0, -36.8],
        kind: 'thermal',
        duration: 11.5,
      },
    ],
    pressurePlates: [
      {
        id: 'l29_tp1',
        position: [4.6, 0, -2.5],
        size: [2.3, 2.3],
        thermalOnly: true,
      },
    ],
    doors: [g29a.door, g29b.door],
    movingPlatforms: [
      {
        id: 'l29_mp1',
        startPos: [0, -0.35, -17.0],
        endPos: [0, -0.35, -27.0],
        size: [4.4, 0.7, 4.6],
        speed: 5.2,
        requiredSignals: ['l29_tsw1'],
        pauseAtEnds: 0.5,
        style: 'industrialMetal',
      },
    ],
    rotatingBridges: [],
    gravityZones: [],
    lasers: [
      {
        id: 'l29_las1',
        start: [-5.6, 0.9, -5.2],
        end: [5.6, 0.9, -5.2],
        disableSignals: ['l29_tp1'],
      },
    ],
    lavaHazards: [
      {
        id: 'l29_lava1',
        position: [0, -2.5, -26.0],
        size: [44, 1.8, 80],
        shimmer: true,
      },
    ],
    movingObstacles: [
      {
        id: 'l29_obs1',
        startPos: [-2.0, 0.85, -46.0],
        endPos: [2.0, 0.85, -46.0],
        size: [1.8, 1.4, 1.3],
        speed: 3.7,
        pauseAtEnds: 0.3,
        lethal: true,
        style: 'industrialMetal',
      },
    ],
    checkpoints: [
      { id: 'l29_cp1', position: [0, 0, -8.5] },
      { id: 'l29_cp2', position: [0, 0, -32.2] },
    ],
  };

  // LEVEL 30: Inferno Trial — Grand 3-stage campaign finale
  const g30 = framedGateZ(
    'l30_gate',
    0,
    0,
    -74.2,
    11.0,
    4.0,
    4.2,
    0.95,
    ['l30_tp2', 'l30_tsw1'],
    'basalt',
    'industrialMetal',
  );
  const level30: LevelBlueprint = {
    id: 30,
    title: 'Inferno Trial',
    tier: 'inferno',
    environment: 'inferno',
    objective: 'Conquer the Inferno Core: ride molten shuttles, align rotating furnaces, and power twin thermal seals.',
    spawn: [0, 1.0, 13.8],
    portal: { position: [0, 0, -82.5] },
    fallY: -10,
    parTime: 115,
    platforms: [
      // Stage 1: Gatehouse + Mid Island
      floor('l30_start', 0, 0, 12.0, 10.0, 8.0, 2.0, 'basalt'),
      floor('l30_mid1', 0, 0, -8.5, 8.2, 6.8, 2.0, 'basalt'),
      // Stage 2: Core Foundry Deck
      floor('l30_foundry', 0, 0, -30.5, 14.0, 11.0, 2.0, 'basalt'),
      wall('l30_f_l', -6.75, 0, -30.5, 0.55, 1.5, 11.0, 'industrialMetal'),
      wall('l30_f_r', 6.75, 0, -30.5, 0.55, 1.5, 11.0, 'industrialMetal'),
      // Stage 3: Upper Magma Citadel + Final Furnace Run
      floor('l30_citadel', 0, 0, -55.0, 15.0, 12.0, 2.0, 'basalt'),
      wall('l30_c_l', -7.25, 0, -55.0, 0.55, 1.5, 12.0, 'industrialMetal'),
      wall('l30_c_r', 7.25, 0, -55.0, 0.55, 1.5, 12.0, 'industrialMetal'),
      floor('l30_run', 0, 0, -67.5, 6.4, 13.0, 1.3, 'industrialMetal'),
      ...g30.walls,
      floor('l30_exit', 0, 0, -79.5, 11.2, 11.0, 2.2, 'basalt'),
      wall('l30_exit_back', 0, 0, -84.8, 11.2, 3.2, 0.8, 'industrialMetal'),
    ],
    dynamicBodies: [
      {
        id: 'l30_core1',
        shape: 'cube',
        position: [-4.8, 0.85, -31.0],
        size: [1.45, 1.45, 1.45],
        mass: 1.6,
        grabbable: true,
        heatConductive: true,
      },
      {
        id: 'l30_core2',
        shape: 'cube',
        position: [-5.6, 0.85, -55.5],
        size: [1.45, 1.45, 1.45],
        mass: 1.6,
        grabbable: true,
        heatConductive: true,
      },
    ],
    switches: [
      {
        id: 'l30_tsw1',
        position: [0, 0, -58.8],
        kind: 'thermal',
        duration: 15.0,
      },
    ],
    pressurePlates: [
      {
        id: 'l30_tp1',
        position: [4.8, 0, -33.0],
        size: [2.3, 2.3],
        thermalOnly: true,
      },
      {
        id: 'l30_tp2',
        position: [5.2, 0, -57.5],
        size: [2.3, 2.3],
        thermalOnly: true,
      },
    ],
    doors: [g30.door],
    movingPlatforms: [
      {
        id: 'l30_mp1',
        startPos: [0, -0.35, 5.4],
        endPos: [0, -0.35, -2.6],
        size: [4.2, 0.7, 4.2],
        speed: 3.8,
        pauseAtEnds: 0.65,
        style: 'industrialMetal',
      },
    ],
    rotatingBridges: [
      {
        id: 'l30_rb1',
        pivot: [0, -0.35, -18.5],
        size: [3.8, 0.7, 12.6],
        restAngleY: 0,
        activeAngleY: 0,
        speed: 0,
        continuousSpeed: 0.46,
        style: 'industrialMetal',
      },
      {
        id: 'l30_rb2',
        pivot: [0, -0.35, -42.5],
        size: [4.0, 0.7, 12.6],
        restAngleY: Math.PI / 2,
        activeAngleY: 0,
        speed: 1.35,
        requiredSignals: ['l30_tp1'],
        style: 'industrialMetal',
      },
    ],
    gravityZones: [],
    lasers: [
      {
        id: 'l30_las1',
        start: [-6.0, 0.9, -35.8],
        end: [6.0, 0.9, -35.8],
        disableSignals: ['l30_tp1'],
      },
      {
        id: 'l30_las2',
        start: [-3.5, 0.9, -51.8],
        end: [-3.5, 0.9, -59.2],
        cyclePeriod: 3.6,
        activeDuty: 0.42,
      },
    ],
    lavaHazards: [
      {
        id: 'l30_lava1',
        position: [0, -2.8, -36.0],
        size: [56, 2.0, 108],
        shimmer: true,
      },
    ],
    movingObstacles: [
      {
        id: 'l30_obs1',
        startPos: [-2.8, 0.85, -8.5],
        endPos: [2.8, 0.85, -8.5],
        size: [1.8, 1.4, 1.3],
        speed: 3.4,
        pauseAtEnds: 0.35,
        lethal: true,
        style: 'industrialMetal',
      },
      {
        id: 'l30_obs2',
        startPos: [2.1, 0.85, -67.5],
        endPos: [-2.1, 0.85, -67.5],
        size: [1.9, 1.4, 1.3],
        speed: 3.9,
        pauseAtEnds: 0.3,
        lethal: true,
        style: 'industrialMetal',
      },
    ],
    checkpoints: [
      { id: 'l30_cp1', position: [0, 0, -26.8] },
      { id: 'l30_cp2', position: [0, 0, -50.8] },
    ],
  };

  return [level26, level27, level28, level29, level30];
}

export const FROZEN_LEVELS: LevelBlueprint[] = buildFrozenLevels();
export const INFERNO_LEVELS: LevelBlueprint[] = buildInfernoLevels();
export const EXPANSION_LEVELS: LevelBlueprint[] = [
  ...FROZEN_LEVELS,
  ...INFERNO_LEVELS,
];
