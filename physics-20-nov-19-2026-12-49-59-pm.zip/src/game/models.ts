import * as THREE from 'three';
import type { ProceduralTextureSet } from './textures';
import type { DynamicShape, SurfaceStyle, SwitchKind } from './types';

export interface MaterialLibrary {
  stone: THREE.MeshStandardMaterial;
  metal: THREE.MeshStandardMaterial;
  trim: THREE.MeshStandardMaterial;
  ice: THREE.MeshStandardMaterial;
  bounce: THREE.MeshStandardMaterial;
  accent: THREE.MeshStandardMaterial;
  darkFrame: THREE.MeshStandardMaterial;
  bronze: THREE.MeshStandardMaterial;
  cyanEmissive: THREE.MeshStandardMaterial;
  amberEmissive: THREE.MeshStandardMaterial;
  crimsonEmissive: THREE.MeshStandardMaterial;
  contactShadow: THREE.MeshBasicMaterial;
  // World 5: Frozen Abyss materials
  frozenStone: THREE.MeshStandardMaterial;
  clearIce: THREE.MeshStandardMaterial;
  snow: THREE.MeshStandardMaterial;
  frostEmissive: THREE.MeshStandardMaterial;
  // World 6: Inferno Core materials
  basalt: THREE.MeshStandardMaterial;
  industrialMetal: THREE.MeshStandardMaterial;
  lava: THREE.MeshStandardMaterial;
  moltenEmissive: THREE.MeshStandardMaterial;
  dispose: () => void;
}

export function createMaterialLibrary(
  textures: ProceduralTextureSet,
  _isSoftwareGl: boolean,
): MaterialLibrary {
  const stone = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.stoneMap,
    bumpMap: textures.stoneBump,
    bumpScale: 0.045,
    roughness: 0.82,
    metalness: 0.08,
  });

  const metal = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.metalMap,
    bumpMap: textures.metalBump,
    bumpScale: 0.03,
    roughness: 0.34,
    metalness: 0.78,
  });

  const trim = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.trimMap,
    roughness: 0.45,
    metalness: 0.62,
  });

  const ice = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.iceMap,
    roughness: 0.16,
    metalness: 0.35,
  });

  const bounce = new THREE.MeshStandardMaterial({
    color: 0x0ea5e9,
    emissive: 0x0284c7,
    emissiveIntensity: 0.65,
    roughness: 0.25,
    metalness: 0.5,
  });

  const accent = new THREE.MeshStandardMaterial({
    color: 0x2a3b4e,
    map: textures.metalMap,
    roughness: 0.32,
    metalness: 0.72,
    emissive: 0x0c4a6e,
    emissiveIntensity: 0.25,
  });

  const darkFrame = new THREE.MeshStandardMaterial({
    color: 0x1a222d,
    roughness: 0.42,
    metalness: 0.76,
  });

  const bronze = new THREE.MeshStandardMaterial({
    color: 0x8b6f4e,
    roughness: 0.35,
    metalness: 0.82,
  });

  const cyanEmissive = new THREE.MeshStandardMaterial({
    color: 0x7dd3fc,
    emissive: 0x38bdf8,
    emissiveIntensity: 1.4,
    roughness: 0.18,
    metalness: 0.2,
  });

  const amberEmissive = new THREE.MeshStandardMaterial({
    color: 0xfcd34d,
    emissive: 0xd97706,
    emissiveIntensity: 1.15,
    roughness: 0.22,
    metalness: 0.2,
  });

  const crimsonEmissive = new THREE.MeshStandardMaterial({
    color: 0xfca5a5,
    emissive: 0xef4444,
    emissiveIntensity: 1.8,
    roughness: 0.2,
    metalness: 0.1,
  });

  const contactShadow = new THREE.MeshBasicMaterial({
    map: textures.contactShadowMap,
    transparent: true,
    opacity: 0.52,
    depthWrite: false,
  });

  // World 5: Frozen Abyss materials
  const frozenStone = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.frozenStoneMap,
    bumpMap: textures.frozenStoneBump,
    bumpScale: 0.045,
    roughness: 0.66,
    metalness: 0.16,
  });

  const clearIce = new THREE.MeshStandardMaterial({
    color: 0xdcf4ff,
    map: textures.clearIceMap,
    roughness: 0.09,
    metalness: 0.22,
    transparent: true,
    opacity: 0.78,
  });

  const snow = new THREE.MeshStandardMaterial({
    color: 0xcce0ef,
    map: textures.snowMap,
    roughness: 0.9,
    metalness: 0.04,
  });

  const frostEmissive = new THREE.MeshStandardMaterial({
    color: 0xe0f2fe,
    emissive: 0x38bdf8,
    emissiveIntensity: 1.25,
    roughness: 0.15,
    metalness: 0.25,
  });

  // World 6: Inferno Core materials
  const basalt = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.basaltMap,
    bumpMap: textures.basaltBump,
    bumpScale: 0.055,
    roughness: 0.88,
    metalness: 0.12,
  });

  const industrialMetal = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.industrialMetalMap,
    bumpMap: textures.metalBump,
    bumpScale: 0.035,
    roughness: 0.36,
    metalness: 0.82,
  });

  const lava = new THREE.MeshStandardMaterial({
    color: 0xd97742,
    map: textures.lavaMap,
    emissive: 0xff5a14,
    emissiveMap: textures.lavaMap,
    emissiveIntensity: 0.92,
    roughness: 0.42,
    metalness: 0.05,
  });

  const moltenEmissive = new THREE.MeshStandardMaterial({
    color: 0xfdba74,
    emissive: 0xf97316,
    emissiveIntensity: 1.45,
    roughness: 0.2,
    metalness: 0.25,
  });

  return {
    stone,
    metal,
    trim,
    ice,
    bounce,
    accent,
    darkFrame,
    bronze,
    cyanEmissive,
    amberEmissive,
    crimsonEmissive,
    contactShadow,
    frozenStone,
    clearIce,
    snow,
    frostEmissive,
    basalt,
    industrialMetal,
    lava,
    moltenEmissive,
    dispose: () => {
      stone.dispose();
      metal.dispose();
      trim.dispose();
      ice.dispose();
      bounce.dispose();
      accent.dispose();
      darkFrame.dispose();
      bronze.dispose();
      cyanEmissive.dispose();
      amberEmissive.dispose();
      crimsonEmissive.dispose();
      contactShadow.dispose();
      frozenStone.dispose();
      clearIce.dispose();
      snow.dispose();
      frostEmissive.dispose();
      basalt.dispose();
      industrialMetal.dispose();
      lava.dispose();
      moltenEmissive.dispose();
    },
  };
}

export function getSurfaceMaterial(mats: MaterialLibrary, style: SurfaceStyle = 'stone'): THREE.MeshStandardMaterial {
  switch (style) {
    case 'metal':
      return mats.metal;
    case 'trim':
      return mats.trim;
    case 'ice':
      return mats.ice;
    case 'bounce':
      return mats.bounce;
    case 'accent':
      return mats.accent;
    case 'frozenStone':
      return mats.frozenStone;
    case 'clearIce':
      return mats.clearIce;
    case 'snow':
      return mats.snow;
    case 'basalt':
      return mats.basalt;
    case 'industrialMetal':
      return mats.industrialMetal;
    case 'lava':
      return mats.lava;
    default:
      return mats.stone;
  }
}

/**
 * Scales BoxGeometry UVs proportionally to real-world dimensions so stone/metal textures
 * never stretch awkwardly on long walls, corridors, or large floors.
 */
export function createWorldTiledBoxGeometry(
  w: number,
  h: number,
  d: number,
  tileMeters = 5.0,
): THREE.BoxGeometry {
  const geo = new THREE.BoxGeometry(w, h, d);
  const uv = geo.attributes.uv;
  // BoxGeometry face order: +X (d, h), -X (d, h), +Y (w, d), -Y (w, d), +Z (w, h), -Z (w, h)
  const faceDims: Array<[number, number]> = [
    [d, h],
    [d, h],
    [w, d],
    [w, d],
    [w, h],
    [w, h],
  ];
  for (let face = 0; face < 6; face++) {
    const [fw, fh] = faceDims[face];
    const uScale = Math.max(0.25, fw / tileMeters);
    const vScale = Math.max(0.25, fh / tileMeters);
    const base = face * 4;
    for (let i = 0; i < 4; i++) {
      uv.setXY(base + i, uv.getX(base + i) * uScale, uv.getY(base + i) * vScale);
    }
  }
  uv.needsUpdate = true;
  return geo;
}

export interface PlayerOrbRig {
  group: THREE.Group;
  coreMesh: THREE.Mesh;
  outerRingA: THREE.Mesh;
  outerRingB: THREE.Mesh;
  shellMesh: THREE.Mesh;
  light: THREE.PointLight;
  shadowDisc: THREE.Mesh;
  dispose: () => void;
}

/**
 * Composite 6-part procedural Energy Orb player model.
 */
export function createPlayerOrbRig(mats: MaterialLibrary, isSoftwareGl: boolean): PlayerOrbRig {
  const group = new THREE.Group();

  const coreGeo = new THREE.IcosahedronGeometry(0.26, 2);
  const coreMat = new THREE.MeshStandardMaterial({
    color: 0xe0f2fe,
    emissive: 0x38bdf8,
    emissiveIntensity: 1.75,
    roughness: 0.12,
    metalness: 0.1,
  });
  const coreMesh = new THREE.Mesh(coreGeo, coreMat);
  group.add(coreMesh);

  const ringAGeo = new THREE.TorusGeometry(0.39, 0.045, 12, 32);
  const outerRingA = new THREE.Mesh(ringAGeo, mats.darkFrame);
  outerRingA.castShadow = true;
  group.add(outerRingA);

  const ringBGeo = new THREE.TorusGeometry(0.34, 0.032, 10, 28);
  const outerRingB = new THREE.Mesh(ringBGeo, mats.bronze);
  outerRingB.rotation.x = Math.PI * 0.5;
  outerRingB.castShadow = true;
  group.add(outerRingB);

  const eqBandGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.05, 24, 1, true);
  const eqBand = new THREE.Mesh(eqBandGeo, mats.cyanEmissive);
  group.add(eqBand);

  const shellGeo = new THREE.SphereGeometry(0.51, 24, 20);
  const shellMat = new THREE.MeshPhysicalMaterial({
    color: 0x93c5fd,
    roughness: 0.08,
    metalness: 0.12,
    transparent: true,
    opacity: isSoftwareGl ? 0.34 : 0.28,
    clearcoat: 1.0,
    clearcoatRoughness: 0.08,
    depthWrite: false,
  });
  const shellMesh = new THREE.Mesh(shellGeo, shellMat);
  shellMesh.renderOrder = 4;
  group.add(shellMesh);

  const light = new THREE.PointLight(0x38bdf8, 3.2, 8.5, 2);
  light.position.set(0, 0.2, 0);
  group.add(light);

  const shadowGeo = new THREE.CircleGeometry(0.75, 24);
  shadowGeo.rotateX(-Math.PI * 0.5);
  const shadowDisc = new THREE.Mesh(shadowGeo, mats.contactShadow);
  shadowDisc.renderOrder = 1;

  return {
    group,
    coreMesh,
    outerRingA,
    outerRingB,
    shellMesh,
    light,
    shadowDisc,
    dispose: () => {
      coreGeo.dispose();
      coreMat.dispose();
      ringAGeo.dispose();
      ringBGeo.dispose();
      eqBandGeo.dispose();
      shellGeo.dispose();
      shellMat.dispose();
      shadowGeo.dispose();
    },
  };
}

export interface PortalRig {
  group: THREE.Group;
  ringOuter: THREE.Mesh;
  ringInner: THREE.Mesh;
  irisMesh: THREE.Mesh;
  irisMat: THREE.MeshStandardMaterial;
  light: THREE.PointLight;
  dispose: () => void;
}

/**
 * Composite 8-part architectural Exit Portal monument (grounded bottom-center).
 */
export function createPortalRig(mats: MaterialLibrary): PortalRig {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];

  // Stepped dark stone plinth
  const baseGeo = new THREE.CylinderGeometry(2.1, 2.35, 0.28, 8);
  geos.push(baseGeo);
  const baseMesh = new THREE.Mesh(baseGeo, mats.stone);
  baseMesh.position.y = 0.14;
  baseMesh.receiveShadow = true;
  baseMesh.castShadow = true;
  group.add(baseMesh);

  // Twin beveled monolith pylons flanking the portal aperture
  const pylonGeo = new THREE.BoxGeometry(0.56, 3.5, 0.72);
  geos.push(pylonGeo);
  const pylonL = new THREE.Mesh(pylonGeo, mats.darkFrame);
  pylonL.position.set(-1.68, 1.9, 0);
  pylonL.castShadow = true;
  pylonL.receiveShadow = true;
  group.add(pylonL);

  const pylonR = new THREE.Mesh(pylonGeo, mats.darkFrame);
  pylonR.position.set(1.68, 1.9, 0);
  pylonR.castShadow = true;
  pylonR.receiveShadow = true;
  group.add(pylonR);

  // Crown beam bridging pylons
  const crownGeo = new THREE.BoxGeometry(4.2, 0.42, 0.85);
  geos.push(crownGeo);
  const crown = new THREE.Mesh(crownGeo, mats.bronze);
  crown.position.set(0, 3.75, 0);
  crown.castShadow = true;
  group.add(crown);

  // Static bronze aperture torus
  const frameGeo = new THREE.TorusGeometry(1.38, 0.12, 12, 36);
  geos.push(frameGeo);
  const frameRing = new THREE.Mesh(frameGeo, mats.bronze);
  frameRing.position.set(0, 1.95, 0);
  frameRing.castShadow = true;
  group.add(frameRing);

  // Rotating outer segmented cyan ring
  const ringOuterGeo = new THREE.TorusGeometry(1.16, 0.065, 10, 32);
  geos.push(ringOuterGeo);
  const ringOuter = new THREE.Mesh(ringOuterGeo, mats.cyanEmissive);
  ringOuter.position.set(0, 1.95, 0);
  group.add(ringOuter);

  // Counter-rotating inner ring
  const ringInnerGeo = new THREE.TorusGeometry(0.84, 0.045, 10, 24);
  geos.push(ringInnerGeo);
  const ringInner = new THREE.Mesh(ringInnerGeo, mats.cyanEmissive);
  ringInner.position.set(0, 1.95, 0);
  group.add(ringInner);

  // Translucent energy iris membrane
  const irisGeo = new THREE.CircleGeometry(1.1, 28);
  geos.push(irisGeo);
  const irisMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x0284c7,
    emissiveIntensity: 1.2,
    transparent: true,
    opacity: 0.42,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const irisMesh = new THREE.Mesh(irisGeo, irisMat);
  irisMesh.position.set(0, 1.95, 0);
  irisMesh.renderOrder = 3;
  group.add(irisMesh);

  const light = new THREE.PointLight(0x38bdf8, 5.5, 14, 2);
  light.position.set(0, 2.0, 0.6);
  group.add(light);

  return {
    group,
    ringOuter,
    ringInner,
    irisMesh,
    irisMat,
    light,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      irisMat.dispose();
    },
  };
}

export interface DynamicPropRig {
  group: THREE.Group;
  accentMat: THREE.MeshStandardMaterial;
  dispose: () => void;
}

/**
 * Composite multi-part dynamic physics block/sphere/slab model.
 */
export function createDynamicPropRig(
  shape: DynamicShape,
  size: [number, number, number],
  mats: MaterialLibrary,
  options?: { lowFriction?: boolean; heatConductive?: boolean },
): DynamicPropRig {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];
  const isThermal = Boolean(options?.heatConductive);
  const isFrost = Boolean(options?.lowFriction);

  const accentMat = new THREE.MeshStandardMaterial({
    color: isThermal ? 0xfdba74 : isFrost ? 0xbae6fd : 0x38bdf8,
    emissive: isThermal ? 0xea580c : isFrost ? 0x38bdf8 : 0x0284c7,
    emissiveIntensity: isThermal ? 1.15 : 0.55,
    roughness: 0.22,
    metalness: 0.35,
  });

  if (shape === 'sphere') {
    const r = size[0] * 0.5;
    const coreGeo = new THREE.SphereGeometry(r * 0.96, 22, 18);
    geos.push(coreGeo);
    const core = new THREE.Mesh(coreGeo, isThermal ? mats.industrialMetal : isFrost ? mats.clearIce : mats.metal);
    core.castShadow = true;
    core.receiveShadow = true;
    group.add(core);

    const band1Geo = new THREE.TorusGeometry(r * 0.97, r * 0.075, 8, 28);
    geos.push(band1Geo);
    const band1 = new THREE.Mesh(band1Geo, mats.bronze);
    group.add(band1);

    const band2 = new THREE.Mesh(band1Geo, accentMat);
    band2.rotation.y = Math.PI * 0.5;
    group.add(band2);
  } else {
    const [w, h, d] = size;
    const bodyGeo = new THREE.BoxGeometry(w * 0.92, h * 0.92, d * 0.92);
    geos.push(bodyGeo);
    const bodyMat = isThermal
      ? mats.industrialMetal
      : isFrost
        ? mats.frozenStone
        : shape === 'heavyCube'
          ? mats.darkFrame
          : mats.metal;
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    // Outer metallic structural collar beams
    const railHGeo = new THREE.BoxGeometry(w, h * 0.16, d * 1.01);
    geos.push(railHGeo);
    const collarMat = isThermal
      ? mats.bronze
      : isFrost
        ? mats.clearIce
        : shape === 'heavyCube'
          ? mats.bronze
          : mats.trim;
    const topCollar = new THREE.Mesh(railHGeo, collarMat);
    topCollar.position.y = h * 0.42;
    topCollar.castShadow = true;
    group.add(topCollar);

    const botCollar = new THREE.Mesh(railHGeo, collarMat);
    botCollar.position.y = -h * 0.42;
    botCollar.castShadow = true;
    group.add(botCollar);

    // Glowing kinetic inset core strips on opposite sides
    const stripGeo = new THREE.BoxGeometry(w * 0.56, h * 0.14, d * 0.97);
    geos.push(stripGeo);
    const strip = new THREE.Mesh(stripGeo, accentMat);
    group.add(strip);

    const stripCrossGeo = new THREE.BoxGeometry(w * 0.97, h * 0.14, d * 0.56);
    geos.push(stripCrossGeo);
    const stripCross = new THREE.Mesh(stripCrossGeo, accentMat);
    group.add(stripCross);
  }

  return {
    group,
    accentMat,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      accentMat.dispose();
    },
  };
}

export interface SwitchRig {
  group: THREE.Group;
  leverPivot: THREE.Group;
  crystalMat: THREE.MeshStandardMaterial;
  dispose: () => void;
}

export function createSwitchRig(
  kind: SwitchKind,
  mats: MaterialLibrary,
  frozen = false,
): SwitchRig {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];

  const plinthGeo = new THREE.CylinderGeometry(0.55, 0.72, 0.24, 6);
  geos.push(plinthGeo);
  const plinthMat = frozen ? mats.frozenStone : kind === 'thermal' ? mats.basalt : mats.stone;
  const plinth = new THREE.Mesh(plinthGeo, plinthMat);
  plinth.position.y = 0.12;
  plinth.castShadow = true;
  plinth.receiveShadow = true;
  group.add(plinth);

  const colGeo = new THREE.BoxGeometry(0.42, 0.95, 0.42);
  geos.push(colGeo);
  const col = new THREE.Mesh(colGeo, kind === 'thermal' ? mats.industrialMetal : mats.darkFrame);
  col.position.y = 0.7;
  col.castShadow = true;
  group.add(col);

  const capGeo = new THREE.BoxGeometry(0.54, 0.12, 0.54);
  geos.push(capGeo);
  const cap = new THREE.Mesh(capGeo, frozen ? mats.clearIce : mats.bronze);
  cap.position.y = 1.22;
  group.add(cap);

  const leverPivot = new THREE.Group();
  leverPivot.position.set(0, 1.28, 0);
  group.add(leverPivot);

  const armGeo = new THREE.CylinderGeometry(0.055, 0.065, 0.62, 10);
  geos.push(armGeo);
  const arm = new THREE.Mesh(armGeo, mats.metal);
  arm.position.y = 0.31;
  leverPivot.add(arm);

  const crystalGeo = kind === 'gravity' || frozen
    ? new THREE.OctahedronGeometry(0.18, 0)
    : kind === 'thermal'
      ? new THREE.DodecahedronGeometry(0.17, 0)
      : new THREE.BoxGeometry(0.24, 0.24, 0.24);
  geos.push(crystalGeo);

  const crystalMat = new THREE.MeshStandardMaterial({
    color: kind === 'thermal' ? 0xfb923c : frozen ? 0xbae6fd : 0xfcd34d,
    emissive: kind === 'thermal' ? 0xc2410c : frozen ? 0x0284c7 : 0xd97706,
    emissiveIntensity: 1.2,
    roughness: 0.2,
    metalness: 0.2,
  });
  const crystal = new THREE.Mesh(crystalGeo, crystalMat);
  crystal.position.y = 0.68;
  leverPivot.add(crystal);

  return {
    group,
    leverPivot,
    crystalMat,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      crystalMat.dispose();
    },
  };
}

export interface PlateRig {
  group: THREE.Group;
  padMesh: THREE.Mesh;
  rimMat: THREE.MeshStandardMaterial;
  dispose: () => void;
}

export function createPressurePlateRig(
  width: number,
  depth: number,
  mats: MaterialLibrary,
  thermalOnly = false,
): PlateRig {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];

  // Recessed outer steel frame sitting flush above floor (offset 0.025 to prevent Z-fighting)
  const frameGeo = new THREE.BoxGeometry(width + 0.34, 0.1, depth + 0.34);
  geos.push(frameGeo);
  const frame = new THREE.Mesh(frameGeo, thermalOnly ? mats.basalt : mats.darkFrame);
  frame.position.y = 0.05;
  frame.receiveShadow = true;
  group.add(frame);

  // Indicator light rim
  const rimGeo = new THREE.BoxGeometry(width + 0.16, 0.12, depth + 0.16);
  geos.push(rimGeo);
  const rimMat = new THREE.MeshStandardMaterial({
    color: thermalOnly ? 0xf97316 : 0xf59e0b,
    emissive: thermalOnly ? 0x9a3412 : 0xb45309,
    emissiveIntensity: 0.9,
    roughness: 0.3,
    metalness: 0.4,
  });
  const rim = new THREE.Mesh(rimGeo, rimMat);
  rim.position.y = 0.065;
  group.add(rim);

  // Moving beveled top pad
  const padGeo = new THREE.BoxGeometry(width * 0.9, 0.16, depth * 0.9);
  geos.push(padGeo);
  const padMesh = new THREE.Mesh(padGeo, thermalOnly ? mats.industrialMetal : mats.metal);
  padMesh.position.y = 0.14;
  padMesh.receiveShadow = true;
  padMesh.castShadow = true;
  group.add(padMesh);

  return {
    group,
    padMesh,
    rimMat,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      rimMat.dispose();
    },
  };
}

export interface DoorRig {
  group: THREE.Group;
  stripMat: THREE.MeshStandardMaterial;
  dispose: () => void;
}

export function createDoorRig(size: [number, number, number], mats: MaterialLibrary): DoorRig {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];
  const [w, h, d] = size;

  const panelGeo = new THREE.BoxGeometry(w, h, d);
  geos.push(panelGeo);
  const panel = new THREE.Mesh(panelGeo, mats.darkFrame);
  panel.castShadow = true;
  panel.receiveShadow = true;
  group.add(panel);

  // Horizontal bronze reinforcing ribs
  const ribGeo = new THREE.BoxGeometry(w * 0.96, 0.16, d + 0.08);
  geos.push(ribGeo);
  for (const frac of [-0.32, 0, 0.32]) {
    const rib = new THREE.Mesh(ribGeo, mats.bronze);
    rib.position.y = h * frac;
    group.add(rib);
  }

  // Central energy lock indicator bar
  const stripGeo = new THREE.BoxGeometry(0.18, h * 0.78, d + 0.12);
  geos.push(stripGeo);
  const stripMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xd97706,
    emissiveIntensity: 1.2,
    roughness: 0.25,
    metalness: 0.2,
  });
  const strip = new THREE.Mesh(stripGeo, stripMat);
  group.add(strip);

  return {
    group,
    stripMat,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      stripMat.dispose();
    },
  };
}

export interface LaserRig {
  group: THREE.Group;
  beamMesh: THREE.Mesh;
  coreMesh: THREE.Mesh;
  dispose: () => void;
}

export function createLaserRig(
  start: [number, number, number],
  end: [number, number, number],
  mats: MaterialLibrary,
): LaserRig {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];

  const emitterGeo = new THREE.CylinderGeometry(0.24, 0.3, 0.45, 10);
  geos.push(emitterGeo);

  const pStart = new THREE.Vector3(...start);
  const pEnd = new THREE.Vector3(...end);
  const dir = new THREE.Vector3().subVectors(pEnd, pStart).normalize();
  const qAlign = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);

  const emitter = new THREE.Mesh(emitterGeo, mats.darkFrame);
  emitter.position.copy(pStart);
  emitter.quaternion.copy(qAlign);
  group.add(emitter);

  const receiver = new THREE.Mesh(emitterGeo, mats.darkFrame);
  receiver.position.copy(pEnd);
  receiver.quaternion.copy(qAlign);
  group.add(receiver);

  const coreGeo = new THREE.CylinderGeometry(0.055, 0.055, 1, 8);
  coreGeo.translate(0, 0.5, 0);
  geos.push(coreGeo);
  const coreMesh = new THREE.Mesh(coreGeo, mats.crimsonEmissive);
  coreMesh.position.copy(pStart);
  coreMesh.quaternion.copy(qAlign);
  group.add(coreMesh);

  const beamGeo = new THREE.CylinderGeometry(0.14, 0.14, 1, 10);
  beamGeo.translate(0, 0.5, 0);
  geos.push(beamGeo);
  const beamMat = new THREE.MeshBasicMaterial({
    color: 0xef4444,
    transparent: true,
    opacity: 0.28,
    depthWrite: false,
  });
  const beamMesh = new THREE.Mesh(beamGeo, beamMat);
  beamMesh.position.copy(pStart);
  beamMesh.quaternion.copy(qAlign);
  group.add(beamMesh);

  return {
    group,
    beamMesh,
    coreMesh,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      beamMat.dispose();
    },
  };
}

export interface CheckpointRig {
  group: THREE.Group;
  ringMat: THREE.MeshStandardMaterial;
  haloMesh: THREE.Mesh;
  dispose: () => void;
}

export function createCheckpointRig(mats: MaterialLibrary): CheckpointRig {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];

  const padGeo = new THREE.CylinderGeometry(1.05, 1.18, 0.1, 8);
  geos.push(padGeo);
  const pad = new THREE.Mesh(padGeo, mats.darkFrame);
  pad.position.y = 0.05;
  pad.receiveShadow = true;
  group.add(pad);

  const ringGeo = new THREE.TorusGeometry(0.88, 0.06, 8, 24);
  ringGeo.rotateX(Math.PI * 0.5);
  geos.push(ringGeo);
  const ringMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    emissive: 0x1e293b,
    emissiveIntensity: 0.6,
    roughness: 0.3,
    metalness: 0.6,
  });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.position.y = 0.12;
  group.add(ring);

  const haloGeo = new THREE.CylinderGeometry(0.86, 0.86, 0.7, 16, 1, true);
  geos.push(haloGeo);
  const haloMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.14,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const haloMesh = new THREE.Mesh(haloGeo, haloMat);
  haloMesh.position.y = 0.45;
  haloMesh.visible = false;
  group.add(haloMesh);

  return {
    group,
    ringMat,
    haloMesh,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      ringMat.dispose();
      haloMat.dispose();
    },
  };
}

/**
 * Distant architectural monoliths surrounding the arena so every level sits in a deep monumental horizon.
 */
export function createMonumentBackdrop(mats: MaterialLibrary): {
  mesh: THREE.InstancedMesh;
  dispose: () => void;
} {
  const count = 28;
  const geo = new THREE.BoxGeometry(1, 1, 1);
  const mesh = new THREE.InstancedMesh(geo, mats.stone, count);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();

  for (let i = 0; i < count; i++) {
    const angle = (i / count) * Math.PI * 2 + (i % 3) * 0.08;
    const radius = 58 + (i % 4) * 14;
    const height = 28 + (i % 5) * 14;
    const width = 4.5 + (i % 3) * 2.5;
    const depth = 4.5 + ((i + 1) % 3) * 2.2;

    dummy.position.set(
      Math.cos(angle) * radius,
      height * 0.25 - 18,
      Math.sin(angle) * radius - 10,
    );
    dummy.rotation.set(0, angle + 0.3, 0);
    dummy.scale.set(width, height, depth);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);

    const shade = 0.65 + (i % 4) * 0.08;
    color.setRGB(shade, shade * 1.04, shade * 1.12);
    mesh.setColorAt(i, color);
  }
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.computeBoundingSphere();
  mesh.frustumCulled = false;

  return {
    mesh,
    dispose: () => {
      geo.dispose();
    },
  };
}

/**
 * World 5 (Frozen Abyss) horizon: faceted glacial mountain range + crystalline ice spires (2 draw calls).
 */
export function createFrozenBackdrop(mats: MaterialLibrary): {
  group: THREE.Group;
  dispose: () => void;
} {
  const group = new THREE.Group();
  const peakCount = 26;
  const peakGeo = new THREE.ConeGeometry(1, 1, 5);
  const peakMat = new THREE.MeshStandardMaterial({
    color: 0x243b55,
    roughness: 0.9,
    metalness: 0.08,
    flatShading: true,
  });
  const peaks = new THREE.InstancedMesh(peakGeo, peakMat, peakCount);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();

  for (let i = 0; i < peakCount; i++) {
    const angle = (i / peakCount) * Math.PI * 2 + (i % 3) * 0.07;
    const radius = 64 + (i % 4) * 16;
    const height = 34 + (i % 5) * 14;
    const width = 14 + (i % 3) * 7;

    dummy.position.set(
      Math.cos(angle) * radius,
      height * 0.32 - 22,
      Math.sin(angle) * radius - 14,
    );
    dummy.rotation.set(0, angle + i * 0.4, 0);
    dummy.scale.set(width, height, width * 0.85);
    dummy.updateMatrix();
    peaks.setMatrixAt(i, dummy.matrix);

    const shade = 0.72 + (i % 4) * 0.09;
    color.setRGB(shade * 0.86, shade * 0.98, shade * 1.12);
    peaks.setColorAt(i, color);
  }
  peaks.instanceMatrix.needsUpdate = true;
  if (peaks.instanceColor) peaks.instanceColor.needsUpdate = true;
  peaks.computeBoundingSphere();
  peaks.frustumCulled = false;
  group.add(peaks);

  // Translucent glacier crystal spires
  const spireCount = 16;
  const spireGeo = new THREE.OctahedronGeometry(1, 0);
  const spireMat = new THREE.MeshStandardMaterial({
    color: 0x9bd3f0,
    roughness: 0.22,
    metalness: 0.18,
    flatShading: true,
  });
  const spires = new THREE.InstancedMesh(spireGeo, spireMat, spireCount);
  for (let i = 0; i < spireCount; i++) {
    const angle = (i / spireCount) * Math.PI * 2 + 0.22;
    const radius = 56 + (i % 3) * 15;
    const height = 18 + (i % 4) * 9;
    const width = 4.2 + (i % 3) * 2.2;

    dummy.position.set(
      Math.cos(angle) * radius,
      height * 0.35 - 12,
      Math.sin(angle) * radius - 14,
    );
    dummy.rotation.set(0.08 * (i % 2 ? 1 : -1), angle, 0.06);
    dummy.scale.set(width, height, width);
    dummy.updateMatrix();
    spires.setMatrixAt(i, dummy.matrix);
  }
  spires.instanceMatrix.needsUpdate = true;
  spires.computeBoundingSphere();
  spires.frustumCulled = false;
  group.add(spires);
  void mats;

  return {
    group,
    dispose: () => {
      peakGeo.dispose();
      peakMat.dispose();
      spireGeo.dispose();
      spireMat.dispose();
    },
  };
}

/**
 * World 6 (Inferno Core) horizon: volcanic basalt caldera peaks + subterranean magma sea (2 draw calls).
 */
export function createInfernoBackdrop(mats: MaterialLibrary): {
  group: THREE.Group;
  dispose: () => void;
} {
  const group = new THREE.Group();
  const peakCount = 26;
  const peakGeo = new THREE.ConeGeometry(1, 1, 6);
  const peakMat = new THREE.MeshStandardMaterial({
    color: 0x261512,
    roughness: 0.94,
    metalness: 0.06,
    flatShading: true,
  });
  const peaks = new THREE.InstancedMesh(peakGeo, peakMat, peakCount);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();

  for (let i = 0; i < peakCount; i++) {
    const angle = (i / peakCount) * Math.PI * 2 + (i % 3) * 0.09;
    const radius = 62 + (i % 4) * 15;
    const height = 30 + (i % 5) * 13;
    const width = 13 + (i % 3) * 6;

    dummy.position.set(
      Math.cos(angle) * radius,
      height * 0.3 - 22,
      Math.sin(angle) * radius - 14,
    );
    dummy.rotation.set(0, angle * 1.3, 0);
    dummy.scale.set(width, height, width * 0.9);
    dummy.updateMatrix();
    peaks.setMatrixAt(i, dummy.matrix);

    const shade = 0.65 + (i % 4) * 0.1;
    color.setRGB(shade * 1.15, shade * 0.85, shade * 0.78);
    peaks.setColorAt(i, color);
  }
  peaks.instanceMatrix.needsUpdate = true;
  if (peaks.instanceColor) peaks.instanceColor.needsUpdate = true;
  peaks.computeBoundingSphere();
  peaks.frustumCulled = false;
  group.add(peaks);

  // Deep volcanic caldera magma floor far below (depth & subtle under-glow without visual noise)
  const seaGeo = new THREE.CircleGeometry(125, 32);
  seaGeo.rotateX(-Math.PI * 0.5);
  const seaMat = new THREE.MeshBasicMaterial({
    map: mats.lava.map,
    color: 0x993212,
    transparent: true,
    opacity: 0.72,
  });
  const seaMesh = new THREE.Mesh(seaGeo, seaMat);
  seaMesh.position.set(0, -19.5, -14);
  group.add(seaMesh);

  return {
    group,
    dispose: () => {
      peakGeo.dispose();
      peakMat.dispose();
      seaGeo.dispose();
      seaMat.dispose();
    },
  };
}

