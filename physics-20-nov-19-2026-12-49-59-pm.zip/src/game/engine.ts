import RAPIER from '@dimforge/rapier3d-compat';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { AudioEngine } from './audio';
import { getLevelById } from './levels';
import {
  createCheckpointRig,
  createDoorRig,
  createDynamicPropRig,
  createFrozenBackdrop,
  createInfernoBackdrop,
  createLaserRig,
  createMaterialLibrary,
  createMonumentBackdrop,
  createPlayerOrbRig,
  createPortalRig,
  createPressurePlateRig,
  createSwitchRig,
  createWorldTiledBoxGeometry,
  getSurfaceMaterial,
  type CheckpointRig,
  type DoorRig,
  type DynamicPropRig,
  type LaserRig,
  type MaterialLibrary,
  type PlateRig,
  type PlayerOrbRig,
  type PortalRig,
  type SwitchRig,
} from './models';
import {
  describeGravityLabel,
  evaluateLaserBeam,
  evaluateLavaHazardOverlap,
  evaluateSignalCondition,
  resolveGravityAtPoint,
  stepBreakableIceState,
  TIER_META,
  type BreakableIceState,
  type LaserBlockerBox,
} from './rules';
import { createProceduralTextures, type ProceduralTextureSet } from './textures';
import type {
  DynamicBodyDef,
  EnvironmentTheme,
  GameScreenState,
  HudSnapshot,
  LavaHazardDef,
  LevelBlueprint,
  MovingObstacleDef,
  MovingPlatformDef,
  RotatingBridgeDef,
  SettingsState,
  SwitchDef,
  Vec3,
} from './types';

const PLAYER_RADIUS = 0.52;
const DEFAULT_GRAVITY: Vec3 = [0, -22, 0];
const FIXED_DT = 1 / 60;

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const rendererStr = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(rendererStr);
  } catch {
    return true;
  }
}

interface DynamicEntity {
  def: DynamicBodyDef;
  body: RAPIER.RigidBody;
  collider: RAPIER.Collider;
  rig: DynamicPropRig;
  targetYaw: number;
}

interface SwitchEntity {
  def: SwitchDef;
  rig: SwitchRig;
  active: boolean;
  timerRemaining: number;
  leverAngle: number;
}

interface PlateEntity {
  id: string;
  position: Vec3;
  width: number;
  depth: number;
  minWeight: number;
  requiresBlock: boolean;
  thermalOnly: boolean;
  rig: PlateRig;
  pressed: boolean;
  depressOffset: number;
}

interface DoorEntity {
  id: string;
  closedPos: THREE.Vector3;
  openPos: THREE.Vector3;
  requiredSignals: string[];
  logic: 'AND' | 'OR';
  rotationY: number;
  body: RAPIER.RigidBody;
  rig: DoorRig;
  openProgress: number;
  wasOpen: boolean;
}

interface MovingPlatformEntity {
  def: MovingPlatformDef;
  body: RAPIER.RigidBody;
  collider: RAPIER.Collider;
  mesh: THREE.Mesh;
  startVec: THREE.Vector3;
  endVec: THREE.Vector3;
  prevPos: THREE.Vector3;
  currPos: THREE.Vector3;
  velocity: THREE.Vector3;
  progress: number;
  direction: 1 | -1;
  dwellTimer: number;
}

interface RotatingBridgeEntity {
  def: RotatingBridgeDef;
  body: RAPIER.RigidBody;
  collider: RAPIER.Collider;
  mesh: THREE.Mesh;
  currentAngle: number;
  angularVel: number;
}

interface GravityZoneEntity {
  id: string;
  position: Vec3;
  size: Vec3;
  gravity: Vec3;
  requiredSignals?: string[];
  logic?: 'AND' | 'OR';
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
}

interface LaserEntity {
  id: string;
  start: Vec3;
  end: Vec3;
  fullLength: number;
  disableSignals?: string[];
  logic?: 'AND' | 'OR';
  cyclePeriod?: number;
  activeDuty?: number;
  phaseOffset?: number;
  rig: LaserRig;
}

interface BreakablePlatformEntity {
  id: string;
  collider: RAPIER.Collider;
  mesh: THREE.Mesh;
  mat: THREE.MeshStandardMaterial;
  basePos: THREE.Vector3;
  size: Vec3;
  collapseDelay: number;
  respawnDelay: number;
  state: BreakableIceState;
  dropVelocity: number;
}

interface LavaHazardEntity {
  def: LavaHazardDef;
  mesh: THREE.Mesh;
  shimmerMesh: THREE.Mesh | null;
}

interface MovingObstacleEntity {
  def: MovingObstacleDef;
  body: RAPIER.RigidBody;
  collider: RAPIER.Collider;
  mesh: THREE.Mesh;
  startVec: THREE.Vector3;
  endVec: THREE.Vector3;
  currPos: THREE.Vector3;
  progress: number;
  direction: 1 | -1;
  dwellTimer: number;
  active: boolean;
}

interface CheckpointEntity {
  id: string;
  position: Vec3;
  rig: CheckpointRig;
  activated: boolean;
}

interface BouncePadInfo {
  colliderHandle: number;
  bounceVelocity: number;
  position: Vec3;
  halfSize: Vec3;
}

export interface EngineCallbacks {
  onHudUpdate: (snapshot: HudSnapshot) => void;
  onLevelComplete: (levelId: number, elapsedTime: number) => void;
  onRequestPauseToggle: () => void;
  onRequestRestart: () => void;
  onRequestMuteToggle: () => void;
  onError: (message: string) => void;
}

// Pre-allocated scratch math objects (Zero-GC render loop)
const _vA = new THREE.Vector3();
const _vB = new THREE.Vector3();
const _vC = new THREE.Vector3();
const _vForward = new THREE.Vector3();
const _vRight = new THREE.Vector3();
const _vCamDesired = new THREE.Vector3();
const _vCamTarget = new THREE.Vector3();
const _qA = new THREE.Quaternion();
const _eulerA = new THREE.Euler();
const _upY = new THREE.Vector3(0, 1, 0);

export class Physics20Engine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  public readonly audio: AudioEngine;
  public readonly isSoftwareGl: boolean;

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private hemiLight!: THREE.HemisphereLight;
  private dirLight!: THREE.DirectionalLight;
  private rimLight!: THREE.DirectionalLight;
  private textures!: ProceduralTextureSet;
  private mats!: MaterialLibrary;
  private citadelBackdrop!: THREE.Object3D;
  private frozenBackdrop!: THREE.Object3D;
  private infernoBackdrop!: THREE.Object3D;
  private backdropDisposables: Array<() => void> = [];
  private activeTheme: EnvironmentTheme = 'citadel';
  private envTexture: THREE.Texture | null = null;

  private levelRoot = new THREE.Group();
  private levelDisposables: Array<() => void> = [];

  private world: RAPIER.World | null = null;
  private playerBody: RAPIER.RigidBody | null = null;
  private playerCollider: RAPIER.Collider | null = null;
  private playerRig: PlayerOrbRig | null = null;
  private portalRig: PortalRig | null = null;
  private tetherMesh: THREE.Mesh | null = null;

  private currentLevel: LevelBlueprint = getLevelById(1);
  private screenState: GameScreenState = 'loading';
  private settings: SettingsState;

  // Level entities
  private dynamicEntities: DynamicEntity[] = [];
  private switchEntities: SwitchEntity[] = [];
  private plateEntities: PlateEntity[] = [];
  private doorEntities: DoorEntity[] = [];
  private movingPlatforms: MovingPlatformEntity[] = [];
  private rotatingBridges: RotatingBridgeEntity[] = [];
  private gravityZones: GravityZoneEntity[] = [];
  private laserEntities: LaserEntity[] = [];
  private breakablePlatforms: BreakablePlatformEntity[] = [];
  private lavaHazards: LavaHazardEntity[] = [];
  private movingObstacles: MovingObstacleEntity[] = [];
  private checkpointEntities: CheckpointEntity[] = [];
  private bouncePads: BouncePadInfo[] = [];
  private staticColliderHandles = new Set<number>();
  private slipperyColliderHandles = new Set<number>();

  // Gameplay state
  private signalMap: Record<string, boolean> = {};
  private elapsedTime = 0;
  private respawnPos: Vec3 = [0, 1, 8];
  private movesRemaining: number | null = null;
  private grabbedEntity: DynamicEntity | null = null;
  private portalUnlocked = true;
  private checkpointBanner: string | null = null;
  private checkpointBannerTimer = 0;
  private levelCompletedFlag = false;
  private hitstopTimer = 0;
  private cameraTrauma = 0;
  private orbSquash = 1.0;

  // Movement & jump mechanics
  private grounded = false;
  private onIce = false;
  private coyoteTimer = 0;
  private jumpBufferTimer = 0;
  private jumpHeld = false;
  private lastVerticalVel = 0;
  private standingPlatform: MovingPlatformEntity | null = null;
  private standingBridge: RotatingBridgeEntity | null = null;

  // Input state
  private keys = new Set<string>();
  private joystickX = 0;
  private joystickY = 0;
  private pointerDragging = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  // Camera state
  private camYaw = 0;
  private camPitch = 0.44;
  private camDistance = 9.4;
  private camCurrentPos = new THREE.Vector3(0, 6, 16);
  private camCurrentLook = new THREE.Vector3(0, 1, 0);
  private titleOrbitAngle = 0.4;

  // Loop & performance tracking
  private disposed = false;
  private ready = false;
  private frameId = 0;
  private lastFrameMs = 0;
  private physicsAccumulator = 0;
  private lastHudPushMs = 0;
  private fpsFrames = 0;
  private fpsWindowStart = 0;
  private currentFps = 60;
  private resizeObserver: ResizeObserver | null = null;

  constructor(container: HTMLElement, settings: SettingsState, callbacks: EngineCallbacks) {
    this.container = container;
    this.settings = settings;
    this.callbacks = callbacks;
    this.audio = new AudioEngine();
    this.audio.applySettings(settings);
    this.isSoftwareGl = detectSoftwareWebGL();
  }

  public async init(initialLevelId: number): Promise<void> {
    try {
      await RAPIER.init();
      if (this.disposed) return;

      this.initThree();
      this.bindEvents();
      this.loadLevel(initialLevelId);

      this.ready = true;
      this.lastFrameMs = performance.now();
      this.fpsWindowStart = this.lastFrameMs;
      this.tick();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to initialize 3D physics engine';
      this.callbacks.onError(msg);
    }
  }

  private initThree(): void {
    const width = Math.max(1, this.container.clientWidth || window.innerWidth);
    const height = Math.max(1, this.container.clientHeight || window.innerHeight);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.applyGraphicsQuality();
    this.renderer.setSize(width, height);
    this.renderer.domElement.className = 'block w-full h-full outline-none';
    this.renderer.domElement.setAttribute('data-testid', 'physics20-canvas');
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0d131c);
    this.scene.fog = new THREE.FogExp2(0x0d131c, 0.0135);

    this.camera = new THREE.PerspectiveCamera(54, width / height, 0.15, 220);

    // Studio Environment Reflections (RoomEnvironment) on all devices
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envTarget = pmrem.fromScene(new RoomEnvironment(), 0.04);
    this.envTexture = envTarget.texture;
    this.scene.environment = this.envTexture;
    pmrem.dispose();

    // Balanced 3-point warm/cool lighting rig (1 shadow caster)
    this.hemiLight = new THREE.HemisphereLight(0x8cb4dc, 0x161d28, 0.92);
    this.hemiLight.position.set(0, 40, 0);
    this.scene.add(this.hemiLight);

    this.dirLight = new THREE.DirectionalLight(0xffeed8, 2.05);
    this.dirLight.position.set(16, 28, 18);
    this.dirLight.castShadow = !this.isSoftwareGl;
    this.dirLight.shadow.mapSize.set(1024, 1024);
    const d = 24;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.dirLight.shadow.camera.near = 2;
    this.dirLight.shadow.camera.far = 80;
    this.dirLight.shadow.bias = -0.0005;
    this.dirLight.shadow.normalBias = 0.025;
    this.scene.add(this.dirLight);
    this.scene.add(this.dirLight.target);

    this.rimLight = new THREE.DirectionalLight(0x38bdf8, 0.55);
    this.rimLight.position.set(-18, 14, -22);
    this.scene.add(this.rimLight);

    this.textures = createProceduralTextures(this.renderer);
    this.mats = createMaterialLibrary(this.textures, this.isSoftwareGl);

    // Three world backdrops (zero allocation during level switching; Levels 1–20 use original citadelBackdrop unchanged)
    const citadelBg = createMonumentBackdrop(this.mats);
    this.citadelBackdrop = citadelBg.mesh;
    this.scene.add(this.citadelBackdrop);
    this.backdropDisposables.push(citadelBg.dispose);

    const frozenBg = createFrozenBackdrop(this.mats);
    this.frozenBackdrop = frozenBg.group;
    this.frozenBackdrop.visible = false;
    this.scene.add(this.frozenBackdrop);
    this.backdropDisposables.push(frozenBg.dispose);

    const infernoBg = createInfernoBackdrop(this.mats);
    this.infernoBackdrop = infernoBg.group;
    this.infernoBackdrop.visible = false;
    this.scene.add(this.infernoBackdrop);
    this.backdropDisposables.push(infernoBg.dispose);

    this.scene.add(this.levelRoot);

    // Kinetic tether cylinder (hidden unless grabbing a block)
    const tetherGeo = new THREE.CylinderGeometry(0.055, 0.055, 1, 8);
    tetherGeo.translate(0, 0.5, 0);
    const tetherMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
    });
    this.tetherMesh = new THREE.Mesh(tetherGeo, tetherMat);
    this.tetherMesh.visible = false;
    this.scene.add(this.tetherMesh);
  }

  private applyEnvironmentTheme(theme: EnvironmentTheme): void {
    this.activeTheme = theme;
    this.citadelBackdrop.visible = theme === 'citadel';
    this.frozenBackdrop.visible = theme === 'frozen';
    this.infernoBackdrop.visible = theme === 'inferno';

    if (theme === 'frozen') {
      this.scene.background = new THREE.Color(0x0b1726);
      this.scene.fog = new THREE.FogExp2(0x0c1b2e, 0.0115);
      this.hemiLight.color.setHex(0xa5d4ff);
      this.hemiLight.groundColor.setHex(0x102033);
      this.hemiLight.intensity = 1.05;
      this.dirLight.color.setHex(0xdbeafe);
      this.dirLight.intensity = 2.1;
      this.rimLight.color.setHex(0x38bdf8);
      this.rimLight.intensity = 0.78;
    } else if (theme === 'inferno') {
      this.scene.background = new THREE.Color(0x160a08);
      this.scene.fog = new THREE.FogExp2(0x1b0c09, 0.0118);
      this.hemiLight.color.setHex(0xfb923c);
      this.hemiLight.groundColor.setHex(0x240c08);
      this.hemiLight.intensity = 0.86;
      this.dirLight.color.setHex(0xffd2a6);
      this.dirLight.intensity = 2.0;
      this.rimLight.color.setHex(0xf97316);
      this.rimLight.intensity = 0.72;
    } else {
      // Exact original Citadel lighting & fog for Levels 1–20
      this.scene.background = new THREE.Color(0x0d131c);
      this.scene.fog = new THREE.FogExp2(0x0d131c, 0.0135);
      this.hemiLight.color.setHex(0x8cb4dc);
      this.hemiLight.groundColor.setHex(0x161d28);
      this.hemiLight.intensity = 0.92;
      this.dirLight.color.setHex(0xffeed8);
      this.dirLight.intensity = 2.05;
      this.rimLight.color.setHex(0x38bdf8);
      this.rimLight.intensity = 0.55;
    }
  }

  private applyGraphicsQuality(): void {
    if (!this.renderer) return;
    if (this.isSoftwareGl) {
      this.renderer.setPixelRatio(1);
      this.renderer.shadowMap.enabled = false;
      return;
    }
    const maxPr = this.settings.graphicsQuality === 'balanced'
      ? 1.25
      : this.settings.graphicsQuality === 'high'
        ? 2
        : Math.min(window.devicePixelRatio || 1, 1.75);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxPr));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  }

  public updateSettings(next: SettingsState): void {
    this.settings = next;
    this.audio.applySettings(next);
    this.applyGraphicsQuality();
  }

  private resetInputs(): void {
    this.keys.clear();
    this.joystickX = 0;
    this.joystickY = 0;
    this.jumpHeld = false;
    this.jumpBufferTimer = 0;
    this.pointerDragging = false;
  }

  public setScreenState(state: GameScreenState): void {
    this.screenState = state;
    this.audio.setPaused(state === 'paused');
    this.resetInputs();
    if (state === 'playing') {
      this.audio.unlock();
      // Snap look direction neatly toward level spawnYaw when starting fresh
      if (this.elapsedTime < 0.05) {
        this.camYaw = this.currentLevel.spawnYaw ?? 0;
        this.camPitch = 0.42;
      }
    }
  }

  public setJoystickInput(x: number, y: number): void {
    if (this.screenState !== 'playing') {
      this.joystickX = 0;
      this.joystickY = 0;
      return;
    }
    const safeX = Number.isFinite(x) ? x : 0;
    const safeY = Number.isFinite(y) ? y : 0;
    this.joystickX = Math.max(-1, Math.min(1, safeX));
    this.joystickY = Math.max(-1, Math.min(1, safeY));
  }

  public triggerJump(pressed: boolean): void {
    this.audio.unlock();
    if (pressed) {
      if (this.screenState !== 'playing') return;
      this.jumpBufferTimer = 0.14;
      this.jumpHeld = true;
    } else {
      this.jumpHeld = false;
      // Variable jump cut if released early while ascending
      if (this.playerBody && this.screenState === 'playing') {
        const vel = this.playerBody.linvel();
        if (vel.y > 3.0) {
          this.playerBody.setLinvel({ x: vel.x, y: vel.y * 0.55, z: vel.z }, true);
        }
      }
    }
  }

  public triggerInteract(): void {
    this.audio.unlock();
    if (this.screenState !== 'playing' || this.levelCompletedFlag) return;
    this.handleInteractAction();
  }

  public rotateHeldBlock(): void {
    if (this.grabbedEntity) {
      this.grabbedEntity.targetYaw += Math.PI * 0.25;
      this.audio.playInteract(true);
    }
  }

  public rotateCameraBy(deltaYaw: number, deltaPitch: number): void {
    const sens = this.settings.cameraSensitivity;
    this.camYaw -= deltaYaw * sens;
    this.camPitch = THREE.MathUtils.clamp(this.camPitch + deltaPitch * sens, 0.14, 1.18);
  }

  public loadLevel(levelId: number): void {
    this.resetInputs();
    this.disposeCurrentLevel();
    const level = getLevelById(levelId);
    this.currentLevel = level;
    this.applyEnvironmentTheme(level.environment ?? 'citadel');
    this.elapsedTime = 0;
    this.respawnPos = [...level.spawn];
    this.movesRemaining = level.moveLimit ?? null;
    this.grabbedEntity = null;
    this.levelCompletedFlag = false;
    this.checkpointBanner = null;
    this.checkpointBannerTimer = 0;
    this.camYaw = level.spawnYaw ?? 0;
    this.camPitch = 0.42;
    this.grounded = false;
    this.onIce = false;
    this.coyoteTimer = 0;
    this.jumpBufferTimer = 0;
    this.standingPlatform = null;
    this.standingBridge = null;
    this.signalMap = {};

    const baseG = level.baseGravity ?? DEFAULT_GRAVITY;
    this.world = new RAPIER.World({ x: baseG[0], y: baseG[1], z: baseG[2] });

    // 1. Static platforms, walls, ramps, bounce pads, slippery ice & breakable ice slabs
    for (const plat of level.platforms) {
      const rbDesc = RAPIER.RigidBodyDesc.fixed().setTranslation(
        plat.position[0],
        plat.position[1],
        plat.position[2],
      );
      if (plat.rotation) {
        _eulerA.set(plat.rotation[0], plat.rotation[1], plat.rotation[2]);
        _qA.setFromEuler(_eulerA);
        rbDesc.setRotation({ x: _qA.x, y: _qA.y, z: _qA.z, w: _qA.w });
      }
      const rb = this.world.createRigidBody(rbDesc);
      const isSlippery = Boolean(plat.slippery);
      const colDesc = RAPIER.ColliderDesc.cuboid(
        plat.size[0] * 0.5,
        plat.size[1] * 0.5,
        plat.size[2] * 0.5,
      )
        .setFriction(plat.friction ?? (isSlippery ? 0.03 : 0.72))
        .setRestitution(plat.restitution ?? 0.08);
      const col = this.world.createCollider(colDesc, rb);
      this.staticColliderHandles.add(col.handle);
      if (isSlippery) {
        this.slipperyColliderHandles.add(col.handle);
      }

      if (plat.bounceVelocity) {
        this.bouncePads.push({
          colliderHandle: col.handle,
          bounceVelocity: plat.bounceVelocity,
          position: plat.position,
          halfSize: [plat.size[0] * 0.5, plat.size[1] * 0.5, plat.size[2] * 0.5],
        });
      }

      const tileSize = plat.style === 'ice' || plat.style === 'clearIce' ? 4.0 : 5.5;
      const geo = createWorldTiledBoxGeometry(plat.size[0], plat.size[1], plat.size[2], tileSize);

      if (plat.breakable) {
        const breakMat = this.mats.clearIce.clone();
        breakMat.color.setHex(0xe0f2fe);
        breakMat.emissive.setHex(0x0c4a6e);
        breakMat.emissiveIntensity = 0.28;
        const mesh = new THREE.Mesh(geo, breakMat);
        mesh.position.set(plat.position[0], plat.position[1], plat.position[2]);
        if (plat.rotation) {
          mesh.rotation.set(plat.rotation[0], plat.rotation[1], plat.rotation[2]);
        }
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        this.levelRoot.add(mesh);
        this.levelDisposables.push(() => {
          geo.dispose();
          breakMat.dispose();
        });
        this.breakablePlatforms.push({
          id: plat.id,
          collider: col,
          mesh,
          mat: breakMat,
          basePos: new THREE.Vector3(plat.position[0], plat.position[1], plat.position[2]),
          size: plat.size,
          collapseDelay: plat.breakable.collapseDelay,
          respawnDelay: plat.breakable.respawnDelay,
          state: { phase: 'intact', timer: 0 },
          dropVelocity: 0,
        });
      } else {
        const mat = getSurfaceMaterial(this.mats, plat.style);
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(plat.position[0], plat.position[1], plat.position[2]);
        if (plat.rotation) {
          mesh.rotation.set(plat.rotation[0], plat.rotation[1], plat.rotation[2]);
        }
        mesh.castShadow = plat.style !== 'clearIce';
        mesh.receiveShadow = true;
        this.levelRoot.add(mesh);
        this.levelDisposables.push(() => geo.dispose());
      }
    }

    // 2. Dynamic movable bodies (cubes, heavy cubes, spheres, slabs, low-friction frost blocks, thermal cores)
    for (const def of level.dynamicBodies) {
      const rbDesc = RAPIER.RigidBodyDesc.dynamic()
        .setTranslation(def.position[0], def.position[1], def.position[2])
        .setLinearDamping(def.lowFriction ? 0.1 : def.shape === 'sphere' ? 0.35 : 0.7)
        .setAngularDamping(def.lowFriction ? 0.6 : def.shape === 'sphere' ? 0.4 : 0.9)
        .setCcdEnabled(true);
      const body = this.world.createRigidBody(rbDesc);
      const colDesc = def.shape === 'sphere'
        ? RAPIER.ColliderDesc.ball(def.size[0] * 0.5)
        : RAPIER.ColliderDesc.cuboid(def.size[0] * 0.5, def.size[1] * 0.5, def.size[2] * 0.5);
      colDesc
        .setMass(def.mass)
        .setFriction(def.friction ?? (def.lowFriction ? 0.04 : 0.6))
        .setRestitution(def.restitution ?? 0.12);
      const collider = this.world.createCollider(colDesc, body);

      const rig = createDynamicPropRig(def.shape, def.size, this.mats, {
        lowFriction: def.lowFriction,
        heatConductive: def.heatConductive,
      });
      rig.group.position.set(def.position[0], def.position[1], def.position[2]);
      this.levelRoot.add(rig.group);
      this.levelDisposables.push(rig.dispose);

      this.dynamicEntities.push({
        def,
        body,
        collider,
        rig,
        targetYaw: 0,
      });
    }

    // 3. Mechanical, Frozen, Gravity & Thermal Switches
    for (const sw of level.switches) {
      const rig = createSwitchRig(sw.kind, this.mats, Boolean(sw.frozen));
      rig.group.position.set(sw.position[0], sw.position[1], sw.position[2]);
      this.levelRoot.add(rig.group);
      this.levelDisposables.push(rig.dispose);

      // Solid pedestal collider so orb doesn't pass through the switch pillar
      const rb = this.world.createRigidBody(
        RAPIER.RigidBodyDesc.fixed().setTranslation(sw.position[0], sw.position[1] + 0.6, sw.position[2]),
      );
      const col = this.world.createCollider(RAPIER.ColliderDesc.cylinder(0.6, 0.42), rb);
      this.staticColliderHandles.add(col.handle);

      const active = Boolean(sw.initialActive);
      this.signalMap[sw.id] = active;
      this.switchEntities.push({
        def: sw,
        rig,
        active,
        timerRemaining: 0,
        leverAngle: active ? 0.45 : -0.45,
      });
    }

    // 4. Pressure Plates & Heat-Sensitive Thermal Receptors
    for (const plate of level.pressurePlates) {
      const width = plate.size?.[0] ?? 2.2;
      const depth = plate.size?.[1] ?? 2.2;
      const rig = createPressurePlateRig(width, depth, this.mats, Boolean(plate.thermalOnly));
      rig.group.position.set(plate.position[0], plate.position[1], plate.position[2]);
      this.levelRoot.add(rig.group);
      this.levelDisposables.push(rig.dispose);

      this.signalMap[plate.id] = false;
      this.plateEntities.push({
        id: plate.id,
        position: plate.position,
        width,
        depth,
        minWeight: plate.minWeight ?? 1.5,
        requiresBlock: Boolean(plate.requiresBlock || plate.thermalOnly),
        thermalOnly: Boolean(plate.thermalOnly),
        rig,
        pressed: false,
        depressOffset: 0,
      });
    }

    // 5. Kinematic Sliding Blast Doors
    for (const door of level.doors) {
      const closedPos = new THREE.Vector3(...door.position);
      const openPos = new THREE.Vector3(
        door.position[0] + door.openOffset[0],
        door.position[1] + door.openOffset[1],
        door.position[2] + door.openOffset[2],
      );
      const rotY = door.rotationY ?? 0;
      _qA.setFromAxisAngle(_upY, rotY);

      const rb = this.world.createRigidBody(
        RAPIER.RigidBodyDesc.kinematicPositionBased()
          .setTranslation(closedPos.x, closedPos.y, closedPos.z)
          .setRotation({ x: _qA.x, y: _qA.y, z: _qA.z, w: _qA.w }),
      );
      const col = this.world.createCollider(
        RAPIER.ColliderDesc.cuboid(door.size[0] * 0.5, door.size[1] * 0.5, door.size[2] * 0.5),
        rb,
      );
      this.staticColliderHandles.add(col.handle);

      const rig = createDoorRig(door.size, this.mats);
      rig.group.position.copy(closedPos);
      rig.group.rotation.y = rotY;
      this.levelRoot.add(rig.group);
      this.levelDisposables.push(rig.dispose);

      this.doorEntities.push({
        id: door.id,
        closedPos,
        openPos,
        requiredSignals: door.requiredSignals,
        logic: door.logic ?? 'AND',
        rotationY: rotY,
        body: rb,
        rig,
        openProgress: 0,
        wasOpen: false,
      });
    }

    // 6. Moving Platforms & Elevators
    for (const mp of level.movingPlatforms) {
      const startVec = new THREE.Vector3(...mp.startPos);
      const endVec = new THREE.Vector3(...mp.endPos);
      const rb = this.world.createRigidBody(
        RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(startVec.x, startVec.y, startVec.z),
      );
      const col = this.world.createCollider(
        RAPIER.ColliderDesc.cuboid(mp.size[0] * 0.5, mp.size[1] * 0.5, mp.size[2] * 0.5)
          .setFriction(mp.slippery ? 0.04 : 0.95),
        rb,
      );
      this.staticColliderHandles.add(col.handle);
      if (mp.slippery) {
        this.slipperyColliderHandles.add(col.handle);
      }

      const geo = createWorldTiledBoxGeometry(mp.size[0], mp.size[1], mp.size[2], 4.5);
      const mesh = new THREE.Mesh(geo, getSurfaceMaterial(this.mats, mp.style ?? 'metal'));
      mesh.position.copy(startVec);
      mesh.castShadow = true;
      mesh.receiveShadow = true;

      // Subtle glowing trim border around moving platform (theme-appropriate)
      const rimGeo = new THREE.BoxGeometry(mp.size[0] + 0.08, 0.1, mp.size[2] + 0.08);
      const rimMat = this.activeTheme === 'inferno' ? this.mats.moltenEmissive : this.mats.cyanEmissive;
      const rimMesh = new THREE.Mesh(rimGeo, rimMat);
      rimMesh.position.y = -mp.size[1] * 0.32;
      mesh.add(rimMesh);

      this.levelRoot.add(mesh);
      this.levelDisposables.push(() => {
        geo.dispose();
        rimGeo.dispose();
      });

      this.movingPlatforms.push({
        def: mp,
        body: rb,
        collider: col,
        mesh,
        startVec,
        endVec,
        prevPos: startVec.clone(),
        currPos: startVec.clone(),
        velocity: new THREE.Vector3(),
        progress: 0,
        direction: 1,
        dwellTimer: 0,
      });
    }

    // 7. Rotating Bridges
    for (const br of level.rotatingBridges) {
      _qA.setFromAxisAngle(_upY, br.restAngleY);
      const rb = this.world.createRigidBody(
        RAPIER.RigidBodyDesc.kinematicPositionBased()
          .setTranslation(br.pivot[0], br.pivot[1], br.pivot[2])
          .setRotation({ x: _qA.x, y: _qA.y, z: _qA.z, w: _qA.w }),
      );
      const col = this.world.createCollider(
        RAPIER.ColliderDesc.cuboid(br.size[0] * 0.5, br.size[1] * 0.5, br.size[2] * 0.5)
          .setFriction(br.slippery ? 0.04 : 0.88),
        rb,
      );
      this.staticColliderHandles.add(col.handle);
      if (br.slippery) {
        this.slipperyColliderHandles.add(col.handle);
      }

      const geo = createWorldTiledBoxGeometry(br.size[0], br.size[1], br.size[2], 4.5);
      const mesh = new THREE.Mesh(geo, getSurfaceMaterial(this.mats, br.style ?? 'metal'));
      mesh.position.set(br.pivot[0], br.pivot[1], br.pivot[2]);
      mesh.rotation.y = br.restAngleY;
      mesh.castShadow = br.style !== 'clearIce';
      mesh.receiveShadow = true;

      const railGeo = new THREE.BoxGeometry(0.18, 0.22, br.size[2] * 0.96);
      const railMat = this.activeTheme === 'frozen' ? this.mats.frozenStone : this.mats.bronze;
      const railL = new THREE.Mesh(railGeo, railMat);
      railL.position.set(-br.size[0] * 0.44, br.size[1] * 0.55, 0);
      const railR = new THREE.Mesh(railGeo, railMat);
      railR.position.set(br.size[0] * 0.44, br.size[1] * 0.55, 0);
      mesh.add(railL, railR);

      this.levelRoot.add(mesh);
      this.levelDisposables.push(() => {
        geo.dispose();
        railGeo.dispose();
      });

      this.rotatingBridges.push({
        def: br,
        body: rb,
        collider: col,
        mesh,
        currentAngle: br.restAngleY,
        angularVel: 0,
      });
    }

    // 8. Gravity Zones (Subtle translucent cyan energy field shafts)
    for (const gz of level.gravityZones) {
      const geo = new THREE.BoxGeometry(gz.size[0], gz.size[1], gz.size[2]);
      const mat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.14,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(gz.position[0], gz.position[1], gz.position[2]);
      mesh.renderOrder = 2;
      this.levelRoot.add(mesh);
      this.levelDisposables.push(() => {
        geo.dispose();
        mat.dispose();
      });

      this.gravityZones.push({
        id: gz.id,
        position: gz.position,
        size: gz.size,
        gravity: gz.gravity,
        requiredSignals: gz.requiredSignals,
        logic: gz.logic,
        mesh,
        mat,
      });
    }

    // 9. Laser Hazards
    for (const las of level.lasers) {
      const rig = createLaserRig(las.start, las.end, this.mats);
      this.levelRoot.add(rig.group);
      this.levelDisposables.push(rig.dispose);
      const fullLength = Math.hypot(
        las.end[0] - las.start[0],
        las.end[1] - las.start[1],
        las.end[2] - las.start[2],
      );
      // Set initial full span so lasers render cleanly from Frame 0 before first physics tick
      rig.beamMesh.scale.set(1, fullLength, 1);
      rig.coreMesh.scale.set(1, fullLength, 1);
      this.laserEntities.push({
        id: las.id,
        start: las.start,
        end: las.end,
        fullLength,
        disableSignals: las.disableSignals,
        logic: las.logic,
        cyclePeriod: las.cyclePeriod,
        activeDuty: las.activeDuty,
        phaseOffset: las.phaseOffset,
        rig,
      });
    }

    // 9b. World 6 — Molten Lava Hazards (glowing magma pools + subtle sparing heat shimmer)
    for (const lava of level.lavaHazards ?? []) {
      const geo = createWorldTiledBoxGeometry(lava.size[0], lava.size[1], lava.size[2], 6.0);
      const mesh = new THREE.Mesh(geo, this.mats.lava);
      mesh.position.set(lava.position[0], lava.position[1], lava.position[2]);
      mesh.receiveShadow = false;
      this.levelRoot.add(mesh);
      this.levelDisposables.push(() => geo.dispose());

      let shimmerMesh: THREE.Mesh | null = null;
      if (lava.shimmer !== false) {
        const shGeo = new THREE.PlaneGeometry(lava.size[0] * 0.94, lava.size[2] * 0.94);
        shGeo.rotateX(-Math.PI * 0.5);
        const shMat = new THREE.MeshBasicMaterial({
          color: 0xfb923c,
          transparent: true,
          opacity: 0.075,
          depthWrite: false,
        });
        shimmerMesh = new THREE.Mesh(shGeo, shMat);
        shimmerMesh.position.set(
          lava.position[0],
          lava.position[1] + lava.size[1] * 0.5 + 0.35,
          lava.position[2],
        );
        shimmerMesh.renderOrder = 2;
        this.levelRoot.add(shimmerMesh);
        this.levelDisposables.push(() => {
          shGeo.dispose();
          shMat.dispose();
        });
      }

      this.lavaHazards.push({ def: lava, mesh, shimmerMesh });
    }

    // 9c. World 6 — Moving Furnace Obstacles (real Rapier kinematic rams / molten sweepers)
    for (const obs of level.movingObstacles ?? []) {
      const startVec = new THREE.Vector3(...obs.startPos);
      const endVec = new THREE.Vector3(...obs.endPos);
      const rb = this.world.createRigidBody(
        RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(startVec.x, startVec.y, startVec.z),
      );
      const col = this.world.createCollider(
        RAPIER.ColliderDesc.cuboid(obs.size[0] * 0.5, obs.size[1] * 0.5, obs.size[2] * 0.5)
          .setFriction(0.4)
          .setRestitution(0.2),
        rb,
      );
      this.staticColliderHandles.add(col.handle);

      const geo = createWorldTiledBoxGeometry(obs.size[0], obs.size[1], obs.size[2], 3.5);
      const mesh = new THREE.Mesh(
        geo,
        getSurfaceMaterial(this.mats, obs.style ?? 'industrialMetal'),
      );
      mesh.position.copy(startVec);
      mesh.castShadow = true;
      mesh.receiveShadow = true;

      // Subtle heat warning stripe along molten rams
      const stripeGeo = new THREE.BoxGeometry(obs.size[0] + 0.06, 0.16, obs.size[2] + 0.06);
      const stripeMesh = new THREE.Mesh(
        stripeGeo,
        obs.lethal ? this.mats.moltenEmissive : this.mats.amberEmissive,
      );
      mesh.add(stripeMesh);

      this.levelRoot.add(mesh);
      this.levelDisposables.push(() => {
        geo.dispose();
        stripeGeo.dispose();
      });

      this.movingObstacles.push({
        def: obs,
        body: rb,
        collider: col,
        mesh,
        startVec,
        endVec,
        currPos: startVec.clone(),
        progress: 0,
        direction: 1,
        dwellTimer: 0,
        active: true,
      });
    }

    // 10. Checkpoints
    for (const cp of level.checkpoints) {
      const rig = createCheckpointRig(this.mats);
      rig.group.position.set(cp.position[0], cp.position[1], cp.position[2]);
      this.levelRoot.add(rig.group);
      this.levelDisposables.push(rig.dispose);

      this.checkpointEntities.push({
        id: cp.id,
        position: cp.position,
        rig,
        activated: false,
      });
    }

    // 11. Exit Portal Monument
    this.portalRig = createPortalRig(this.mats);
    this.portalRig.group.position.set(
      level.portal.position[0],
      level.portal.position[1],
      level.portal.position[2],
    );
    if (level.portal.rotationY) {
      this.portalRig.group.rotation.y = level.portal.rotationY;
    }
    this.levelRoot.add(this.portalRig.group);
    this.levelDisposables.push(this.portalRig.dispose);

    // 12. Player Energy Orb
    const pDesc = RAPIER.RigidBodyDesc.dynamic()
      .setTranslation(level.spawn[0], level.spawn[1], level.spawn[2])
      .setLinearDamping(0.85)
      .setAngularDamping(1.35)
      .setCcdEnabled(true);
    this.playerBody = this.world.createRigidBody(pDesc);
    const pColDesc = RAPIER.ColliderDesc.ball(PLAYER_RADIUS)
      .setMass(1.8)
      .setFriction(0.7)
      .setRestitution(0.06);
    this.playerCollider = this.world.createCollider(pColDesc, this.playerBody);

    this.playerRig = createPlayerOrbRig(this.mats, this.isSoftwareGl);
    this.playerRig.group.position.set(level.spawn[0], level.spawn[1], level.spawn[2]);
    this.levelRoot.add(this.playerRig.group);
    this.levelRoot.add(this.playerRig.shadowDisc);
    this.levelDisposables.push(this.playerRig.dispose);

    // Position camera cleanly behind spawn facing forward
    this.camCurrentLook.set(level.spawn[0], level.spawn[1] + 0.4, level.spawn[2]);
    this.camCurrentPos.set(
      level.spawn[0] + Math.sin(this.camYaw) * this.camDistance,
      level.spawn[1] + 4.4,
      level.spawn[2] + Math.cos(this.camYaw) * this.camDistance,
    );
    this.camera.position.copy(this.camCurrentPos);
    this.camera.lookAt(this.camCurrentLook);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.pushHudSnapshot(true);
  }

  public restartLevel(): void {
    this.loadLevel(this.currentLevel.id);
    if (this.screenState !== 'playing') {
      this.setScreenState('playing');
    }
  }

  private disposeCurrentLevel(): void {
    if (this.tetherMesh) this.tetherMesh.visible = false;
    while (this.levelRoot.children.length > 0) {
      this.levelRoot.remove(this.levelRoot.children[0]);
    }
    for (const fn of this.levelDisposables) {
      try {
        fn();
      } catch {
        // Ignore cleanup edge cases
      }
    }
    this.levelDisposables = [];
    this.dynamicEntities = [];
    this.switchEntities = [];
    this.plateEntities = [];
    this.doorEntities = [];
    this.movingPlatforms = [];
    this.rotatingBridges = [];
    this.gravityZones = [];
    this.laserEntities = [];
    this.breakablePlatforms = [];
    this.lavaHazards = [];
    this.movingObstacles = [];
    this.checkpointEntities = [];
    this.bouncePads = [];
    this.staticColliderHandles.clear();
    this.slipperyColliderHandles.clear();
    this.playerRig = null;
    this.portalRig = null;
    this.playerBody = null;
    this.playerCollider = null;
    if (this.world) {
      this.world.free();
      this.world = null;
    }
  }

  private getActiveGravitySwitchVector(): Vec3 | null {
    for (const sw of this.switchEntities) {
      if (sw.def.kind === 'gravity' && sw.active && sw.def.gravityVector) {
        return sw.def.gravityVector;
      }
    }
    return null;
  }

  private getNearestInteractable(): {
    type: 'switch' | 'grab' | 'release' | null;
    prompt: string | null;
    sw?: SwitchEntity;
    dyn?: DynamicEntity;
  } {
    if (!this.playerBody) return { type: null, prompt: null };
    if (this.grabbedEntity) {
      return {
        type: 'release',
        prompt: 'Release Block [E] · Rotate [Q]',
        dyn: this.grabbedEntity,
      };
    }

    const p = this.playerBody.translation();

    // Prioritize nearby switches
    let nearestSw: SwitchEntity | undefined;
    let bestSwDist = 2.65;
    for (const sw of this.switchEntities) {
      const d = Math.hypot(
        p.x - sw.def.position[0],
        p.y - (sw.def.position[1] + 0.8),
        p.z - sw.def.position[2],
      );
      if (d < bestSwDist) {
        bestSwDist = d;
        nearestSw = sw;
      }
    }
    if (nearestSw) {
      const label = nearestSw.def.label ?? 'Switch';
      return {
        type: 'switch',
        prompt: `Activate ${label} [E]`,
        sw: nearestSw,
      };
    }

    // Check grabbable dynamic objects
    let nearestDyn: DynamicEntity | undefined;
    let bestDynDist = 3.2;
    for (const dyn of this.dynamicEntities) {
      if (dyn.def.grabbable === false) continue;
      const bp = dyn.body.translation();
      const d = Math.hypot(p.x - bp.x, p.y - bp.y, p.z - bp.z);
      if (d < bestDynDist) {
        bestDynDist = d;
        nearestDyn = dyn;
      }
    }
    if (nearestDyn) {
      return {
        type: 'grab',
        prompt: 'Grab Block [E]',
        dyn: nearestDyn,
      };
    }

    return { type: null, prompt: null };
  }

  private consumeMoveBudget(): boolean {
    if (this.movesRemaining === null) return true;
    if (this.movesRemaining <= 0) {
      this.audio.playImpact(0.8);
      this.checkpointBanner = 'Pulse Limit Reached — Press R to Restart';
      this.checkpointBannerTimer = 2.4;
      return false;
    }
    this.movesRemaining -= 1;
    return true;
  }

  private handleInteractAction(): void {
    const target = this.getNearestInteractable();
    if (target.type === 'release') {
      this.grabbedEntity = null;
      if (this.tetherMesh) this.tetherMesh.visible = false;
      this.audio.playInteract(false);
      this.pushHudSnapshot(true);
      return;
    }

    if (target.type === 'switch' && target.sw) {
      if (!this.consumeMoveBudget()) return;
      const sw = target.sw;
      if (sw.def.kind === 'timed' || sw.def.kind === 'thermal') {
        sw.active = true;
        sw.timerRemaining = sw.def.duration ?? 8.0;
      } else {
        sw.active = !sw.active;
      }
      this.signalMap[sw.def.id] = sw.active;
      this.audio.playSwitch(sw.active);
      this.cameraTrauma = Math.min(0.3, this.cameraTrauma + 0.14);
      this.pushHudSnapshot(true);
      return;
    }

    if (target.type === 'grab' && target.dyn) {
      if (!this.consumeMoveBudget()) return;
      this.grabbedEntity = target.dyn;
      const rot = target.dyn.body.rotation();
      _qA.set(rot.x, rot.y, rot.z, rot.w);
      _eulerA.setFromQuaternion(_qA, 'YXZ');
      target.dyn.targetYaw = _eulerA.y;
      this.audio.playInteract(true);
      this.pushHudSnapshot(true);
    }
  }

  private respawnPlayer(dueToHazard: boolean, hazardKind: 'laser' | 'lava' | 'fall' = dueToHazard ? 'laser' : 'fall'): void {
    if (!this.playerBody) return;
    this.grabbedEntity = null;
    if (this.tetherMesh) this.tetherMesh.visible = false;
    this.playerBody.setTranslation(
      { x: this.respawnPos[0], y: this.respawnPos[1] + 0.35, z: this.respawnPos[2] },
      true,
    );
    this.playerBody.setLinvel({ x: 0, y: 0, z: 0 }, true);
    this.playerBody.setAngvel({ x: 0, y: 0, z: 0 }, true);
    this.cameraTrauma = dueToHazard ? 0.55 : 0.35;
    if (hazardKind === 'lava') {
      this.hitstopTimer = 0.06;
      this.audio.playLavaSizzle();
    } else if (dueToHazard) {
      this.hitstopTimer = 0.06;
      this.audio.playLaserZap();
    } else {
      this.audio.playImpact(0.7);
    }
  }

  private stepSimulation(dt: number): void {
    if (!this.world || !this.playerBody || !this.playerCollider) return;

    this.elapsedTime += dt;

    // 1. Update timed & temperature-controlled switches
    for (const sw of this.switchEntities) {
      if ((sw.def.kind === 'timed' || sw.def.kind === 'thermal') && sw.active) {
        sw.timerRemaining -= dt;
        if (sw.timerRemaining <= 0) {
          sw.timerRemaining = 0;
          sw.active = false;
          this.signalMap[sw.def.id] = false;
          this.audio.playSwitch(false);
        }
      }
    }

    // 2. Evaluate pressure plates & heat-sensitive thermal receptors
    const pTrans = this.playerBody.translation();
    for (const plate of this.plateEntities) {
      let totalMass = 0;

      if (!plate.requiresBlock && !plate.thermalOnly) {
        const dx = Math.abs(pTrans.x - plate.position[0]);
        const dz = Math.abs(pTrans.z - plate.position[2]);
        const dy = pTrans.y - plate.position[1];
        if (dx <= plate.width * 0.56 && dz <= plate.depth * 0.56 && dy >= -0.1 && dy <= 1.25) {
          totalMass += 1.8;
        }
      }

      for (const dyn of this.dynamicEntities) {
        if (plate.thermalOnly && !dyn.def.heatConductive) continue;
        const bp = dyn.body.translation();
        const dx = Math.abs(bp.x - plate.position[0]);
        const dz = Math.abs(bp.z - plate.position[2]);
        const dy = bp.y - plate.position[1];
        if (dx <= plate.width * 0.62 && dz <= plate.depth * 0.62 && dy >= -0.1 && dy <= 1.65) {
          totalMass += dyn.def.mass;
        }
      }

      const nowPressed = totalMass >= plate.minWeight;
      if (nowPressed !== plate.pressed) {
        plate.pressed = nowPressed;
        this.signalMap[plate.id] = nowPressed;
        this.audio.playPlate(nowPressed);
      }
    }

    // 3. Apply global gravity switch to Rapier world
    const baseG = this.currentLevel.baseGravity ?? DEFAULT_GRAVITY;
    const swG = this.getActiveGravitySwitchVector();
    const worldGx = swG ? swG[0] : baseG[0];
    const worldGy = swG ? swG[1] : baseG[1];
    const worldGz = swG ? swG[2] : baseG[2];
    this.world.gravity = { x: worldGx, y: worldGy, z: worldGz };

    // 4. Apply localized gravity zone forces to player & dynamic bodies
    const applyZoneGravity = (body: RAPIER.RigidBody, mass: number) => {
      const pos = body.translation();
      const desired = resolveGravityAtPoint(
        [pos.x, pos.y, pos.z],
        baseG,
        swG,
        this.currentLevel.gravityZones,
        this.signalMap,
      );
      const diffX = desired[0] - worldGx;
      const diffY = desired[1] - worldGy;
      const diffZ = desired[2] - worldGz;
      if (Math.abs(diffX) > 0.01 || Math.abs(diffY) > 0.01 || Math.abs(diffZ) > 0.01) {
        body.applyImpulse(
          { x: diffX * mass * dt, y: diffY * mass * dt, z: diffZ * mass * dt },
          true,
        );
        // Cap vertical updraft speed smoothly so floating feels controlled
        const v = body.linvel();
        if (desired[1] > 0 && v.y > 7.2) {
          body.setLinvel({ x: v.x, y: 7.2, z: v.z }, true);
        }
      }
    };

    applyZoneGravity(this.playerBody, 1.8);
    for (const dyn of this.dynamicEntities) {
      applyZoneGravity(dyn.body, dyn.def.mass);
    }

    // 5. Update Kinematic Doors
    for (const door of this.doorEntities) {
      const shouldOpen = evaluateSignalCondition(door.requiredSignals, this.signalMap, door.logic);
      if (shouldOpen !== door.wasOpen) {
        door.wasOpen = shouldOpen;
        this.audio.playDoor(shouldOpen);
      }
      const target = shouldOpen ? 1 : 0;
      const step = dt * 1.9;
      if (door.openProgress < target) {
        door.openProgress = Math.min(1, door.openProgress + step);
      } else if (door.openProgress > target) {
        door.openProgress = Math.max(0, door.openProgress - step);
      }
      _vA.lerpVectors(door.closedPos, door.openPos, door.openProgress);
      door.body.setNextKinematicTranslation({ x: _vA.x, y: _vA.y, z: _vA.z });
      door.rig.group.position.copy(_vA);
      door.rig.stripMat.color.setHex(shouldOpen ? 0x38bdf8 : 0xf59e0b);
      door.rig.stripMat.emissive.setHex(shouldOpen ? 0x0284c7 : 0xd97706);
    }

    // 6. Update Kinematic Moving Platforms & Elevators
    for (const mp of this.movingPlatforms) {
      mp.prevPos.copy(mp.currPos);
      const hasSignals = Boolean(mp.def.requiredSignals && mp.def.requiredSignals.length > 0);
      const active = hasSignals
        ? evaluateSignalCondition(mp.def.requiredSignals, this.signalMap, mp.def.logic)
        : true;
      const dist = Math.max(0.01, mp.startVec.distanceTo(mp.endVec));
      const deltaFrac = (mp.def.speed / dist) * dt;

      if (hasSignals && !mp.def.pauseAtEnds) {
        // Gate-style deployable bridge: move to end when active, return to start when inactive
        const target = active ? 1 : 0;
        if (mp.progress < target) mp.progress = Math.min(1, mp.progress + deltaFrac);
        else if (mp.progress > target) mp.progress = Math.max(0, mp.progress - deltaFrac);
      } else if (active) {
        // Oscillating shuttle / elevator
        if (mp.dwellTimer > 0) {
          mp.dwellTimer -= dt;
        } else {
          mp.progress += deltaFrac * mp.direction;
          if (mp.progress >= 1) {
            mp.progress = 1;
            mp.direction = -1;
            mp.dwellTimer = mp.def.pauseAtEnds ?? 0.6;
          } else if (mp.progress <= 0) {
            mp.progress = 0;
            mp.direction = 1;
            mp.dwellTimer = mp.def.pauseAtEnds ?? 0.6;
          }
        }
      }

      // Smoothstep easing for shuttles feels mechanical and graceful
      const eased = mp.progress * mp.progress * (3 - 2 * mp.progress);
      mp.currPos.lerpVectors(mp.startVec, mp.endVec, eased);
      mp.velocity.subVectors(mp.currPos, mp.prevPos).divideScalar(dt);
      mp.body.setNextKinematicTranslation({ x: mp.currPos.x, y: mp.currPos.y, z: mp.currPos.z });
      mp.mesh.position.copy(mp.currPos);
    }

    // 7. Update Kinematic Rotating Bridges (recording angularVel for tangential carry)
    for (const br of this.rotatingBridges) {
      const prevAngle = br.currentAngle;
      const hasSignals = Boolean(br.def.requiredSignals && br.def.requiredSignals.length > 0);
      if (!hasSignals && br.def.continuousSpeed) {
        br.currentAngle += br.def.continuousSpeed * dt;
      } else {
        const active = evaluateSignalCondition(br.def.requiredSignals, this.signalMap, br.def.logic);
        const targetAngle = active ? br.def.activeAngleY : br.def.restAngleY;
        const diff = targetAngle - br.currentAngle;
        const maxStep = br.def.speed * dt;
        if (Math.abs(diff) <= maxStep) {
          br.currentAngle = targetAngle;
        } else {
          br.currentAngle += Math.sign(diff) * maxStep;
        }
      }
      br.angularVel = (br.currentAngle - prevAngle) / dt;
      _qA.setFromAxisAngle(_upY, br.currentAngle);
      br.body.setNextKinematicRotation({ x: _qA.x, y: _qA.y, z: _qA.z, w: _qA.w });
      br.mesh.rotation.y = br.currentAngle;
    }

    // 7b. Update Moving Furnace Obstacles
    for (const obs of this.movingObstacles) {
      const disabled = obs.def.disableSignals && obs.def.disableSignals.length > 0
        ? evaluateSignalCondition(obs.def.disableSignals, this.signalMap, obs.def.logic)
        : false;
      obs.active = !disabled;
      if (!disabled) {
        const dist = Math.max(0.01, obs.startVec.distanceTo(obs.endVec));
        const deltaFrac = (obs.def.speed / dist) * dt;
        if (obs.dwellTimer > 0) {
          obs.dwellTimer -= dt;
        } else {
          obs.progress += deltaFrac * obs.direction;
          if (obs.progress >= 1) {
            obs.progress = 1;
            obs.direction = -1;
            obs.dwellTimer = obs.def.pauseAtEnds ?? 0.35;
          } else if (obs.progress <= 0) {
            obs.progress = 0;
            obs.direction = 1;
            obs.dwellTimer = obs.def.pauseAtEnds ?? 0.35;
          }
        }
      } else {
        // Retract cleanly toward startPos when disabled
        obs.progress = Math.max(0, obs.progress - dt * 1.4);
      }
      const eased = obs.progress * obs.progress * (3 - 2 * obs.progress);
      obs.currPos.lerpVectors(obs.startVec, obs.endVec, eased);
      obs.body.setNextKinematicTranslation({ x: obs.currPos.x, y: obs.currPos.y, z: obs.currPos.z });
      obs.mesh.position.copy(obs.currPos);
    }

    // 8. Ground Detection via Rapier downward raycast
    const rayOrigin = { x: pTrans.x, y: pTrans.y, z: pTrans.z };
    const rayDir = { x: 0, y: -1, z: 0 };
    const ray = new RAPIER.Ray(rayOrigin, rayDir);
    const hit = this.world.castRay(
      ray,
      PLAYER_RADIUS + 0.16,
      true,
      undefined,
      undefined,
      this.playerCollider,
    );

    const wasGrounded = this.grounded;
    this.grounded = Boolean(hit);
    this.onIce = false;
    this.standingPlatform = null;
    this.standingBridge = null;
    if (hit) {
      this.coyoteTimer = 0.11;
      const hitHandle = hit.collider.handle;
      this.onIce = this.slipperyColliderHandles.has(hitHandle);

      // Check if standing on a moving platform
      for (const mp of this.movingPlatforms) {
        if (mp.collider.handle === hitHandle) {
          this.standingPlatform = mp;
          break;
        }
      }
      // Check if standing on a rotating bridge (for realistic tangential velocity carry)
      for (const br of this.rotatingBridges) {
        if (br.collider.handle === hitHandle) {
          this.standingBridge = br;
          break;
        }
      }
      // Landing squash + impact sound
      if (!wasGrounded && this.lastVerticalVel < -4.2) {
        const intensity = Math.min(1, Math.abs(this.lastVerticalVel) / 15);
        this.audio.playImpact(intensity);
        this.orbSquash = 0.78;
      }
      // Bounce pad check
      for (const bp of this.bouncePads) {
        if (bp.colliderHandle === hitHandle) {
          const curVel = this.playerBody.linvel();
          this.playerBody.setLinvel({ x: curVel.x, y: bp.bounceVelocity, z: curVel.z }, true);
          this.grounded = false;
          this.coyoteTimer = 0;
          this.orbSquash = 1.24;
          this.audio.playJump();
          break;
        }
      }
    } else {
      this.coyoteTimer = Math.max(0, this.coyoteTimer - dt);
    }

    // 8b. World 5 — Breakable / Collapsing Ice Platforms
    const stoodHandle = hit ? hit.collider.handle : -1;
    for (const bp of this.breakablePlatforms) {
      let triggered = stoodHandle === bp.collider.handle;
      if (!triggered && bp.state.phase === 'intact') {
        // Also fracture if a heavy dynamic block lands on it
        for (const dyn of this.dynamicEntities) {
          const dPos = dyn.body.translation();
          const topY = bp.basePos.y + bp.size[1] * 0.5;
          if (
            Math.abs(dPos.x - bp.basePos.x) <= bp.size[0] * 0.52 &&
            Math.abs(dPos.z - bp.basePos.z) <= bp.size[2] * 0.52 &&
            dPos.y >= topY - 0.1 &&
            dPos.y <= topY + dyn.def.size[1] * 0.65
          ) {
            triggered = true;
            break;
          }
        }
      }

      const stepRes = stepBreakableIceState(
        bp.state,
        triggered,
        dt,
        bp.collapseDelay,
        bp.respawnDelay,
      );
      bp.state = stepRes.next;

      if (stepRes.startedCracking) {
        this.audio.playIceCrack();
        this.cameraTrauma = Math.min(0.22, this.cameraTrauma + 0.08);
      }
      if (stepRes.justCollapsed) {
        bp.collider.setEnabled(false);
        this.playerBody.wakeUp();
        for (const dyn of this.dynamicEntities) {
          dyn.body.wakeUp();
        }
        bp.dropVelocity = -1.8;
        this.audio.playIceCrack();
      }
      if (stepRes.justReformed) {
        bp.collider.setEnabled(true);
        bp.dropVelocity = 0;
        bp.mesh.visible = true;
        bp.mesh.position.copy(bp.basePos);
        bp.mesh.rotation.set(0, 0, 0);
        bp.mat.opacity = 0.78;
        bp.mat.emissive.setHex(0x0c4a6e);
        bp.mat.emissiveIntensity = 0.28;
      }

      if (bp.state.phase === 'cracking') {
        const progress = 1 - Math.max(0, bp.state.timer / bp.collapseDelay);
        const jitter = 0.045 + progress * 0.08;
        bp.mesh.position.set(
          bp.basePos.x + Math.sin(this.elapsedTime * 55) * jitter,
          bp.basePos.y - progress * 0.08,
          bp.basePos.z + Math.cos(this.elapsedTime * 61) * jitter,
        );
        bp.mat.emissive.setHex(0x7dd3fc);
        bp.mat.emissiveIntensity = 0.45 + progress * 0.9;
      } else if (bp.state.phase === 'collapsed') {
        bp.dropVelocity -= 18 * dt;
        bp.mesh.position.y += bp.dropVelocity * dt;
        bp.mesh.rotation.x += dt * 0.6;
        bp.mat.opacity = Math.max(0, bp.mat.opacity - dt * 1.4);
        if (bp.mat.opacity <= 0.02) {
          bp.mesh.visible = false;
        }
      }
    }

    // 9. Player Movement (Camera-relative WASD / Arrows / Joystick)
    let moveRight = this.joystickX;
    let moveForward = -this.joystickY; // Joystick up is negative screen Y -> forward (+1)

    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) moveForward += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) moveForward -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) moveRight += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) moveRight -= 1;

    const inputLen = Math.hypot(moveRight, moveForward);
    if (inputLen > 1) {
      moveRight /= inputLen;
      moveForward /= inputLen;
    }

    _vForward.set(-Math.sin(this.camYaw), 0, -Math.cos(this.camYaw)).normalize();
    _vRight.set(Math.cos(this.camYaw), 0, -Math.sin(this.camYaw)).normalize();

    const wishX = _vForward.x * moveForward + _vRight.x * moveRight;
    const wishZ = _vForward.z * moveForward + _vRight.z * moveRight;

    const curVel = this.playerBody.linvel();
    this.lastVerticalVel = curVel.y;

    let platVelX = this.standingPlatform ? this.standingPlatform.velocity.x : 0;
    let platVelZ = this.standingPlatform ? this.standingPlatform.velocity.z : 0;

    // Tangential carry when standing on a rotating bridge/furnace turntable (v = omega x r)
    if (this.standingBridge && Math.abs(this.standingBridge.angularVel) > 1e-4) {
      const rx = pTrans.x - this.standingBridge.def.pivot[0];
      const rz = pTrans.z - this.standingBridge.def.pivot[2];
      platVelX += this.standingBridge.angularVel * rz;
      platVelZ -= this.standingBridge.angularVel * rx;
    }

    const maxSpeed = this.onIce ? 9.4 : 8.4;
    const accel = this.grounded ? (this.onIce ? 13.5 : 42) : 20;
    const targetVx = wishX * maxSpeed + platVelX;
    const targetVz = wishZ * maxSpeed + platVelZ;

    let nextVx = curVel.x;
    let nextVz = curVel.z;

    if (inputLen > 0.04) {
      const dvx = targetVx - curVel.x;
      const dvz = targetVz - curVel.z;
      const maxChange = accel * dt;
      const dvLen = Math.hypot(dvx, dvz);
      if (dvLen <= maxChange) {
        nextVx = targetVx;
        nextVz = targetVz;
      } else {
        nextVx = curVel.x + (dvx / dvLen) * maxChange;
        nextVz = curVel.z + (dvz / dvLen) * maxChange;
      }
    } else if (this.grounded) {
      // Crisp stopping deceleration on normal stone/metal; authentic low-friction glide on World 5 ice
      const decelRate = this.onIce ? 0.95 : 9.5;
      const decel = Math.exp(-decelRate * dt);
      nextVx = platVelX + (curVel.x - platVelX) * decel;
      nextVz = platVelZ + (curVel.z - platVelZ) * decel;
    }

    let nextVy = curVel.y;

    // Jump execution (coyote time + input buffer)
    if (this.jumpBufferTimer > 0) {
      this.jumpBufferTimer = Math.max(0, this.jumpBufferTimer - dt);
      if (this.coyoteTimer > 0) {
        nextVy = 9.7 + (this.standingPlatform ? Math.max(0, this.standingPlatform.velocity.y) : 0);
        this.grounded = false;
        this.coyoteTimer = 0;
        this.jumpBufferTimer = 0;
        this.orbSquash = 1.2;
        this.audio.playJump();
      }
    }

    this.playerBody.setLinvel({ x: nextVx, y: nextVy, z: nextVz }, true);

    // Apply rolling angular torque visually matched to travel velocity
    this.playerBody.setAngvel(
      { x: (nextVz - platVelZ) * 1.4, y: 0, z: -(nextVx - platVelX) * 1.4 },
      true,
    );

    // 10. Kinetic Tether Spring Physics for Grabbed Block
    if (this.grabbedEntity) {
      const dyn = this.grabbedEntity;
      const bp = dyn.body.translation();
      const holdDist = dyn.def.shape === 'slab' ? 2.75 : 2.25;
      const targetX = pTrans.x + _vForward.x * holdDist;
      const targetY = pTrans.y + 0.48;
      const targetZ = pTrans.z + _vForward.z * holdDist;

      const distToAnchor = Math.hypot(targetX - bp.x, targetY - bp.y, targetZ - bp.z);
      if (distToAnchor > 6.5) {
        // Auto-release if snagged far behind a wall
        this.grabbedEntity = null;
        this.audio.playInteract(false);
      } else {
        const bv = dyn.body.linvel();
        const springK = 14.5;
        const desiredVx = THREE.MathUtils.clamp((targetX - bp.x) * springK, -10, 10);
        const desiredVy = THREE.MathUtils.clamp((targetY - bp.y) * springK, -10, 10);
        const desiredVz = THREE.MathUtils.clamp((targetZ - bp.z) * springK, -10, 10);
        const blend = 1 - Math.exp(-14 * dt);
        dyn.body.setLinvel(
          {
            x: bv.x + (desiredVx - bv.x) * blend,
            y: bv.y + (desiredVy - bv.y) * blend,
            z: bv.z + (desiredVz - bv.z) * blend,
          },
          true,
        );

        // Smooth yaw orientation toward targetYaw so slabs can be aligned cleanly
        const rot = dyn.body.rotation();
        _qA.set(rot.x, rot.y, rot.z, rot.w);
        _eulerA.setFromQuaternion(_qA, 'YXZ');
        let yawErr = dyn.targetYaw - _eulerA.y;
        while (yawErr > Math.PI) yawErr -= Math.PI * 2;
        while (yawErr < -Math.PI) yawErr += Math.PI * 2;
        dyn.body.setAngvel({ x: 0, y: THREE.MathUtils.clamp(yawErr * 6, -5, 5), z: 0 }, true);
      }
    }

    // 11. Step Rapier Physics World
    this.world.step();

    // 12. Evaluate Laser Hazards (with real dynamic cube occlusion!)
    const updatedPlayerPos = this.playerBody.translation();
    const playerVec: Vec3 = [updatedPlayerPos.x, updatedPlayerPos.y, updatedPlayerPos.z];

    const blockerBoxes: LaserBlockerBox[] = [];
    for (const dyn of this.dynamicEntities) {
      if (dyn.def.blocksLaser === false) continue;
      const bp = dyn.body.translation();
      blockerBoxes.push({
        center: [bp.x, bp.y, bp.z],
        halfExtents: [dyn.def.size[0] * 0.52, dyn.def.size[1] * 0.52, dyn.def.size[2] * 0.52],
      });
    }

    for (const las of this.laserEntities) {
      const res = evaluateLaserBeam(
        las,
        this.signalMap,
        this.elapsedTime,
        blockerBoxes,
        playerVec,
        PLAYER_RADIUS,
      );
      las.rig.beamMesh.visible = res.active;
      las.rig.coreMesh.visible = res.active;
      if (res.active) {
        const len = Math.max(0.05, las.fullLength * res.hitFraction);
        las.rig.beamMesh.scale.set(1, len, 1);
        las.rig.coreMesh.scale.set(1, len, 1);
        if (res.hitsPlayer) {
          this.respawnPlayer(true);
          return;
        }
      }
    }

    // 12b. World 6 — Lava Hazards & Lethal Moving Furnace Obstacles
    for (const lava of this.lavaHazards) {
      if (evaluateLavaHazardOverlap(playerVec, PLAYER_RADIUS, lava.def)) {
        this.respawnPlayer(true, 'lava');
        return;
      }
      // Rescue dynamic cubes if dropped into molten lava so puzzles stay solvable
      for (const dyn of this.dynamicEntities) {
        const bp = dyn.body.translation();
        if (evaluateLavaHazardOverlap([bp.x, bp.y, bp.z], dyn.def.size[1] * 0.5, lava.def)) {
          if (this.grabbedEntity === dyn) this.grabbedEntity = null;
          dyn.body.setTranslation(
            { x: dyn.def.position[0], y: dyn.def.position[1] + 0.5, z: dyn.def.position[2] },
            true,
          );
          dyn.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
          dyn.body.setAngvel({ x: 0, y: 0, z: 0 }, true);
        }
      }
    }
    for (const obs of this.movingObstacles) {
      if (!obs.def.lethal || !obs.active) continue;
      if (
        evaluateLavaHazardOverlap(playerVec, PLAYER_RADIUS + 0.06, {
          position: [obs.currPos.x, obs.currPos.y, obs.currPos.z],
          size: obs.def.size,
        })
      ) {
        this.respawnPlayer(true, 'lava');
        return;
      }
    }

    // 13. Checkpoints
    for (const cp of this.checkpointEntities) {
      if (cp.activated) continue;
      const d = Math.hypot(
        updatedPlayerPos.x - cp.position[0],
        updatedPlayerPos.y - (cp.position[1] + 0.6),
        updatedPlayerPos.z - cp.position[2],
      );
      if (d <= 1.55) {
        cp.activated = true;
        this.respawnPos = [cp.position[0], cp.position[1] + 0.9, cp.position[2]];
        cp.rig.ringMat.color.setHex(0x38bdf8);
        cp.rig.ringMat.emissive.setHex(0x0284c7);
        cp.rig.ringMat.emissiveIntensity = 1.4;
        cp.rig.haloMesh.visible = true;
        this.checkpointBanner = 'Checkpoint Reached';
        this.checkpointBannerTimer = 2.0;
        this.audio.playCheckpoint();
        this.pushHudSnapshot(true);
      }
    }

    // 14. Fall Out-of-Bounds Recovery (for player and accidentally dropped dynamic blocks)
    if (updatedPlayerPos.y < this.currentLevel.fallY) {
      this.respawnPlayer(false, 'fall');
    }
    for (const dyn of this.dynamicEntities) {
      const bp = dyn.body.translation();
      if (bp.y < this.currentLevel.fallY) {
        dyn.body.setTranslation(
          { x: dyn.def.position[0], y: dyn.def.position[1] + 0.5, z: dyn.def.position[2] },
          true,
        );
        dyn.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
        dyn.body.setAngvel({ x: 0, y: 0, z: 0 }, true);
      }
    }

    // 15. Exit Portal Check
    this.portalUnlocked = evaluateSignalCondition(
      this.currentLevel.portal.requiredSignals,
      this.signalMap,
      this.currentLevel.portal.logic,
    );
    const portalPos = this.currentLevel.portal.position;
    const distPortal = Math.hypot(
      updatedPlayerPos.x - portalPos[0],
      updatedPlayerPos.y - (portalPos[1] + 1.4),
      updatedPlayerPos.z - portalPos[2],
    );
    if (this.portalUnlocked && distPortal <= 1.75 && !this.levelCompletedFlag) {
      this.levelCompletedFlag = true;
      this.resetInputs();
      this.grabbedEntity = null;
      if (this.tetherMesh) this.tetherMesh.visible = false;
      this.audio.playPortalComplete();
      this.callbacks.onLevelComplete(this.currentLevel.id, this.elapsedTime);
    }
  }

  private syncVisualsAndCamera(dt: number, nowSec: number): void {
    // Sync player orb mesh + shadow disc + gyro animations
    if (this.playerBody && this.playerRig && this.world && this.playerCollider) {
      const p = this.playerBody.translation();
      this.playerRig.group.position.set(p.x, p.y, p.z);

      this.orbSquash = THREE.MathUtils.damp(this.orbSquash, 1.0, 12, dt);
      const xzScale = 1 / Math.sqrt(this.orbSquash);
      this.playerRig.group.scale.set(xzScale, this.orbSquash, xzScale);

      const v = this.playerBody.linvel();
      const speed = Math.hypot(v.x, v.z);
      this.playerRig.outerRingA.rotation.x += dt * (1.2 + speed * 0.45);
      this.playerRig.outerRingA.rotation.y += dt * 0.9;
      this.playerRig.outerRingB.rotation.z -= dt * (1.4 + speed * 0.35);
      this.playerRig.coreMesh.rotation.y += dt * 1.6;

      // Ground contact shadow raycast
      const shRay = new RAPIER.Ray({ x: p.x, y: p.y, z: p.z }, { x: 0, y: -1, z: 0 });
      const shHit = this.world.castRay(shRay, 10, true, undefined, undefined, this.playerCollider);
      if (shHit) {
        const floorY = p.y - shHit.timeOfImpact;
        this.playerRig.shadowDisc.visible = true;
        this.playerRig.shadowDisc.position.set(p.x, floorY + 0.025, p.z);
        const s = Math.max(0.45, 1.05 - shHit.timeOfImpact * 0.08);
        this.playerRig.shadowDisc.scale.set(s, 1, s);
      } else {
        this.playerRig.shadowDisc.visible = false;
      }

      // Keep directional light shadow frustum centered near player
      this.dirLight.position.set(p.x + 16, p.y + 28, p.z + 18);
      this.dirLight.target.position.set(p.x, p.y, p.z);
      this.dirLight.target.updateMatrixWorld();
    }

    // Sync dynamic blocks
    for (const dyn of this.dynamicEntities) {
      const t = dyn.body.translation();
      const r = dyn.body.rotation();
      dyn.rig.group.position.set(t.x, t.y, t.z);
      dyn.rig.group.quaternion.set(r.x, r.y, r.z, r.w);
      const isHeld = this.grabbedEntity === dyn;
      dyn.rig.accentMat.emissiveIntensity = isHeld ? 1.85 : 0.55;
    }

    // Sync tether beam
    if (this.tetherMesh && this.grabbedEntity && this.playerBody) {
      const p = this.playerBody.translation();
      const b = this.grabbedEntity.body.translation();
      _vA.set(p.x, p.y, p.z);
      _vB.set(b.x, b.y, b.z);
      _vC.subVectors(_vB, _vA);
      const len = _vC.length();
      if (len > 0.05) {
        this.tetherMesh.visible = true;
        this.tetherMesh.position.copy(_vA);
        _vC.divideScalar(len);
        _qA.setFromUnitVectors(_upY, _vC);
        this.tetherMesh.quaternion.copy(_qA);
        this.tetherMesh.scale.set(1, len, 1);
      }
    } else if (this.tetherMesh) {
      this.tetherMesh.visible = false;
    }

    // Sync switch levers & crystals
    for (const sw of this.switchEntities) {
      const targetAngle = sw.active ? 0.45 : -0.45;
      sw.leverAngle = THREE.MathUtils.damp(sw.leverAngle, targetAngle, 12, dt);
      sw.rig.leverPivot.rotation.z = sw.leverAngle;
      const isThermal = sw.def.kind === 'thermal';
      const colorHex = isThermal
        ? (sw.active ? 0xfed7aa : 0x9a3412)
        : (sw.active ? 0x38bdf8 : 0xf59e0b);
      const emissiveHex = isThermal
        ? (sw.active ? 0xf97316 : 0x7c2d12)
        : (sw.active ? 0x0284c7 : 0xb45309);
      sw.rig.crystalMat.color.setHex(colorHex);
      sw.rig.crystalMat.emissive.setHex(emissiveHex);
    }

    // Sync pressure plate & thermal receptor depression
    for (const plate of this.plateEntities) {
      const targetY = plate.pressed ? 0.095 : 0.145;
      plate.rig.padMesh.position.y = THREE.MathUtils.damp(plate.rig.padMesh.position.y, targetY, 14, dt);
      if (plate.thermalOnly) {
        plate.rig.rimMat.color.setHex(plate.pressed ? 0xfed7aa : 0xc2410c);
        plate.rig.rimMat.emissive.setHex(plate.pressed ? 0xf97316 : 0x7c2d12);
        plate.rig.rimMat.emissiveIntensity = plate.pressed ? 1.55 : 0.65;
      } else {
        plate.rig.rimMat.color.setHex(plate.pressed ? 0x38bdf8 : 0xf59e0b);
        plate.rig.rimMat.emissive.setHex(plate.pressed ? 0x0284c7 : 0xb45309);
      }
    }

    // Animate molten magma flow & subtle heat shimmer in World 6
    if (this.activeTheme === 'inferno' && this.textures?.lavaMap) {
      this.textures.lavaMap.offset.x = (nowSec * 0.028) % 1;
      this.textures.lavaMap.offset.y = (nowSec * 0.017) % 1;
      for (let i = 0; i < this.lavaHazards.length; i++) {
        const lh = this.lavaHazards[i];
        if (lh.shimmerMesh) {
          lh.shimmerMesh.position.y =
            lh.def.position[1] + lh.def.size[1] * 0.5 + 0.32 + Math.sin(nowSec * 2.4 + i) * 0.08;
        }
      }
    }

    // Sync gravity zone visibility
    for (const gz of this.gravityZones) {
      const active = evaluateSignalCondition(gz.requiredSignals, this.signalMap, gz.logic);
      gz.mesh.visible = active;
      if (active) {
        gz.mat.opacity = 0.11 + Math.sin(nowSec * 3.0) * 0.035;
      }
    }

    // Animate Exit Portal
    if (this.portalRig) {
      const spin = this.portalUnlocked ? 1.0 : 0.15;
      this.portalRig.ringOuter.rotation.z += dt * 1.15 * spin;
      this.portalRig.ringInner.rotation.z -= dt * 1.85 * spin;
      this.portalRig.irisMat.opacity = this.portalUnlocked ? 0.36 + Math.sin(nowSec * 3.4) * 0.08 : 0.08;
      this.portalRig.irisMat.color.setHex(this.portalUnlocked ? 0x38bdf8 : 0x475569);
      this.portalRig.irisMat.emissive.setHex(this.portalUnlocked ? 0x0284c7 : 0x1e293b);
      this.portalRig.light.intensity = this.portalUnlocked ? 5.5 : 1.0;
    }

    // Decay checkpoint banner
    if (this.checkpointBannerTimer > 0) {
      this.checkpointBannerTimer -= dt;
      if (this.checkpointBannerTimer <= 0) {
        this.checkpointBanner = null;
      }
    }

    // Camera choreography
    if (this.screenState === 'title') {
      // Smooth monumental orbital tour around Level 1 / active level
      this.titleOrbitAngle += dt * 0.16;
      const focusX = this.currentLevel.spawn[0];
      const focusY = this.currentLevel.spawn[1] + 1.8;
      const focusZ = (this.currentLevel.spawn[2] + this.currentLevel.portal.position[2]) * 0.35;
      const orbitR = 17.5;
      _vCamDesired.set(
        focusX + Math.sin(this.titleOrbitAngle) * orbitR,
        focusY + 7.5 + Math.sin(this.titleOrbitAngle * 0.7) * 1.2,
        focusZ + Math.cos(this.titleOrbitAngle) * orbitR,
      );
      _vCamTarget.set(focusX - 2.2, focusY, focusZ - 2.0); // Offset slightly right so left-third title sits in clean negative space
      const alpha = 1 - Math.exp(-3.5 * dt);
      this.camCurrentPos.lerp(_vCamDesired, alpha);
      this.camCurrentLook.lerp(_vCamTarget, alpha);
      this.camera.position.copy(this.camCurrentPos);
      this.camera.lookAt(this.camCurrentLook);
    } else if (this.playerBody && this.world) {
      const p = this.playerBody.translation();
      _vCamTarget.set(p.x, p.y + 0.65, p.z);

      const horizDist = Math.cos(this.camPitch) * this.camDistance;
      const vertDist = Math.sin(this.camPitch) * this.camDistance;
      const rawOffsetX = Math.sin(this.camYaw) * horizDist;
      const rawOffsetY = vertDist + 0.85;
      const rawOffsetZ = Math.cos(this.camYaw) * horizDist;

      // Wall pull-in raycast so camera never clips through geometry
      let safeDist = Math.hypot(rawOffsetX, rawOffsetY, rawOffsetZ);
      const dirX = rawOffsetX / safeDist;
      const dirY = rawOffsetY / safeDist;
      const dirZ = rawOffsetZ / safeDist;

      const camRay = new RAPIER.Ray(
        { x: _vCamTarget.x, y: _vCamTarget.y, z: _vCamTarget.z },
        { x: dirX, y: dirY, z: dirZ },
      );
      const camHit = this.world.castRay(
        camRay,
        safeDist,
        true,
        undefined,
        undefined,
        this.playerCollider ?? undefined,
      );
      if (camHit && this.staticColliderHandles.has(camHit.collider.handle)) {
        safeDist = Math.max(2.6, camHit.timeOfImpact - 0.55);
      }

      _vCamDesired.set(
        _vCamTarget.x + dirX * safeDist,
        _vCamTarget.y + dirY * safeDist,
        _vCamTarget.z + dirZ * safeDist,
      );

      const posAlpha = 1 - Math.exp(-10.5 * dt);
      const lookAlpha = 1 - Math.exp(-14.0 * dt);
      this.camCurrentPos.lerp(_vCamDesired, posAlpha);
      this.camCurrentLook.lerp(_vCamTarget, lookAlpha);

      this.camera.position.copy(this.camCurrentPos);

      // Trauma shake
      if (this.cameraTrauma > 0.005) {
        this.cameraTrauma = Math.max(0, this.cameraTrauma - dt * 1.9);
        const shake = this.cameraTrauma * this.cameraTrauma * 0.42;
        this.camera.position.x += (Math.random() - 0.5) * shake;
        this.camera.position.y += (Math.random() - 0.5) * shake;
      }

      this.camera.lookAt(this.camCurrentLook);
    }
  }

  private pushHudSnapshot(force = false): void {
    const now = performance.now();
    if (!force && now - this.lastHudPushMs < 110) return;
    this.lastHudPushMs = now;

    const interact = this.getNearestInteractable();
    let activeTimer: number | null = null;
    let timedLabel: string | null = null;
    for (const sw of this.switchEntities) {
      if ((sw.def.kind === 'timed' || sw.def.kind === 'thermal') && sw.active && sw.timerRemaining > 0) {
        if (activeTimer === null || sw.timerRemaining < activeTimer) {
          activeTimer = sw.timerRemaining;
          timedLabel = sw.def.kind === 'thermal' ? 'Thermal' : 'Timer';
        }
      }
    }

    let gravLabel: string | null = null;
    if (this.playerBody) {
      const p = this.playerBody.translation();
      if (this.renderer?.domElement) {
        this.renderer.domElement.dataset.levelId = String(this.currentLevel.id);
        this.renderer.domElement.dataset.env = this.activeTheme;
        this.renderer.domElement.dataset.onIce = this.onIce ? 'true' : 'false';
        this.renderer.domElement.dataset.fps = String(this.currentFps);
        this.renderer.domElement.dataset.playerPos = `${p.x.toFixed(2)},${p.y.toFixed(2)},${p.z.toFixed(2)}`;
      }
      const effG = resolveGravityAtPoint(
        [p.x, p.y, p.z],
        this.currentLevel.baseGravity ?? DEFAULT_GRAVITY,
        this.getActiveGravitySwitchVector(),
        this.currentLevel.gravityZones,
        this.signalMap,
      );
      gravLabel = describeGravityLabel(effG);
    }

    this.callbacks.onHudUpdate({
      levelId: this.currentLevel.id,
      levelTitle: this.currentLevel.title,
      tierLabel: TIER_META[this.currentLevel.tier].label,
      objective: this.currentLevel.objective,
      elapsedTime: this.elapsedTime,
      interactPrompt: interact.prompt,
      interactType: interact.type,
      isGrabbing: Boolean(this.grabbedEntity),
      gravityLabel: gravLabel,
      movesRemaining: this.movesRemaining,
      moveLimit: this.currentLevel.moveLimit ?? null,
      portalUnlocked: this.portalUnlocked,
      checkpointBanner: this.checkpointBanner,
      timedRemaining: activeTimer,
      timedLabel,
      fps: this.currentFps,
    });
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync?.(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed || !this.ready) return;

    const nowMs = performance.now();
    const rawDt = Math.max(0.001, (nowMs - this.lastFrameMs) / 1000);
    this.lastFrameMs = nowMs;
    const clampedDt = Math.min(rawDt, 0.05);

    // Real FPS measurement
    this.fpsFrames += 1;
    if (nowMs - this.fpsWindowStart >= 500) {
      this.currentFps = Math.round((this.fpsFrames * 1000) / (nowMs - this.fpsWindowStart));
      this.fpsFrames = 0;
      this.fpsWindowStart = nowMs;
    }

    if (this.screenState === 'playing' && !this.levelCompletedFlag) {
      if (this.hitstopTimer > 0) {
        this.hitstopTimer = Math.max(0, this.hitstopTimer - clampedDt);
      } else {
        this.physicsAccumulator += clampedDt;
        let substeps = 0;
        while (this.physicsAccumulator >= FIXED_DT && substeps < 4) {
          this.stepSimulation(FIXED_DT);
          this.physicsAccumulator -= FIXED_DT;
          substeps += 1;
        }
      }
      this.pushHudSnapshot(false);
    }

    this.syncVisualsAndCamera(clampedDt, nowMs * 0.001);
    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  // =========================================================================
  // Event Binding & Cleanup
  // =========================================================================

  private onKeyDown = (e: KeyboardEvent): void => {
    if (this.screenState === 'playing') {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
      }
      if (!e.repeat) {
        if (e.code === 'Space') {
          this.triggerJump(true);
        } else if (e.code === 'KeyE') {
          this.triggerInteract();
        } else if (e.code === 'KeyQ') {
          this.rotateHeldBlock();
        } else if (e.code === 'KeyR') {
          this.callbacks.onRequestRestart();
        } else if (e.code === 'KeyP' || e.code === 'Escape') {
          this.callbacks.onRequestPauseToggle();
        } else if (e.code === 'KeyM') {
          this.callbacks.onRequestMuteToggle();
        }
      }
      this.keys.add(e.code);
    } else if (this.screenState === 'paused') {
      if (!e.repeat && (e.code === 'Escape' || e.code === 'KeyP')) {
        e.preventDefault();
        this.callbacks.onRequestPauseToggle();
      }
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
    if (e.code === 'Space' && this.screenState === 'playing') {
      this.triggerJump(false);
    }
  };

  private onWindowBlur = (): void => {
    this.resetInputs();
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (this.screenState !== 'playing') return;
    // Ignore touch pointers here (mobile camera swipe is handled cleanly on the dedicated right-side swipe zone)
    if (e.pointerType === 'touch') return;
    if (e.button !== 0 && e.button !== 2) return;
    this.audio.unlock();
    this.pointerDragging = true;
    this.lastPointerX = e.clientX;
    this.lastPointerY = e.clientY;
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (!this.pointerDragging || this.screenState !== 'playing') return;
    const dx = e.clientX - this.lastPointerX;
    const dy = e.clientY - this.lastPointerY;
    this.lastPointerX = e.clientX;
    this.lastPointerY = e.clientY;
    this.rotateCameraBy(dx * 0.0055, dy * 0.0045);
  };

  private onPointerUp = (): void => {
    this.pointerDragging = false;
  };

  private onContextMenu = (e: MouseEvent): void => {
    if (this.screenState === 'playing') {
      e.preventDefault();
    }
  };

  private handleResize = (): void => {
    if (!this.renderer || !this.camera) return;
    const width = Math.max(1, this.container.clientWidth || window.innerWidth);
    const height = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.applyGraphicsQuality();
  };

  private bindEvents(): void {
    window.addEventListener('keydown', this.onKeyDown, { passive: false });
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    document.addEventListener('visibilitychange', this.onWindowBlur);

    const dom = this.renderer.domElement;
    dom.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    dom.addEventListener('contextmenu', this.onContextMenu);

    this.resizeObserver = new ResizeObserver(this.handleResize);
    this.resizeObserver.observe(this.container);
    window.addEventListener('resize', this.handleResize);
  }

  public getPlayerPosition(): Vec3 | null {
    if (!this.playerBody) return null;
    const t = this.playerBody.translation();
    return [t.x, t.y, t.z];
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    document.removeEventListener('visibilitychange', this.onWindowBlur);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('resize', this.handleResize);
    this.resizeObserver?.disconnect();

    if (this.renderer?.domElement) {
      this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);
      this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu);
      this.renderer.domElement.remove();
    }

    this.disposeCurrentLevel();
    for (const fn of this.backdropDisposables) {
      fn();
    }
    this.backdropDisposables = [];
    if (this.tetherMesh) {
      this.tetherMesh.geometry.dispose();
      (this.tetherMesh.material as THREE.Material).dispose();
    }
    this.mats?.dispose();
    this.textures?.dispose();
    this.envTexture?.dispose();
    this.renderer?.dispose();
    this.audio.dispose();
  }
}
