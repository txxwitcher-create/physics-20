import { useCallback, useEffect, useRef, useState } from 'react';
import { CompletionModal } from './components/CompletionModal';
import { GameHud } from './components/GameHud';
import { LevelSelectModal } from './components/LevelSelectModal';
import { PauseModal } from './components/PauseModal';
import { SettingsModal } from './components/SettingsModal';
import { TitleOverlay } from './components/TitleOverlay';
import { TouchControls } from './components/TouchControls';
import { Physics20Engine } from './game/engine';
import { getLevelById } from './game/levels';
import { TIER_META } from './game/rules';
import {
  loadProgress,
  loadSettings,
  recordLevelCompletion,
  resetProgressStorage,
  saveProgress,
  saveSettings,
  TOTAL_LEVELS,
} from './game/storage';
import type {
  CompletionSummary,
  GameScreenState,
  HudSnapshot,
  ProgressState,
  SettingsState,
} from './game/types';

function readQueryParams(): { autostart: boolean; level: number | null; fps: boolean } {
  try {
    const params = new URLSearchParams(window.location.search);
    const autostart = params.get('autostart') === '1';
    const rawLevel = params.get('level');
    const parsedLevel = rawLevel ? Number(rawLevel) : NaN;
    const level = Number.isInteger(parsedLevel) && parsedLevel >= 1 && parsedLevel <= TOTAL_LEVELS
      ? parsedLevel
      : null;
    const fps = params.get('fps') === '1';
    return { autostart, level, fps };
  } catch {
    return { autostart: false, level: null, fps: false };
  }
}

function detectTouchViewport(): boolean {
  if (typeof window === 'undefined') return false;
  const coarse = window.matchMedia?.('(pointer: coarse)').matches ?? false;
  return coarse || window.innerWidth <= 820;
}

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<Physics20Engine | null>(null);

  const [progress, setProgress] = useState<ProgressState>(() => loadProgress());
  const [settings, setSettings] = useState<SettingsState>(() => {
    const loaded = loadSettings();
    const qp = readQueryParams();
    return qp.fps ? { ...loaded, showFps: true } : loaded;
  });

  const [screen, setScreen] = useState<GameScreenState>('loading');
  const [activeModal, setActiveModal] = useState<'none' | 'levels' | 'settings'>('none');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [completionSummary, setCompletionSummary] = useState<CompletionSummary | null>(null);
  const [isTouchViewport, setIsTouchViewport] = useState<boolean>(() => detectTouchViewport());
  const [touchResetNonce, setTouchResetNonce] = useState(0);

  const initialLevel = (() => {
    const qp = readQueryParams();
    if (qp.level) return qp.level;
    return loadProgress().unlockedLevel;
  })();

  const [hud, setHud] = useState<HudSnapshot>(() => {
    const lvl = getLevelById(initialLevel);
    return {
      levelId: lvl.id,
      levelTitle: lvl.title,
      tierLabel: TIER_META[lvl.tier].label,
      objective: lvl.objective,
      elapsedTime: 0,
      interactPrompt: null,
      interactType: null,
      isGrabbing: false,
      gravityLabel: null,
      movesRemaining: lvl.moveLimit ?? null,
      moveLimit: lvl.moveLimit ?? null,
      portalUnlocked: true,
      checkpointBanner: null,
      timedRemaining: null,
      timedLabel: null,
      fps: 60,
    };
  });

  // Mutable refs so stable engine callbacks never capture stale React state
  const screenRef = useRef<GameScreenState>(screen);
  const progressRef = useRef<ProgressState>(progress);
  const settingsRef = useRef<SettingsState>(settings);
  screenRef.current = screen;
  progressRef.current = progress;
  settingsRef.current = settings;

  // Sync game state to document.body.dataset.state
  useEffect(() => {
    const bodyState = screen === 'complete'
      ? 'gameover'
      : screen === 'loading' || screen === 'error'
        ? 'title'
        : screen;
    document.body.dataset.state = bodyState;
  }, [screen]);

  // Keep touch viewport state synced on resize
  useEffect(() => {
    const onResize = () => setIsTouchViewport(detectTouchViewport());
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const updateSettings = useCallback((next: SettingsState) => {
    setSettings(next);
    saveSettings(next);
    engineRef.current?.updateSettings(next);
  }, []);

  const toggleMute = useCallback(() => {
    const cur = settingsRef.current;
    const allMuted = !cur.sfxEnabled && !cur.musicEnabled;
    const next: SettingsState = allMuted
      ? { ...cur, sfxEnabled: true, musicEnabled: true }
      : { ...cur, sfxEnabled: false, musicEnabled: false };
    updateSettings(next);
  }, [updateSettings]);

  const startPlayingLevel = useCallback((levelId: number) => {
    setActiveModal('none');
    setCompletionSummary(null);
    setTouchResetNonce((n) => n + 1);
    engineRef.current?.loadLevel(levelId);
    engineRef.current?.setScreenState('playing');
    setScreen('playing');
  }, []);

  const handlePlayFromTitle = useCallback(() => {
    const targetLevel = progressRef.current.unlockedLevel;
    startPlayingLevel(targetLevel);
  }, [startPlayingLevel]);

  const handlePauseToggle = useCallback(() => {
    if (screenRef.current === 'playing') {
      engineRef.current?.setScreenState('paused');
      setScreen('paused');
    } else if (screenRef.current === 'paused') {
      setActiveModal('none');
      engineRef.current?.setScreenState('playing');
      setScreen('playing');
    }
  }, []);

  const handleRestart = useCallback(() => {
    setActiveModal('none');
    setCompletionSummary(null);
    setTouchResetNonce((n) => n + 1);
    engineRef.current?.restartLevel();
    setScreen('playing');
  }, []);

  const handleJoystickChange = useCallback((x: number, y: number) => {
    engineRef.current?.setJoystickInput(x, y);
  }, []);

  const handleJumpChange = useCallback((pressed: boolean) => {
    engineRef.current?.triggerJump(pressed);
  }, []);

  const handleInteract = useCallback(() => {
    engineRef.current?.triggerInteract();
  }, []);

  const handleRotateBlock = useCallback(() => {
    engineRef.current?.rotateHeldBlock();
  }, []);

  const handleCameraDelta = useCallback((dx: number, dy: number) => {
    engineRef.current?.rotateCameraBy(dx, dy);
  }, []);

  const handleMainMenu = useCallback(() => {
    setActiveModal('none');
    setCompletionSummary(null);
    engineRef.current?.setScreenState('title');
    setScreen('title');
  }, []);

  const handleResetProgress = useCallback(() => {
    const fresh = resetProgressStorage();
    setProgress(fresh);
    engineRef.current?.loadLevel(1);
  }, []);

  // Mount Three.js + Rapier engine exactly once
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const qp = readQueryParams();
    const bootLevelId = qp.level ?? progressRef.current.unlockedLevel;

    const engine = new Physics20Engine(mount, settingsRef.current, {
      onHudUpdate: (snapshot) => {
        setHud(snapshot);
      },
      onLevelComplete: (levelId, elapsedTime) => {
        const lvl = getLevelById(levelId);
        const { next, isNewBest, bestTime } = recordLevelCompletion(
          progressRef.current,
          levelId,
          elapsedTime,
        );
        setProgress(next);
        saveProgress(next);
        setCompletionSummary({
          levelId,
          levelTitle: lvl.title,
          elapsedTime,
          bestTime,
          isNewBest,
          hasNextLevel: levelId < TOTAL_LEVELS,
        });
        engine.setScreenState('complete');
        setScreen('complete');
      },
      onRequestPauseToggle: () => {
        handlePauseToggle();
      },
      onRequestRestart: () => {
        handleRestart();
      },
      onRequestMuteToggle: () => {
        toggleMute();
      },
      onError: (message) => {
        setErrorMessage(message);
        setScreen('error');
      },
    });

    engineRef.current = engine;

    void engine.init(bootLevelId).then(() => {
      if (engineRef.current !== engine) return;
      if (qp.autostart) {
        engine.setScreenState('playing');
        setScreen('playing');
      } else {
        engine.setScreenState('title');
        setScreen('title');
      }
    });

    return () => {
      engine.dispose();
      if (engineRef.current === engine) {
        engineRef.current = null;
      }
    };
  }, [handlePauseToggle, handleRestart, toggleMute]);

  // Title Screen Enter/Space keyboard start handshake
  useEffect(() => {
    const onTitleKeyDown = (e: KeyboardEvent) => {
      if (screenRef.current !== 'title' || activeModal !== 'none') return;
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        handlePlayFromTitle();
      }
    };
    window.addEventListener('keydown', onTitleKeyDown);
    return () => window.removeEventListener('keydown', onTitleKeyDown);
  }, [activeModal, handlePlayFromTitle]);

  const showTouchControls =
    screen === 'playing' &&
    activeModal === 'none' &&
    (settings.touchControlsMode === 'always' ||
      (settings.touchControlsMode === 'auto' && isTouchViewport));

  const isMuted = !settings.sfxEnabled && !settings.musicEnabled;

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#0d1117]">
      {/* Isolated full-bleed WebGL Canvas container */}
      <div
        ref={mountRef}
        className={`fixed inset-0 w-full h-full ${screen === 'playing' ? 'gameplay-touch-layer' : ''}`}
      />

      {/* Loading State */}
      {screen === 'loading' && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0d1117] text-slate-200">
          <div className="font-display text-2xl font-semibold tracking-wider mb-2">
            PHYSICS <span className="text-[#38bdf8] font-mono-num">20</span>
          </div>
          <div className="text-xs text-slate-400">Initializing 3D physics simulation…</div>
        </div>
      )}

      {/* Runtime Error Fallback */}
      {screen === 'error' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-[#0d1117]">
          <div className="max-w-md w-full rounded-xl p-6 bg-[#111824] border border-red-900/60">
            <h1 className="font-display text-xl font-semibold text-slate-100 mb-2">
              Unable to Start 3D Engine
            </h1>
            <p className="text-sm text-slate-300 mb-5">
              {errorMessage ?? 'WebGL or physics initialization failed on this device.'}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2.5 rounded-lg bg-[#0284c7] hover:bg-[#0ea5e9] text-white text-sm font-semibold cursor-pointer"
            >
              Reload Game
            </button>
          </div>
        </div>
      )}

      {/* Main Title Screen */}
      {screen === 'title' && activeModal === 'none' && (
        <TitleOverlay
          progress={progress}
          onPlay={handlePlayFromTitle}
          onOpenLevels={() => setActiveModal('levels')}
          onOpenSettings={() => setActiveModal('settings')}
        />
      )}

      {/* Minimal Gameplay HUD */}
      {screen === 'playing' && (
        <GameHud
          hud={hud}
          isMuted={isMuted}
          showFps={settings.showFps}
          showTouchControls={showTouchControls}
          onPause={handlePauseToggle}
          onRestart={handleRestart}
          onToggleMute={toggleMute}
        />
      )}

      {/* Mobile Touch Controls (Joystick + Jump + Contextual Interact + Camera Swipe) */}
      <TouchControls
        visible={showTouchControls}
        resetKey={`${hud.levelId}-${touchResetNonce}`}
        interactType={hud.interactType}
        isGrabbing={hud.isGrabbing}
        onJoystickChange={handleJoystickChange}
        onJumpChange={handleJumpChange}
        onInteract={handleInteract}
        onRotateBlock={handleRotateBlock}
        onCameraDelta={handleCameraDelta}
      />

      {/* Pause Overlay */}
      {screen === 'paused' && activeModal === 'none' && (
        <PauseModal
          levelId={hud.levelId}
          levelTitle={hud.levelTitle}
          onResume={handlePauseToggle}
          onRestart={handleRestart}
          onOpenLevels={() => setActiveModal('levels')}
          onOpenSettings={() => setActiveModal('settings')}
          onMainMenu={handleMainMenu}
        />
      )}

      {/* Level Completion Modal */}
      {screen === 'complete' && completionSummary && activeModal === 'none' && (
        <CompletionModal
          summary={completionSummary}
          onNextLevel={() => startPlayingLevel(Math.min(TOTAL_LEVELS, completionSummary.levelId + 1))}
          onReplay={() => startPlayingLevel(completionSummary.levelId)}
          onOpenLevels={() => setActiveModal('levels')}
        />
      )}

      {/* 20-Level Selection Modal */}
      {activeModal === 'levels' && (
        <LevelSelectModal
          progress={progress}
          currentLevelId={hud.levelId}
          onSelectLevel={(id) => startPlayingLevel(id)}
          onClose={() => setActiveModal('none')}
        />
      )}

      {/* Settings Modal */}
      {activeModal === 'settings' && (
        <SettingsModal
          settings={settings}
          onChange={updateSettings}
          onResetProgress={handleResetProgress}
          onClose={() => setActiveModal('none')}
        />
      )}
    </main>
  );
}
