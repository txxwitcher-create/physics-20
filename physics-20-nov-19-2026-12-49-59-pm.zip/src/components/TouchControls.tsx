import React, { useCallback, useEffect, useRef, useState } from 'react';
import { computeJoystickOutput } from '../game/rules';

interface TouchControlsProps {
  visible: boolean;
  resetKey?: string | number;
  interactType: 'switch' | 'grab' | 'release' | null;
  isGrabbing: boolean;
  onJoystickChange: (x: number, y: number) => void;
  onJumpChange: (pressed: boolean) => void;
  onInteract: () => void;
  onRotateBlock: () => void;
  onCameraDelta: (dx: number, dy: number) => void;
}

const JOYSTICK_MAX_RADIUS = 42;

function safeSetPointerCapture(el: Element | null, pointerId: number): void {
  if (!el || typeof el.setPointerCapture !== 'function') return;
  try {
    el.setPointerCapture(pointerId);
  } catch {
    // Ignore when pointer is synthetic or already inactive
  }
}

function safeReleasePointerCapture(el: Element | null, pointerId: number): void {
  if (!el || typeof el.releasePointerCapture !== 'function') return;
  try {
    if (typeof el.hasPointerCapture === 'function' && !el.hasPointerCapture(pointerId)) {
      return;
    }
    el.releasePointerCapture(pointerId);
  } catch {
    // Ignore when capture was already lost
  }
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  visible,
  resetKey,
  interactType,
  isGrabbing,
  onJoystickChange,
  onJumpChange,
  onInteract,
  onRotateBlock,
  onCameraDelta,
}) => {
  const joyElRef = useRef<HTMLDivElement | null>(null);
  const camElRef = useRef<HTMLDivElement | null>(null);
  const jumpElRef = useRef<HTMLButtonElement | null>(null);

  const joyPointerId = useRef<number | null>(null);
  const joyCenter = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [joyActive, setJoyActive] = useState(false);

  const camPointerId = useRef<number | null>(null);
  const camLastPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const jumpPointerId = useRef<number | null>(null);

  // Keep latest callbacks in refs so lifecycle reset effects never invoke stale closures
  const onJoystickChangeRef = useRef(onJoystickChange);
  const onJumpChangeRef = useRef(onJumpChange);
  const onCameraDeltaRef = useRef(onCameraDelta);
  onJoystickChangeRef.current = onJoystickChange;
  onJumpChangeRef.current = onJumpChange;
  onCameraDeltaRef.current = onCameraDelta;

  const resetJoystick = useCallback(() => {
    const activeId = joyPointerId.current;
    if (activeId !== null) {
      safeReleasePointerCapture(joyElRef.current, activeId);
      joyPointerId.current = null;
    }
    setJoyActive(false);
    setKnobOffset((prev) => (prev.x === 0 && prev.y === 0 ? prev : { x: 0, y: 0 }));
    onJoystickChangeRef.current(0, 0);
  }, []);

  const resetCamera = useCallback(() => {
    const activeId = camPointerId.current;
    if (activeId !== null) {
      safeReleasePointerCapture(camElRef.current, activeId);
      camPointerId.current = null;
    }
  }, []);

  const resetJump = useCallback(() => {
    const activeId = jumpPointerId.current;
    if (activeId !== null) {
      safeReleasePointerCapture(jumpElRef.current, activeId);
      jumpPointerId.current = null;
      onJumpChangeRef.current(false);
    }
  }, []);

  const resetAllInputs = useCallback(() => {
    resetJoystick();
    resetCamera();
    resetJump();
  }, [resetCamera, resetJoystick, resetJump]);

  // Reset all touch inputs whenever visibility toggles off (pause/complete/modal) or level changes/restarts
  useEffect(() => {
    resetAllInputs();
  }, [visible, resetKey, resetAllInputs]);

  // Safety net: reset on window blur, tab hide, or global pointer release if capture was lost/unavailable
  useEffect(() => {
    if (!visible) return;

    const handleWindowReset = () => {
      resetAllInputs();
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        resetAllInputs();
      }
    };

    const handleGlobalPointerRelease = (e: PointerEvent) => {
      if (joyPointerId.current === e.pointerId) {
        resetJoystick();
      }
      if (camPointerId.current === e.pointerId) {
        resetCamera();
      }
      if (jumpPointerId.current === e.pointerId) {
        resetJump();
      }
    };

    window.addEventListener('blur', handleWindowReset);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pointerup', handleGlobalPointerRelease);
    window.addEventListener('pointercancel', handleGlobalPointerRelease);

    return () => {
      window.removeEventListener('blur', handleWindowReset);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pointerup', handleGlobalPointerRelease);
      window.removeEventListener('pointercancel', handleGlobalPointerRelease);
    };
  }, [visible, resetAllInputs, resetCamera, resetJoystick, resetJump]);

  // Ensure unmount always zeros inputs
  useEffect(() => {
    return () => {
      resetAllInputs();
    };
  }, [resetAllInputs]);

  if (!visible) return null;

  const updateJoyFromClient = (clientX: number, clientY: number) => {
    const vec = computeJoystickOutput(
      clientX,
      clientY,
      joyCenter.current.x,
      joyCenter.current.y,
      JOYSTICK_MAX_RADIUS,
    );
    setKnobOffset({ x: vec.offsetX, y: vec.offsetY });
    onJoystickChangeRef.current(vec.normX, vec.normY);
  };

  const handleJoyDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== null) return;
    e.stopPropagation();
    joyPointerId.current = e.pointerId;
    safeSetPointerCapture(e.currentTarget, e.pointerId);
    const rect = e.currentTarget.getBoundingClientRect();
    joyCenter.current = {
      x: rect.left + rect.width * 0.5,
      y: rect.top + rect.height * 0.5,
    };
    setJoyActive(true);
    updateJoyFromClient(e.clientX, e.clientY);
  };

  const handleJoyMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    // If a mouse button was released outside the window/iframe without delivering pointerup, reset cleanly
    if (e.pointerType === 'mouse' && e.buttons === 0) {
      resetJoystick();
      return;
    }
    updateJoyFromClient(e.clientX, e.clientY);
  };

  const handleJoyEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    resetJoystick();
  };

  const handleCamDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (camPointerId.current !== null) return;
    camPointerId.current = e.pointerId;
    camLastPos.current = { x: e.clientX, y: e.clientY };
    safeSetPointerCapture(e.currentTarget, e.pointerId);
  };

  const handleCamMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (camPointerId.current !== e.pointerId) return;
    if (e.pointerType === 'mouse' && e.buttons === 0) {
      resetCamera();
      return;
    }
    const dx = e.clientX - camLastPos.current.x;
    const dy = e.clientY - camLastPos.current.y;
    camLastPos.current = { x: e.clientX, y: e.clientY };
    onCameraDeltaRef.current(dx * 0.0075, dy * 0.006);
  };

  const handleCamEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    if (camPointerId.current !== e.pointerId) return;
    resetCamera();
  };

  const handleJumpDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (jumpPointerId.current !== null) return;
    jumpPointerId.current = e.pointerId;
    safeSetPointerCapture(e.currentTarget, e.pointerId);
    onJumpChangeRef.current(true);
  };

  const handleJumpEnd = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (jumpPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    resetJump();
  };

  const interactLabel = interactType === 'switch'
    ? 'Switch'
    : interactType === 'release'
      ? 'Drop'
      : 'Grab';

  const normX = Number((knobOffset.x / JOYSTICK_MAX_RADIUS).toFixed(3));
  const normY = Number((knobOffset.y / JOYSTICK_MAX_RADIUS).toFixed(3));

  return (
    <div className="fixed inset-0 z-20 pointer-events-none gameplay-touch-layer">
      {/* Right-side gameplay camera rotation swipe zone (avoids conflict with buttons) */}
      <div
        ref={camElRef}
        data-testid="touch-camera-zone"
        onPointerDown={handleCamDown}
        onPointerMove={handleCamMove}
        onPointerUp={handleCamEnd}
        onPointerCancel={handleCamEnd}
        onLostPointerCapture={handleCamEnd}
        className="fixed top-16 right-0 bottom-0 left-[44%] pointer-events-auto gameplay-touch-layer"
      />

      {/* Bottom-left Virtual Joystick */}
      <div
        ref={joyElRef}
        data-testid="virtual-joystick"
        data-joy-active={joyActive ? 'true' : 'false'}
        data-joy-x={String(normX)}
        data-joy-y={String(normY)}
        aria-label="Movement joystick"
        onPointerDown={handleJoyDown}
        onPointerMove={handleJoyMove}
        onPointerUp={handleJoyEnd}
        onPointerCancel={handleJoyEnd}
        onLostPointerCapture={handleJoyEnd}
        className="fixed bottom-7 left-6 w-32 h-32 rounded-full pointer-events-auto flex items-center justify-center gameplay-touch-layer"
        style={{
          backgroundColor: joyActive ? 'rgba(15, 23, 36, 0.72)' : 'rgba(15, 23, 36, 0.52)',
          border: '1.5px solid rgba(148, 163, 184, 0.32)',
        }}
      >
        <div
          data-testid="virtual-joystick-knob"
          className="w-12 h-12 rounded-full pointer-events-none"
          style={{
            transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
            backgroundColor: joyActive ? 'rgba(56, 189, 248, 0.85)' : 'rgba(148, 163, 184, 0.58)',
            border: '2px solid rgba(224, 242, 254, 0.7)',
          }}
        />
      </div>

      {/* Bottom-right Action Controls: Jump + Contextual Interact (only when relevant) */}
      <div className="fixed bottom-7 right-6 flex items-end gap-3.5 pointer-events-auto z-30">
        {isGrabbing && (
          <button
            type="button"
            aria-label="Rotate held block"
            tabIndex={-1}
            onPointerDown={(e) => {
              e.stopPropagation();
              onRotateBlock();
            }}
            className="w-14 h-14 rounded-full font-semibold text-xs text-slate-100 flex items-center justify-center active:scale-95 transition-transform"
            style={{
              backgroundColor: 'rgba(20, 29, 43, 0.86)',
              border: '1.5px solid rgba(148, 163, 184, 0.42)',
            }}
          >
            Rotate
          </button>
        )}

        {interactType !== null && (
          <button
            type="button"
            data-testid="touch-interact-btn"
            aria-label={interactLabel}
            tabIndex={-1}
            onPointerDown={(e) => {
              e.stopPropagation();
              onInteract();
            }}
            className="w-16 h-16 rounded-full font-semibold text-xs text-white flex items-center justify-center active:scale-95 transition-transform"
            style={{
              backgroundColor: 'rgba(2, 132, 199, 0.9)',
              border: '1.5px solid rgba(125, 211, 252, 0.8)',
            }}
          >
            {interactLabel}
          </button>
        )}

        <button
          ref={jumpElRef}
          type="button"
          data-testid="touch-jump-btn"
          aria-label="Jump"
          tabIndex={-1}
          onPointerDown={handleJumpDown}
          onPointerUp={handleJumpEnd}
          onPointerCancel={handleJumpEnd}
          onLostPointerCapture={handleJumpEnd}
          className="w-[74px] h-[74px] rounded-full font-semibold text-sm text-slate-50 flex items-center justify-center active:scale-95 transition-transform"
          style={{
            backgroundColor: 'rgba(20, 29, 43, 0.84)',
            border: '2px solid rgba(56, 189, 248, 0.65)',
          }}
        >
          Jump
        </button>
      </div>
    </div>
  );
};

