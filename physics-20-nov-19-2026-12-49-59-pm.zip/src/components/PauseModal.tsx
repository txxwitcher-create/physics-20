import React from 'react';
import { Grid2x2, Home, Play, RotateCcw, Settings } from 'lucide-react';

interface PauseModalProps {
  levelId: number;
  levelTitle: string;
  onResume: () => void;
  onRestart: () => void;
  onOpenLevels: () => void;
  onOpenSettings: () => void;
  onMainMenu: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  levelId,
  levelTitle,
  onResume,
  onRestart,
  onOpenLevels,
  onOpenSettings,
  onMainMenu,
}) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Game Paused"
      className="fixed inset-0 z-30 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(7, 10, 15, 0.78)' }}
    >
      <div
        className="w-full max-w-sm rounded-xl p-6"
        style={{
          backgroundColor: '#111824',
          border: '1px solid rgba(148, 163, 184, 0.22)',
        }}
      >
        <div className="mb-6">
          <div className="font-mono-num text-xs text-[#38bdf8] mb-1">
            Level {String(levelId).padStart(2, '0')} · {levelTitle}
          </div>
          <h2 className="font-display text-2xl font-semibold text-slate-100">
            Paused
          </h2>
        </div>

        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onResume}
            className="flex items-center justify-between px-4 py-3 rounded-lg bg-[#0284c7] hover:bg-[#0ea5e9] text-white font-semibold text-sm transition-colors cursor-pointer"
          >
            <span>Resume</span>
            <Play className="w-4 h-4 fill-current" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="flex items-center justify-between px-4 py-2.5 rounded-lg bg-[#182230] hover:bg-[#223044] text-slate-100 border border-slate-700/70 font-medium text-sm transition-colors cursor-pointer"
          >
            <span>Restart Level</span>
            <RotateCcw className="w-4 h-4 text-slate-400" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onOpenLevels}
            className="flex items-center justify-between px-4 py-2.5 rounded-lg bg-[#182230] hover:bg-[#223044] text-slate-100 border border-slate-700/70 font-medium text-sm transition-colors cursor-pointer"
          >
            <span>Level Selection</span>
            <Grid2x2 className="w-4 h-4 text-slate-400" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            className="flex items-center justify-between px-4 py-2.5 rounded-lg bg-[#182230] hover:bg-[#223044] text-slate-100 border border-slate-700/70 font-medium text-sm transition-colors cursor-pointer"
          >
            <span>Settings</span>
            <Settings className="w-4 h-4 text-slate-400" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onMainMenu}
            className="flex items-center justify-between px-4 py-2.5 rounded-lg bg-transparent hover:bg-slate-800/70 text-slate-300 border border-slate-800 font-medium text-sm transition-colors cursor-pointer mt-1"
          >
            <span>Main Menu</span>
            <Home className="w-4 h-4 text-slate-400" aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
};
