import React, { useState } from 'react';
import { Check, Flame, Lock, Snowflake, X } from 'lucide-react';
import { LEVELS } from '../game/levels';
import { formatDuration, getWorldForLevel, WORLD_META, WORLD_ORDER } from '../game/rules';
import { TOTAL_LEVELS } from '../game/storage';
import type { EnvironmentTheme, ProgressState, WorldId } from '../game/types';

interface LevelSelectModalProps {
  progress: ProgressState;
  currentLevelId: number;
  onSelectLevel: (levelId: number) => void;
  onClose: () => void;
}

function getWorldAccent(theme: EnvironmentTheme): {
  activeBorder: string;
  activeBg: string;
  badgeText: string;
  cardCurrent: string;
} {
  if (theme === 'frozen') {
    return {
      activeBorder: 'border-[#7dd3fc]',
      activeBg: 'bg-[#102438]',
      badgeText: 'text-[#7dd3fc]',
      cardCurrent: 'bg-[#12293e] border-[#7dd3fc]',
    };
  }
  if (theme === 'inferno') {
    return {
      activeBorder: 'border-[#fb923c]',
      activeBg: 'bg-[#2a1712]',
      badgeText: 'text-[#fb923c]',
      cardCurrent: 'bg-[#2e1913] border-[#fb923c]',
    };
  }
  return {
    activeBorder: 'border-[#38bdf8]',
    activeBg: 'bg-[#162638]',
    badgeText: 'text-[#38bdf8]',
    cardCurrent: 'bg-[#162638] border-[#38bdf8]',
  };
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  progress,
  currentLevelId,
  onSelectLevel,
  onClose,
}) => {
  const [selectedWorldId, setSelectedWorldId] = useState<WorldId>(
    () => getWorldForLevel(currentLevelId).id,
  );

  const selectedWorld = WORLD_META[selectedWorldId];
  const worldLevels = LEVELS.filter(
    (l) => l.id >= selectedWorld.range[0] && l.id <= selectedWorld.range[1],
  );
  const accent = getWorldAccent(selectedWorld.theme);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Level Selection"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 sm:p-6"
      style={{ backgroundColor: 'rgba(7, 10, 15, 0.86)' }}
    >
      <div
        className="w-full max-w-4xl max-h-[88vh] flex flex-col rounded-xl overflow-hidden"
        style={{
          backgroundColor: '#111824',
          border: '1px solid rgba(148, 163, 184, 0.2)',
        }}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 shrink-0">
          <div>
            <h2 className="font-display text-xl font-semibold text-slate-100">
              World &amp; Level Selection
            </h2>
            <p className="text-xs text-slate-400 mt-0.5 font-mono-num">
              {Object.keys(progress.completedLevels).length} of {TOTAL_LEVELS} chambers solved
            </p>
          </div>
          <button
            type="button"
            aria-label="Close level selection"
            onClick={onClose}
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="overflow-y-auto modal-scroll-area p-5 sm:p-6 space-y-5">
          {/* World Selector Grid (Worlds 1–6) */}
          <div
            role="tablist"
            aria-label="Campaign Worlds"
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5"
          >
            {WORLD_ORDER.map((worldId) => {
              const world = WORLD_META[worldId];
              const isSelected = worldId === selectedWorldId;
              const worldUnlocked = progress.unlockedLevel >= world.range[0];
              const solvedInWorld = LEVELS.filter(
                (l) =>
                  l.id >= world.range[0] &&
                  l.id <= world.range[1] &&
                  Boolean(progress.completedLevels[l.id]),
              ).length;
              const worldAccent = getWorldAccent(world.theme);

              return (
                <button
                  key={worldId}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  data-world={worldId}
                  onClick={() => setSelectedWorldId(worldId)}
                  className={`text-left p-3 rounded-lg border transition-colors cursor-pointer ${
                    isSelected
                      ? `${worldAccent.activeBg} ${worldAccent.activeBorder}`
                      : worldUnlocked
                        ? 'bg-[#151d2a] border-slate-800 hover:border-slate-600 hover:bg-[#1a2434]'
                        : 'bg-[#0e141d] border-slate-800/70 opacity-75 hover:opacity-95'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className={`font-mono-num text-[11px] font-bold ${worldAccent.badgeText}`}>
                      World {world.number}
                    </span>
                    {world.theme === 'frozen' ? (
                      <Snowflake className="w-3.5 h-3.5 text-[#7dd3fc]" aria-hidden="true" />
                    ) : world.theme === 'inferno' ? (
                      <Flame className="w-3.5 h-3.5 text-[#fb923c]" aria-hidden="true" />
                    ) : !worldUnlocked ? (
                      <Lock className="w-3 h-3 text-slate-500" aria-hidden="true" />
                    ) : null}
                  </div>
                  <div className="text-xs font-semibold text-slate-100 truncate">
                    {world.name}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono-num">
                    {solvedInWorld}/5 · {String(world.range[0]).padStart(2, '0')}–{String(world.range[1]).padStart(2, '0')}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected World Details & Level Cards */}
          <section aria-label={`World ${selectedWorld.number}: ${selectedWorld.name}`}>
            <div className="flex flex-wrap items-baseline justify-between gap-2 pb-3 mb-4 border-b border-slate-800/80">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`font-mono-num text-xs font-bold uppercase tracking-wider ${accent.badgeText}`}>
                    World {selectedWorld.number}
                  </span>
                  <span className="text-slate-600" aria-hidden="true">·</span>
                  <span className="text-xs text-slate-400 font-mono-num">
                    Levels {String(selectedWorld.range[0]).padStart(2, '0')}–{String(selectedWorld.range[1]).padStart(2, '0')}
                  </span>
                  <span className="text-slate-600" aria-hidden="true">·</span>
                  <span className="text-xs text-slate-400">
                    {selectedWorld.difficultyLabel}
                  </span>
                </div>
                <h3 className="font-display text-lg font-semibold text-slate-100 mt-0.5">
                  {selectedWorld.name}
                </h3>
              </div>
              <p className="text-xs text-slate-400 max-w-md">
                {selectedWorld.subtitle}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {worldLevels.map((lvl) => {
                const unlocked = lvl.id <= progress.unlockedLevel;
                const record = progress.completedLevels[lvl.id];
                const isCurrent = lvl.id === currentLevelId;
                return (
                  <button
                    key={lvl.id}
                    type="button"
                    disabled={!unlocked}
                    data-level-id={lvl.id}
                    onClick={() => onSelectLevel(lvl.id)}
                    className={`text-left p-3.5 rounded-lg border transition-colors ${
                      unlocked
                        ? isCurrent
                          ? `${accent.cardCurrent} cursor-pointer`
                          : 'bg-[#161e2b] border-slate-800 hover:border-slate-600 hover:bg-[#1b2535] cursor-pointer'
                        : 'bg-[#0e141d] border-slate-800/60 opacity-55 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`font-mono-num text-xs font-bold ${accent.badgeText}`}>
                        Level {String(lvl.id).padStart(2, '0')}
                      </span>
                      {!unlocked ? (
                        <Lock className="w-3.5 h-3.5 text-slate-500" aria-label="Locked" />
                      ) : record ? (
                        <Check className="w-4 h-4 text-sky-400" aria-label="Completed" />
                      ) : null}
                    </div>
                    <div className="text-sm font-medium text-slate-100 truncate">
                      {lvl.title}
                    </div>
                    <div className="text-xs text-slate-400 mt-1 font-mono-num">
                      {record ? `Best ${formatDuration(record.bestTime)}` : unlocked ? 'Ready' : 'Locked'}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
