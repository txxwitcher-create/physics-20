import React from 'react';
import { Play, Grid2x2, Settings } from 'lucide-react';
import type { ProgressState } from '../game/types';
import { TOTAL_LEVELS } from '../game/storage';

interface TitleOverlayProps {
  progress: ProgressState;
  onPlay: () => void;
  onOpenLevels: () => void;
  onOpenSettings: () => void;
}

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  progress,
  onPlay,
  onOpenLevels,
  onOpenSettings,
}) => {
  const completedCount = Object.keys(progress.completedLevels).length;
  const playLabel = completedCount > 0 && progress.unlockedLevel <= TOTAL_LEVELS
    ? `Continue · Level ${String(progress.unlockedLevel).padStart(2, '0')}`
    : 'Play';

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-6 sm:p-10 lg:p-14">
      {/* Subtle left-side scrim so typography has >= 7:1 contrast over the live 3D scene */}
      <div
        aria-hidden="true"
        className="fixed inset-y-0 left-0 w-full sm:w-[480px] pointer-events-none"
        style={{
          background:
            'linear-gradient(90deg, rgba(10, 14, 21, 0.90) 0%, rgba(10, 14, 21, 0.68) 65%, rgba(10, 14, 21, 0) 100%)',
        }}
      />

      <div className="relative z-10 flex-1 flex flex-col justify-center max-w-md pointer-events-auto">
        {/* Bespoke inline SVG Architectural Crest + Title Lockup */}
        <div className="mb-8">
          <svg
            viewBox="0 0 370 112"
            className="w-72 sm:w-88 h-auto block"
            role="img"
            aria-label="PHYSICS 20"
          >
            {/* Geometric monolith crest */}
            <g transform="translate(2, 12)">
              <polygon
                points="32,2 62,19 62,53 32,70 2,53 2,19"
                fill="#111827"
                stroke="#8b6f4e"
                strokeWidth="2.2"
              />
              <polygon
                points="32,12 52,23.5 52,48.5 32,60 12,48.5 12,23.5"
                fill="none"
                stroke="#38bdf8"
                strokeWidth="1.5"
                strokeOpacity="0.85"
              />
              <circle cx="32" cy="36" r="9.5" fill="#38bdf8" fillOpacity="0.22" stroke="#7dd3fc" strokeWidth="1.8" />
              <circle cx="32" cy="36" r="3.8" fill="#e0f2fe" />
              <line x1="32" y1="2" x2="32" y2="12" stroke="#8b6f4e" strokeWidth="1.8" />
              <line x1="32" y1="60" x2="32" y2="70" stroke="#8b6f4e" strokeWidth="1.8" />
            </g>

            {/* Title Wordmark */}
            <text
              x="82"
              y="54"
              fontFamily="Outfit, sans-serif"
              fontWeight="700"
              fontSize="40"
              letterSpacing="2.5"
            >
              <tspan fill="#f1f5f9">PHYSICS </tspan>
              <tspan fill="#38bdf8" fontFamily="JetBrains Mono, monospace" letterSpacing="0">
                20
              </tspan>
            </text>
            <line x1="82" y1="68" x2="352" y2="68" stroke="#334155" strokeWidth="1.2" />
            <text
              x="82"
              y="88"
              fill="#94a3b8"
              fontFamily="Plus Jakarta Sans, sans-serif"
              fontWeight="500"
              fontSize="13.5"
              letterSpacing="0.8"
            >
              3D Physics Puzzle Adventure
            </text>
          </svg>
        </div>

        {/* Clean unboxed progression metadata */}
        <div className="flex items-center gap-2.5 text-sm text-slate-400 mb-7 font-mono-num">
          <span>{completedCount} / {TOTAL_LEVELS} Solved</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Level {String(progress.unlockedLevel).padStart(2, '0')} Unlocked</span>
        </div>

        {/* Primary Menu Actions (3 controls) */}
        <div className="flex flex-col gap-3 w-full max-w-[280px]">
          <button
            type="button"
            data-start="true"
            onClick={(e) => {
              e.currentTarget.blur();
              onPlay();
            }}
            className="flex items-center justify-between px-5 py-3.5 rounded-lg bg-[#0284c7] hover:bg-[#0ea5e9] active:bg-[#0369a1] text-white font-semibold text-base transition-colors cursor-pointer whitespace-nowrap shadow-lg"
          >
            <span>{playLabel}</span>
            <Play className="w-4 h-4 fill-current shrink-0" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenLevels();
            }}
            className="flex items-center justify-between px-5 py-3 rounded-lg bg-[#161e2a] hover:bg-[#1e293b] text-slate-100 border border-slate-700/80 font-medium text-sm transition-colors cursor-pointer whitespace-nowrap"
          >
            <span>Level Selection</span>
            <Grid2x2 className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenSettings();
            }}
            className="flex items-center justify-between px-5 py-3 rounded-lg bg-[#161e2a] hover:bg-[#1e293b] text-slate-100 border border-slate-700/80 font-medium text-sm transition-colors cursor-pointer whitespace-nowrap"
          >
            <span>Settings</span>
            <Settings className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Flat borderless control hint line in bottom safe margin */}
      <div className="relative z-10 text-xs text-slate-400 tracking-wide hidden sm:block">
        WASD Move · Space Jump · E Interact · Q Rotate Block · Drag Camera · Esc Pause
      </div>
    </div>
  );
};
