import React from 'react';
import { ArrowRight, Grid2x2, RotateCcw } from 'lucide-react';
import { formatDuration } from '../game/rules';
import { TOTAL_LEVELS } from '../game/storage';
import type { CompletionSummary } from '../game/types';

interface CompletionModalProps {
  summary: CompletionSummary;
  onNextLevel: () => void;
  onReplay: () => void;
  onOpenLevels: () => void;
}

export const CompletionModal: React.FC<CompletionModalProps> = ({
  summary,
  onNextLevel,
  onReplay,
  onOpenLevels,
}) => {
  const isFinalClear = !summary.hasNextLevel;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Level Complete"
      className="fixed inset-0 z-30 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(7, 10, 15, 0.80)' }}
    >
      <div
        className="w-full max-w-md rounded-xl p-6 sm:p-7"
        style={{
          backgroundColor: '#111824',
          border: '1px solid rgba(56, 189, 248, 0.35)',
        }}
      >
        {/* Geometric Completion Crest */}
        <div className="flex items-center gap-3.5 mb-5">
          <svg viewBox="0 0 44 44" className="w-11 h-11 shrink-0" aria-hidden="true">
            <polygon
              points="22,2 40,12 40,32 22,42 4,32 4,12"
              fill="#0c263b"
              stroke="#38bdf8"
              strokeWidth="2"
            />
            <polyline
              points="14,22 20,28 31,16"
              fill="none"
              stroke="#e0f2fe"
              strokeWidth="2.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <div>
            <div className="font-mono-num text-xs text-[#38bdf8]">
              Level {String(summary.levelId).padStart(2, '0')} Cleared
            </div>
            <h2 className="font-display text-2xl font-semibold text-slate-100">
              {isFinalClear ? `All ${TOTAL_LEVELS} Chambers Solved` : summary.levelTitle}
            </h2>
          </div>
        </div>

        {/* Tabular Metrics Strip */}
        <div className="grid grid-cols-2 gap-3 mb-6 py-3.5 border-y border-slate-800">
          <div>
            <div className="text-xs text-slate-400">Completion Time</div>
            <div className="font-mono-num text-xl font-bold text-slate-100 mt-0.5">
              {formatDuration(summary.elapsedTime)}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-400">
              Best Time {summary.isNewBest ? '· New Record' : ''}
            </div>
            <div className="font-mono-num text-xl font-bold text-[#38bdf8] mt-0.5">
              {formatDuration(summary.bestTime)}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-2.5">
          {summary.hasNextLevel ? (
            <button
              type="button"
              data-start="true"
              onClick={onNextLevel}
              className="flex items-center justify-between px-5 py-3 rounded-lg bg-[#0284c7] hover:bg-[#0ea5e9] text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              <span>Next Level · {String(summary.levelId + 1).padStart(2, '0')}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          ) : (
            <button
              type="button"
              data-start="true"
              onClick={onOpenLevels}
              className="flex items-center justify-between px-5 py-3 rounded-lg bg-[#0284c7] hover:bg-[#0ea5e9] text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              <span>Browse All {TOTAL_LEVELS} Levels</span>
              <Grid2x2 className="w-4 h-4" aria-hidden="true" />
            </button>
          )}

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={onReplay}
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#182230] hover:bg-[#223044] text-slate-100 border border-slate-700/70 font-medium text-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-slate-400" aria-hidden="true" />
              <span>Replay</span>
            </button>

            <button
              type="button"
              onClick={onOpenLevels}
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#182230] hover:bg-[#223044] text-slate-100 border border-slate-700/70 font-medium text-sm transition-colors cursor-pointer"
            >
              <Grid2x2 className="w-4 h-4 text-slate-400" aria-hidden="true" />
              <span>Levels</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
