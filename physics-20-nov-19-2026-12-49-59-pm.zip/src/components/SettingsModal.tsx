import React, { useState } from 'react';
import { X } from 'lucide-react';
import type { GraphicsQuality, SettingsState, TouchControlsMode } from '../game/types';

interface SettingsModalProps {
  settings: SettingsState;
  onChange: (next: SettingsState) => void;
  onResetProgress: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onChange,
  onResetProgress,
  onClose,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  const patch = (partial: Partial<SettingsState>) => {
    onChange({ ...settings, ...partial });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Settings"
      className="fixed inset-0 z-40 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(7, 10, 15, 0.84)' }}
    >
      <div
        className="w-full max-w-md max-h-[88vh] flex flex-col rounded-xl overflow-hidden"
        style={{
          backgroundColor: '#111824',
          border: '1px solid rgba(148, 163, 184, 0.22)',
        }}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <h2 className="font-display text-xl font-semibold text-slate-100">Settings</h2>
          <button
            type="button"
            aria-label="Close settings"
            onClick={onClose}
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="overflow-y-auto modal-scroll-area p-6 space-y-5 text-sm">
          {/* Audio Controls */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 tracking-wide">Audio</h3>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-200">Sound Effects</span>
              <input
                type="checkbox"
                checked={settings.sfxEnabled}
                onChange={(e) => patch({ sfxEnabled: e.target.checked })}
                className="w-4 h-4 accent-[#0284c7] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-200">Ambient Music</span>
              <input
                type="checkbox"
                checked={settings.musicEnabled}
                onChange={(e) => patch({ musicEnabled: e.target.checked })}
                className="w-4 h-4 accent-[#0284c7] cursor-pointer"
              />
            </label>

            <label className="block">
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Master Volume</span>
                <span className="font-mono-num text-xs text-slate-400">
                  {Math.round(settings.volume * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={settings.volume}
                onChange={(e) => patch({ volume: Number(e.target.value) })}
                className="w-full accent-[#0284c7] cursor-pointer"
              />
            </label>
          </div>

          {/* Camera & Controls */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <h3 className="text-xs font-semibold text-slate-400 tracking-wide">Controls</h3>

            <label className="block">
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Camera Sensitivity</span>
                <span className="font-mono-num text-xs text-slate-400">
                  {settings.cameraSensitivity.toFixed(1)}x
                </span>
              </div>
              <input
                type="range"
                min={0.4}
                max={2.0}
                step={0.1}
                value={settings.cameraSensitivity}
                onChange={(e) => patch({ cameraSensitivity: Number(e.target.value) })}
                className="w-full accent-[#0284c7] cursor-pointer"
              />
            </label>

            <div>
              <div className="text-slate-300 mb-1.5">Touch Controls</div>
              <div className="grid grid-cols-3 gap-1.5 p-1 rounded-lg bg-[#0c111a]">
                {(['auto', 'always', 'off'] as TouchControlsMode[]).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => patch({ touchControlsMode: mode })}
                    className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer capitalize ${
                      settings.touchControlsMode === mode
                        ? 'bg-[#0284c7] text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Graphics & Diagnostics */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <h3 className="text-xs font-semibold text-slate-400 tracking-wide">Display</h3>

            <div>
              <div className="text-slate-300 mb-1.5">Graphics Quality</div>
              <div className="grid grid-cols-3 gap-1.5 p-1 rounded-lg bg-[#0c111a]">
                {(['auto', 'high', 'balanced'] as GraphicsQuality[]).map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => patch({ graphicsQuality: q })}
                    className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer capitalize ${
                      settings.graphicsQuality === q
                        ? 'bg-[#0284c7] text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <label className="flex items-center justify-between cursor-pointer pt-1">
              <span className="text-slate-300">Show FPS Counter (Testing)</span>
              <input
                type="checkbox"
                checked={settings.showFps}
                onChange={(e) => patch({ showFps: e.target.checked })}
                className="w-4 h-4 accent-[#0284c7] cursor-pointer"
              />
            </label>
          </div>

          {/* Save Data Reset */}
          <div className="pt-4 border-t border-slate-800">
            {!confirmReset ? (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="w-full py-2.5 px-4 rounded-lg border border-red-900/60 bg-red-950/30 hover:bg-red-950/50 text-red-300 text-xs font-medium transition-colors cursor-pointer"
              >
                Reset Saved Progress
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onResetProgress();
                    setConfirmReset(false);
                  }}
                  className="flex-1 py-2.5 px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  Confirm Reset
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="flex-1 py-2.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
