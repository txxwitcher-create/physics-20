import React from 'react';
import { Pause, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { formatDuration } from '../game/rules';
import { TOTAL_LEVELS } from '../game/storage';
import type { HudSnapshot } from '../game/types';

interface GameHudProps {
  hud: HudSnapshot;
  isMuted: boolean;
  showFps: boolean;
  showTouchControls: boolean;
  onPause: () => void;
  onRestart: () => void;
  onToggleMute: () => void;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  isMuted,
  showFps,
  showTouchControls,
  onPause,
  onRestart,
  onToggleMute,
}) => {
  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-3 sm:p-5">
      {/* Top Row: Left Level & Objective Readout | Right Utility Icon Buttons */}
      <div className="flex items-start justify-between gap-2.5 sm:gap-4">
        <div
          className="px-3 py-2 sm:px-4 sm:py-2.5 rounded-lg max-w-[230px] sm:max-w-md"
          style={{
            backgroundColor: 'rgba(13, 18, 26, 0.84)',
            border: '1px solid rgba(148, 163, 184, 0.16)',
          }}
        >
          <div className="flex items-center gap-2 text-xs sm:text-sm">
            <span className="font-mono-num font-bold text-[#38bdf8] whitespace-nowrap">
              {String(hud.levelId).padStart(2, '0')} / {TOTAL_LEVELS}
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-display font-semibold text-slate-100 truncate">
              {hud.levelTitle}
            </span>
            <span aria-hidden="true" className="text-slate-600 hidden sm:inline">·</span>
            <span className="font-mono-num text-xs text-slate-300 hidden sm:inline whitespace-nowrap">
              {formatDuration(hud.elapsedTime)}
            </span>
          </div>
          <p className="text-[11px] sm:text-xs text-slate-300/90 mt-1 leading-snug">
            {hud.objective}
          </p>

          {/* Dynamic mechanic readouts — rendered strictly when relevant to the active level */}
          {(hud.movesRemaining !== null || hud.gravityLabel || hud.timedRemaining !== null) && (
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 pt-1.5 border-t border-slate-800 text-xs font-mono-num">
              {hud.movesRemaining !== null && hud.moveLimit !== null && (
                <span className={hud.movesRemaining <= 2 ? 'text-amber-400 font-semibold' : 'text-sky-300'}>
                  Pulses {hud.movesRemaining}/{hud.moveLimit}
                </span>
              )}
              {hud.gravityLabel && (
                <span className="text-sky-300">
                  Gravity: {hud.gravityLabel}
                </span>
              )}
              {hud.timedRemaining !== null && (
                <span className="text-amber-300 font-semibold">
                  {hud.timedLabel ?? 'Timer'} {hud.timedRemaining.toFixed(1)}s
                </span>
              )}
            </div>
          )}
        </div>

        {/* Top-Right Compact Utility Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 pointer-events-auto shrink-0">
          {showFps && (
            <div
              data-testid="fps-counter"
              className="px-2 py-1.5 sm:px-2.5 sm:py-2 rounded-lg text-xs font-mono-num text-slate-300 pointer-events-none"
              style={{
                backgroundColor: 'rgba(13, 18, 26, 0.84)',
                border: '1px solid rgba(148, 163, 184, 0.16)',
              }}
            >
              {hud.fps} FPS
            </div>
          )}

          <button
            type="button"
            aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
            title={isMuted ? 'Unmute (M)' : 'Mute (M)'}
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onToggleMute();
            }}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-200 hover:text-white transition-colors cursor-pointer"
            style={{
              backgroundColor: 'rgba(13, 18, 26, 0.86)',
              border: '1px solid rgba(148, 163, 184, 0.2)',
            }}
          >
            {isMuted ? <VolumeX className="w-4 h-4" aria-hidden="true" /> : <Volume2 className="w-4 h-4" aria-hidden="true" />}
          </button>

          <button
            type="button"
            aria-label="Restart level"
            title="Restart (R)"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onRestart();
            }}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-200 hover:text-white transition-colors cursor-pointer"
            style={{
              backgroundColor: 'rgba(13, 18, 26, 0.86)',
              border: '1px solid rgba(148, 163, 184, 0.2)',
            }}
          >
            <RotateCcw className="w-4 h-4" aria-hidden="true" />
          </button>

          <button
            type="button"
            aria-label="Pause game"
            title="Pause (Esc)"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onPause();
            }}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-200 hover:text-white transition-colors cursor-pointer"
            style={{
              backgroundColor: 'rgba(13, 18, 26, 0.86)',
              border: '1px solid rgba(148, 163, 184, 0.2)',
            }}
          >
            <Pause className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Transient Checkpoint / Status Banner */}
      {hud.checkpointBanner && (
        <div className="self-center mt-2">
          <div
            className="px-4 py-1.5 rounded-md text-xs font-medium text-sky-200 tracking-wide"
            style={{
              backgroundColor: 'rgba(12, 30, 48, 0.88)',
              border: '1px solid rgba(56, 189, 248, 0.4)',
            }}
          >
            {hud.checkpointBanner}
          </div>
        </div>
      )}

      {/* Bottom Contextual Interaction Prompt (Desktop only; mobile uses TouchControls button) */}
      <div className="flex justify-center pb-2">
        {!showTouchControls && hud.interactPrompt && (
          <div
            className="px-4 py-2 rounded-lg text-sm font-medium text-sky-100 whitespace-nowrap"
            style={{
              backgroundColor: 'rgba(13, 21, 32, 0.88)',
              border: '1px solid rgba(56, 189, 248, 0.45)',
            }}
          >
            {hud.interactPrompt}
          </div>
        )}
      </div>
    </div>
  );
};
